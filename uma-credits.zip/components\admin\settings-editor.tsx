'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import {
  IconSpark,
  IconCheck,
  IconCross,
  IconGear,
  IconArrow,
  IconRupee,
} from '@/components/icons';
import {
  Button,
  Card,
  Badge,
  SectionLabel,
  Input,
  Textarea,
  Select,
  ToastStack,
  useToasts,
  inr,
  relativeTime,
} from '@/components/ui';
import { useRouter } from 'next/navigation';
import { useSettings } from '@/components/settings-provider';
import { calculateLoan } from '@/lib/loan-math';

interface SettingRow {
  key: string;
  label: string;
  category: string;
  type: string;
  value: string;
  options?: { value: string; label: string }[];
  description?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export function SettingsEditor({
  rows,
  pricing: serverPricing,
  defaults = {},
}: {
  rows: SettingRow[];
  pricing: any;
  defaults?: Record<string, string>;
}) {
  const router = useRouter();
  const { refresh } = useSettings();
  const { toasts, push, dismiss } = useToasts();

  const [values, setValues] = useState<Record<string, string>>(() =>
    Object.fromEntries(rows.map(r => [r.key, r.value]))
  );
  const [savedValues, setSavedValues] = useState<Record<string, string>>(() =>
    Object.fromEntries(rows.map(r => [r.key, r.value]))
  );
  const [meta, setMeta] = useState<Record<string, { updatedAt?: string; updatedBy?: string }>>(() =>
    Object.fromEntries(rows.map(r => [r.key, { updatedAt: r.updatedAt, updatedBy: r.updatedBy }]))
  );
  const [saving, setSaving] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>(rows[0]?.category ?? 'Brand & Identity');

  const categories = useMemo(() => Array.from(new Set(rows.map(r => r.category))), [rows]);

  const changedKeys = useMemo(
    () => rows.filter(r => (values[r.key] ?? '') !== (savedValues[r.key] ?? '')).map(r => r.key),
    [rows, values, savedValues]
  );

  const currentCategoryRows = rows.filter(r => r.category === activeCategory);

  function setFieldValue(key: string, val: string) {
    setValues(prev => ({ ...prev, [key]: val }));
  }

  function getValidationError(key: string) {
    const row = rows.find(r => r.key === key);
    if (row?.type === 'json') {
      try {
        JSON.parse(values[key] ?? '');
        return undefined;
      } catch {
        return 'Not valid JSON — the borrower app will fall back to the previous value';
      }
    }
    return undefined;
  }

  // Live loan calculation based on current editor state
  const liveQuote = useMemo(() => {
    try {
      const livePricing = {
        ...serverPricing,
        interestMethod: values.interest_method === 'flat' ? 'flat' : 'reducing',
        monthlyRatePct: parseFloat(values.monthly_interest_pct || '1.75'),
        processingFeePct: parseFloat(values.processing_fee_pct || '2'),
        gstPct: parseFloat(values.gst_pct || '18'),
      };
      return calculateLoan({
        principal: 10000,
        tenureMonths: parseInt(values.default_tenure_months || '6'),
        pricing: livePricing,
      });
    } catch {
      return calculateLoan({ principal: 10000, tenureMonths: 6, pricing: serverPricing });
    }
  }, [values, serverPricing]);

  async function handleSave() {
    if (!changedKeys.length) return;
    setSaving(true);
    try {
      const updates: Record<string, string> = {};
      changedKeys.forEach(k => {
        updates[k] = values[k] ?? '';
      });

      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updates }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update settings');
      }

      setSavedValues({ ...values });

      setMeta(prev => {
        const next = { ...prev };
        (data.updated || []).forEach((k: string) => {
          next[k] = { updatedAt: new Date().toISOString(), updatedBy: 'you' };
        });
        return next;
      });

      push({
        tone: 'good',
        title: 'Settings published',
        body: 'The borrower site already reflects the change — no redeploy.',
      });

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('settings:bump'));
      }

      await refresh();
      router.refresh();
    } catch (err: any) {
      push({ tone: 'bad', title: 'Could not save', body: err.message || '' });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-7">
      <header className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <SectionLabel>Dynamic configuration</SectionLabel>
          <h1 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] font-black leading-none">
            Rewrite the website without redeploying it.
          </h1>
          <p className="mt-3 max-w-2xl text-[14px] text-ink-3">
            Every value below is read from the <code className="rounded bg-ink/8 px-1.5 py-0.5 font-mono text-[12px]">app_settings</code> table on each request. Brand colours are pushed into CSS custom properties, so the borrower app repaints the instant you publish.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {changedKeys.length > 0 && (
            <Badge tone="amber">
              <IconSpark width={12} height={12} /> {changedKeys.length} unsaved
            </Badge>
          )}
          <Button
            variant="accent"
            size="lg"
            loading={saving}
            disabled={!changedKeys.length}
            onClick={handleSave}
          >
            <IconCheck width={16} height={16} /> Publish{' '}
            {changedKeys.length ? `${changedKeys.length} change${changedKeys.length > 1 ? 's' : ''}` : 'changes'}
          </Button>
        </div>
      </header>

      {/* Main Settings Editor & Live Preview Layout */}
      <div className="grid gap-6 lg:grid-cols-[220px_1fr] lg:items-start">
        {/* Category Nav */}
        <nav className="flex flex-wrap gap-2 lg:sticky lg:top-24 lg:flex-col lg:items-stretch">
          {categories.map(cat => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`ledger-row rounded-xl px-4 py-2.5 text-left text-[13px] font-semibold transition-all duration-300 ${
                cat === activeCategory
                  ? 'bg-brand text-paper'
                  : 'border border-ink/12 bg-[#fffaf1] text-ink-2 hover:border-brand/40'
              }`}
            >
              {cat}
              <span className={`ml-2 font-mono text-[10.5px] ${cat === activeCategory ? 'text-paper/60' : 'text-ink-3'}`}>
                {rows.filter(r => r.category === cat).length}
              </span>
            </button>
          ))}
        </nav>

        {/* Settings Cards */}
        <div className="grid gap-5">
          {currentCategoryRows.map(row => {
            const isChanged = (values[row.key] ?? '') !== row.value;
            const err = getValidationError(row.key);
            const val = values[row.key] ?? '';

            return (
              <Card
                key={row.key}
                className={`p-5 transition-shadow duration-300 ${
                  isChanged ? 'shadow-[0_0_0_2px_rgba(228,87,46,.35),0_18px_40px_-24px_rgba(23,19,15,.45)]' : ''
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="flex flex-wrap items-center gap-2 text-[14.5px] font-bold text-ink">
                      {row.label}
                      <code className="rounded bg-ink/8 px-1.5 py-0.5 font-mono text-[10.5px] font-normal text-ink-3">
                        {row.key}
                      </code>
                      {row.type === 'json' && <Badge tone="teal">JSON</Badge>}
                      {isChanged && <Badge tone="amber">edited</Badge>}
                    </p>
                    {row.description && (
                      <p className="mt-1.5 max-w-2xl text-[12.5px] leading-relaxed text-ink-3">{row.description}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-3">
                      {meta[row.key]?.updatedAt
                        ? `${relativeTime(meta[row.key].updatedAt)} · ${meta[row.key]?.updatedBy ?? 'system'}`
                        : 'never edited'}
                    </span>
                    {(values[row.key] ?? '') !== (defaults[row.key] ?? '') && (
                      <button
                        type="button"
                        onClick={() => setFieldValue(row.key, defaults[row.key] ?? '')}
                        className="flex items-center gap-1 rounded-full border border-ink/15 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.12em] text-ink-3 transition-colors hover:border-accent hover:text-accent"
                      >
                        <IconCross width={11} height={11} /> reset
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-4">
                  {row.type === 'boolean' ? (
                    <button
                      type="button"
                      onClick={() => setFieldValue(row.key, val === 'true' ? 'false' : 'true')}
                      className={`flex w-full items-center justify-between gap-4 rounded-xl border px-4 py-3 transition-all duration-300 ${
                        val === 'true' ? 'border-moss/40 bg-moss/10' : 'border-ink/15 bg-paper-2/40'
                      }`}
                    >
                      <span className="text-[13px] font-semibold text-ink">{val === 'true' ? 'On' : 'Off'}</span>
                      <span
                        className={`relative h-6 w-11 rounded-full transition-colors duration-300 ${
                          val === 'true' ? 'bg-moss' : 'bg-ink/25'
                        }`}
                      >
                        <span
                          className={`absolute top-0.5 h-5 w-5 rounded-full bg-paper shadow transition-all duration-300 ${
                            val === 'true' ? 'left-[22px]' : 'left-0.5'
                          }`}
                        />
                      </span>
                    </button>
                  ) : row.type === 'select' ? (
                    <Select value={val} onChange={e => setFieldValue(row.key, e.target.value)}>
                      {(row.options ?? []).map(opt => (
                        <option key={opt.value} value={opt.value}>
                          {opt.label}
                        </option>
                      ))}
                    </Select>
                  ) : row.type === 'textarea' || row.type === 'json' ? (
                    <Textarea
                      value={val}
                      rows={row.type === 'json' ? 8 : 4}
                      invalid={!!err}
                      onChange={e => setFieldValue(row.key, e.target.value)}
                      className={row.type === 'json' ? 'font-mono text-[12px] leading-relaxed' : ''}
                    />
                  ) : (
                    <div className="flex items-center gap-2">
                      {(row.key.includes('colour') || row.key.includes('theme')) && (
                        <input
                          type="color"
                          aria-label={`${row.label} colour picker`}
                          value={/^#[0-9a-f]{6}$/i.test(val) ? val : '#0f3d33'}
                          onChange={e => setFieldValue(row.key, e.target.value)}
                          className="h-11 w-12 shrink-0 cursor-pointer rounded-lg border border-ink/18 bg-paper p-1"
                        />
                      )}
                      <Input
                        value={val}
                        type={row.type === 'number' ? 'number' : 'text'}
                        step={row.type === 'number' ? '0.01' : undefined}
                        onChange={e => setFieldValue(row.key, e.target.value)}
                        invalid={!!err}
                        className={row.type === 'number' ? 'font-mono tabular' : ''}
                      />
                    </div>
                  )}
                </div>

                {err && <p className="mt-2 text-[12px] font-medium text-rust">{err}</p>}
              </Card>
            );
          })}
        </div>
      </div>

      {/* Live Preview Card */}
      <Card className="overflow-hidden p-0">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink/10 px-6 py-4">
          <div className="flex items-center gap-2">
            <IconGear width={15} height={15} className="text-accent" />
            <p className="font-mono text-[10.5px] uppercase tracking-[0.18em] text-ink-3">
              Live borrower-side preview
            </p>
          </div>
          <Link href="/" target="_blank" rel="noreferrer" className="text-[12.5px] font-semibold text-brand link-draw">
            Open the real site →
          </Link>
        </div>

        <div className="grid gap-0 lg:grid-cols-[1fr_320px]">
          <div className="p-6">
            <div
              className="rounded-[16px] border border-ink/12 p-5"
              style={{ background: values.theme_primary || '#0f3d33' }}
            >
              <p className="font-mono text-[10px] uppercase tracking-[0.22em]" style={{ color: '#e0a02f' }}>
                {values.hero_kicker || 'Bahi-khata style digital lending · Bengaluru'}
              </p>
              <p className="mt-3 font-display text-[clamp(1.4rem,3vw,2.1rem)] font-black leading-tight text-[#f7f1e6]">
                {values.hero_headline || 'A ₹1,000 loan, sanctioned before your chai gets cold.'}
              </p>
              <p className="mt-3 max-w-lg text-[13px] leading-relaxed text-[#f7f1e6]/70">
                {values.hero_subline || 'Log in with just your name and mobile number.'}
              </p>
              <span
                className="mt-5 inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-[13px] font-bold text-[#fff6ec]"
                style={{ background: values.theme_accent || '#e4572e' }}
              >
                Apply now <IconArrow width={14} height={14} />
              </span>
            </div>

            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {[
                { k: 'Rate / month', v: `${values.monthly_interest_pct || '1.75'}%` },
                { k: 'Processing fee', v: `${values.processing_fee_pct || '2'}%` },
                {
                  k: 'Min – max',
                  v: `${inr(Number(values.min_loan_rs) || 1000)} – ${inr(Number(values.max_loan_rs) || 200000)}`,
                },
              ].map(item => (
                <div key={item.k} className="rounded-xl border border-ink/12 bg-paper-2/40 px-4 py-3">
                  <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">{item.k}</p>
                  <p className="mt-1 font-display text-[19px] font-bold tabular">{item.v}</p>
                </div>
              ))}
            </div>

            <div className="mt-5">
              <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">Tenure chips</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {(() => {
                  try {
                    return JSON.parse(values.tenure_options || '[]').map((t: any) => (
                      <span key={t.months} className="rounded-full border border-ink/18 px-3 py-1.5 font-mono text-[11.5px] text-ink-2">
                        {t.months} mo
                      </span>
                    ));
                  } catch {
                    return <span className="text-[12.5px] text-rust">Fix the tenure JSON to preview the chips</span>;
                  }
                })()}
              </div>
            </div>
          </div>

          <div className="border-t border-ink/10 bg-paper-2/40 p-6 lg:border-l lg:border-t-0">
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">Sample quote at these settings</p>
            <div className="mt-4 grid gap-2.5 text-[13px]">
              {[
                { k: 'Borrow', v: inr(10000) },
                { k: 'Method', v: values.interest_method === 'flat' ? 'Flat' : 'Reducing balance' },
                { k: 'Tenure', v: `${values.default_tenure_months || 6} months` },
                { k: 'Rate', v: `${values.monthly_interest_pct || 1.75}% / mo` },
                { k: 'Live EMI preview', v: inr(liveQuote.emi) },
                { k: 'Total repayable', v: inr(liveQuote.totalRepayable) },
                { k: 'Server rate today', v: `${serverPricing.monthlyRatePct}% / mo` },
              ].map(item => (
                <div key={item.k} className="flex items-center justify-between gap-3 border-b border-ink/8 pb-2 last:border-0">
                  <span className="text-ink-3">{item.k}</span>
                  <span className="font-mono font-semibold tabular">{item.v}</span>
                </div>
              ))}
            </div>

            <p className="mt-5 flex items-start gap-2 rounded-xl border border-brand/20 bg-brand/6 px-4 py-3 text-[12px] leading-relaxed text-brand">
              <IconRupee width={14} height={14} className="mt-0.5 shrink-0" />
              Publishing writes to <code className="font-mono">app_settings</code>, invalidates the in-memory cache and broadcasts a <code className="font-mono">settings:bump</code> event so every open tab re-prices instantly.
            </p>
          </div>
        </div>
      </Card>

      <ToastStack toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
