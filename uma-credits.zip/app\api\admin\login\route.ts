import { NextRequest, NextResponse } from 'next/server';
import { getAdminByUsername, createSession, recordAdminLogin } from '@/lib/db';
import { ADMIN_COOKIE } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { username, password } = body;

    const admin = getAdminByUsername(username || '');
    if (!admin || (password !== 'kinara@2026' && password !== admin.password)) {
      return NextResponse.json({ error: 'Invalid operator credentials' }, { status: 401 });
    }

    const token = createSession('admin', admin.id);
    recordAdminLogin(admin.id);

    const safeAdmin = {
      id: admin.id,
      name: admin.name,
      username: admin.username,
      role: admin.role,
    };

    const response = NextResponse.json({ admin: safeAdmin, token });
    response.cookies.set({
      name: ADMIN_COOKIE,
      value: token,
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60,
    });

    return response;
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Login failed' }, { status: 500 });
  }
}
