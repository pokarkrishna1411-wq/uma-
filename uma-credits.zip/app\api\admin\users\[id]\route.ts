import { NextRequest, NextResponse } from 'next/server';
import { getUserById, updateUserStatus, deleteUser, getUserLoans, getUserTransactions } from '@/lib/db';
import { getCurrentAdmin } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const user = getUserById(params.id);
  if (!user) {
    return NextResponse.json({ error: 'Borrower not found' }, { status: 404 });
  }

  const loans = getUserLoans(user.id);
  const ledger = getUserTransactions(user.id);

  return NextResponse.json({
    user,
    loans,
    ledger,
  });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await req.json();
    const action = body.action;
    const status = body.status || (action === 'block' ? 'blocked' : action === 'unblock' ? 'active' : undefined);
    const reason = body.reason;

    if (status !== 'active' && status !== 'blocked') {
      return NextResponse.json({ error: 'Status must be active or blocked' }, { status: 400 });
    }

    const updatedUser = updateUserStatus(params.id, status, reason);
    if (!updatedUser) {
      return NextResponse.json({ error: 'Borrower not found' }, { status: 404 });
    }

    return NextResponse.json({ user: updatedUser, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Update failed' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = getCurrentAdmin();
    const operatorName = admin?.name || 'Rukmini Iyer';

    const success = deleteUser(params.id, operatorName);
    if (!success) {
      return NextResponse.json({ error: 'Borrower not found' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: 'Borrower and associated records deleted successfully',
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Delete failed' }, { status: 500 });
  }
}
