import React from 'react';
import { getAppSettings } from '@/lib/db';
import { SettingsEditor } from '@/components/admin/settings-editor';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function SettingsPage() {
  const { settings, values, pricing } = getAppSettings();
  return <SettingsEditor rows={settings} pricing={pricing} defaults={values} />;
}
