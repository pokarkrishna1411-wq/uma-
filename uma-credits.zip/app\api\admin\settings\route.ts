import { NextRequest, NextResponse } from 'next/server';
import { getAppSettings, updateSettings } from '@/lib/db';
import { getCurrentAdmin } from '@/lib/auth';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  const { settings, values, pricing } = getAppSettings();
  return NextResponse.json({
    settings,
    values,
    pricing,
    defaults: values,
  });
}

export async function PUT(req: NextRequest) {
  try {
    const admin = getCurrentAdmin();
    const operatorName = admin?.name || 'Rukmini Iyer';

    const body = await req.json();
    const updates = body.updates || body;

    const result = updateSettings(updates, operatorName);
    const refreshed = getAppSettings();

    return NextResponse.json({
      success: true,
      updated: result.updated,
      values: refreshed.values,
      pricing: refreshed.pricing,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Update settings failed' }, { status: 500 });
  }
}

export const POST = PUT;
export const PATCH = PUT;

