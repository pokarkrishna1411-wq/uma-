import { NextResponse } from 'next/server';
import { getAdminPortfolioStats } from '@/lib/db';

export async function GET() {
  const data = getAdminPortfolioStats();
  return NextResponse.json(data);
}
