import './globals.css';
import { Metadata } from 'next';
import { SettingsProvider } from '@/components/settings-provider';
import { getAppSettings } from '@/lib/db';

export const metadata: Metadata = {
  title: 'Uma Credits — Chhoti zaroorat. Bada bharosa.',
  description:
    'Log in with your name and mobile number, pick an amount, read the exact EMI and interest breakdown, complete KYC and track every repayment in your own ledger.',
  keywords: ['loan', 'EMI calculator', 'KYC', 'admin panel', 'lending', 'India'],
  themeColor: '#0f3d33',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { values, pricing } = getAppSettings();

  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400..900;1,9..144,400..900&family=IBM+Plex+Mono:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Manrope:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-paper text-ink antialiased">
        <SettingsProvider initial={{ settings: values, pricing }}>
          {children}
          <div className="grain-overlay" aria-hidden="true" />
        </SettingsProvider>
      </body>
    </html>
  );
}
