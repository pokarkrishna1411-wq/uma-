import { NextRequest, NextResponse } from 'next/server';
import { getLoanById, handleLoanAction } from '@/lib/db';
import { getCurrentAdmin } from '@/lib/auth';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const application = getLoanById(params.id);
  if (!application) {
    return NextResponse.json({ error: 'Application not found' }, { status: 404 });
  }
  return NextResponse.json({ application });
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = getCurrentAdmin();
    const operatorName = admin?.name || 'Rukmini Iyer';

    const body = await req.json();
    const { action, reason, note } = body;

    if (!action) {
      return NextResponse.json({ error: 'Action is required' }, { status: 400 });
    }

    const application = handleLoanAction(params.id, action, { reason, note }, operatorName);
    return NextResponse.json({ application, loan: application, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Action failed' }, { status: 500 });
  }
}
