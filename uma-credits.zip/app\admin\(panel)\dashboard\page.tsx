import React from 'react';
import { getAdminPortfolioStats } from '@/lib/db';
import { AdminDashboardClient } from '@/components/admin/dashboard-client';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function AdminDashboardPage() {
  const { stats, queue, activity } = getAdminPortfolioStats();

  return <AdminDashboardClient stats={stats} queue={queue} activity={activity} />;
}
