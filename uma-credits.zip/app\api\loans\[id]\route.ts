import { NextRequest, NextResponse } from 'next/server';
import { getLoanById } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const loan = getLoanById(params.id);
  if (!loan) {
    return NextResponse.json({ error: 'Loan not found' }, { status: 404 });
  }

  return NextResponse.json({ loan });
}
