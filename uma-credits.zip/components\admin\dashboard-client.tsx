'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  IconUsers,
  IconDoc,
  IconShield,
  IconBank,
  IconCoins,
  IconRupee,
  IconAlert,
  IconClock,
  IconArrow,
  IconCheck,
  IconCross,
} from '@/components/icons';
import {
  Button,
  Card,
  Badge,
  SectionLabel,
  EmptyState,
  ToastStack,
  useToasts,
  inr,
  inrCompact,
  relativeTime,
  maskPan,
  maskAccount,
} from '@/components/ui';

const chartColours = ['#0f3d33', '#e4572e', '#e0a02f', '#4f7a52', '#a63a22', '#5b6a6e'];

function DoubleBarChart({
  data,
  height = 190,
  labelA = 'Series A',
  labelB,
  format = (val: number) => inrCompact(val),
}: {
  data: { label: string; a: number; b?: number }[];
  height?: number;
  labelA?: string;
  labelB?: string;
  format?: (val: number) => string;
}) {
  const [animated, setAnimated] = useState(false);
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => setAnimated(true), 60);
    return () => clearTimeout(timer);
  }, []);

  const maxVal = Math.max(1, ...data.map(d => Math.max(d.a, d.b ?? 0)));

  return (
    <div>
      <div className="flex flex-wrap items-center gap-4 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">
        <span className="flex items-center gap-1.5">
          <span className="inline-block h-2 w-2 rounded-sm bg-brand" /> {labelA}
        </span>
        {labelB && (
          <span className="flex items-center gap-1.5">
            <span className="inline-block h-2 w-2 rounded-sm bg-accent" /> {labelB}
          </span>
        )}
      </div>

      <div className="relative mt-4 flex items-end gap-1.5" style={{ height }}>
        {data.map((item, idx) => {
          const heightA = animated ? (item.a / maxVal) * 100 : 0;
          const heightB = animated ? ((item.b ?? 0) / maxVal) * 100 : 0;
          const isDimmed = hoveredIdx !== null && hoveredIdx !== idx;

          return (
            <div
              key={`${item.label}-${idx}`}
              className="group relative flex h-full flex-1 items-end justify-center gap-[3px]"
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
            >
              <div
                className="w-1/2 max-w-5 rounded-t-[4px] bg-brand transition-all duration-[900ms] ease-out"
                style={{
                  height: `${Math.max(heightA, item.a > 0 ? 2 : 0)}%`,
                  transitionDelay: `${45 * idx}ms`,
                  opacity: isDimmed ? 0.45 : 1,
                }}
              />
              {labelB && (
                <div
                  className="w-1/2 max-w-5 rounded-t-[4px] bg-accent transition-all duration-[900ms] ease-out"
                  style={{
                    height: `${Math.max(heightB, (item.b ?? 0) > 0 ? 2 : 0)}%`,
                    transitionDelay: `${45 * idx + 90}ms`,
                    opacity: isDimmed ? 0.45 : 1,
                  }}
                />
              )}

              {hoveredIdx === idx && (
                <div className="pointer-events-none absolute -top-1 left-1/2 z-10 w-max -translate-x-1/2 -translate-y-full rounded-lg border border-ink/15 bg-[#fffcf4] px-3 py-2 text-left shadow-card">
                  <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-3">{item.label}</p>
                  <p className="mt-1 font-mono text-[12px] text-brand">
                    {labelA}: {format(item.a)}
                  </p>
                  {labelB && (
                    <p className="font-mono text-[12px] text-accent">
                      {labelB}: {format(item.b ?? 0)}
                    </p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="mt-2 flex gap-1.5">
        {data.map((item, idx) => (
          <span key={`${item.label}-x-${idx}`} className="flex-1 truncate text-center font-mono text-[9.5px] uppercase tracking-[0.08em] text-ink-3">
            {item.label}
          </span>
        ))}
      </div>
    </div>
  );
}

function DonutChart({
  slices,
  size = 168,
  centreLabel,
  centreValue,
}: {
  slices: { label: string; value: number; colour?: string }[];
  size?: number;
  centreLabel?: string;
  centreValue?: string;
}) {
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setAnimated(true), 80);
    return () => clearTimeout(timer);
  }, []);

  const total = slices.reduce((acc, s) => acc + s.value, 0) || 1;
  const radius = size / 2 - 14;
  const circumference = 2 * Math.PI * radius;
  let accumulatedOffset = 0;

  return (
    <div className="flex flex-wrap items-center gap-7">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0 -rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgba(23,19,15,.1)" strokeWidth="18" />
        {slices.map((slice, idx) => {
          const ratio = slice.value / total;
          const strokeLength = animated ? ratio * circumference : 0;
          const currentOffset = accumulatedOffset;
          accumulatedOffset += ratio * circumference;

          return (
            <circle
              key={slice.label}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={slice.colour ?? chartColours[idx % chartColours.length]}
              strokeWidth="18"
              strokeDasharray={`${strokeLength} ${circumference - strokeLength}`}
              strokeDashoffset={-currentOffset}
              strokeLinecap="butt"
              style={{
                transition: `stroke-dasharray 900ms cubic-bezier(.16,1,.3,1) ${110 * idx}ms`,
              }}
            />
          );
        })}
      </svg>

      <div className="grid gap-2">
        {centreValue && (
          <p className="mb-1 font-display text-[26px] font-bold leading-none tabular">
            {centreValue}
            {centreLabel && (
              <span className="ml-2 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">
                {centreLabel}
              </span>
            )}
          </p>
        )}
        {slices.map((slice, idx) => (
          <span key={slice.label} className="flex items-center gap-2.5 text-[12.5px] text-ink-2">
            <span
              className="inline-block h-2.5 w-2.5 rounded-sm"
              style={{ background: slice.colour ?? chartColours[idx % chartColours.length] }}
            />
            <span className="capitalize">{slice.label}</span>
            <span className="font-mono tabular text-ink-3">{slice.value}</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function HBarList({
  items,
  format = (val: number) => String(val),
}: {
  items: { name: string; value: number }[];
  format?: (val: number) => string;
}) {
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setAnimated(true), 120);
    return () => clearTimeout(timer);
  }, []);

  const maxVal = Math.max(1, ...items.map(i => i.value));

  return (
    <ul className="grid gap-3">
      {items.map((item, idx) => (
        <li key={item.name} className="grid gap-1.5">
          <span className="flex items-baseline justify-between gap-3">
            <span className="truncate text-[13px] font-medium capitalize text-ink-2">{item.name}</span>
            <span className="shrink-0 font-mono text-[12px] tabular text-ink-3">{format(item.value)}</span>
          </span>
          <span className="h-2 overflow-hidden rounded-full bg-ink/8">
            <span
              className="block h-full rounded-full transition-all duration-[1100ms] ease-out"
              style={{
                width: animated ? `${(item.value / maxVal) * 100}%` : '0%',
                background: chartColours[idx % chartColours.length],
                transitionDelay: `${70 * idx}ms`,
              }}
            />
          </span>
        </li>
      ))}
    </ul>
  );
}

function SparkLine({
  points,
  width = 220,
  height = 48,
  stroke = '#e4572e',
}: {
  points: number[];
  width?: number;
  height?: number;
  stroke?: string;
}) {
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setAnimated(true), 100);
    return () => clearTimeout(timer);
  }, []);

  if (points.length < 2) return <div style={{ height }} />;

  const maxP = Math.max(...points, 1);
  const minP = Math.min(...points, 0);
  const span = Math.max(1, maxP - minP);
  const stepX = width / (points.length - 1);

  const pathD = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${(i * stepX).toFixed(1)} ${(height - ((p - minP) / span) * (height - 6) - 3).toFixed(1)}`)
    .join(' ');

  const closedArea = `${pathD} L ${width} ${height} L 0 ${height} Z`;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      <path d={closedArea} fill={stroke} opacity={0.12 * (animated ? 1 : 0)} style={{ transition: 'opacity 900ms ease' }} />
      <path
        d={pathD}
        fill="none"
        stroke={stroke}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeDasharray={3 * width}
        strokeDashoffset={animated ? 0 : 3 * width}
        style={{ transition: 'stroke-dashoffset 1400ms cubic-bezier(.16,1,.3,1)' }}
      />
    </svg>
  );
}

export function AdminDashboardClient({
  stats,
  queue,
  activity,
}: {
  stats: any;
  queue: any[];
  activity: any[];
}) {
  const router = useRouter();
  const { toasts, push, dismiss } = useToasts();
  const [queueList, setQueueList] = useState<any[]>(queue || []);
  const [loadingLoanId, setLoadingLoanId] = useState<string | null>(null);

  async function handleLoanAction(loan: any, action: 'approve' | 'reject') {
    setLoadingLoanId(loan.id);
    try {
      const res = await fetch(`/api/admin/applications/${loan.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(
          action === 'reject'
            ? { action, reason: 'Does not meet the underwriting policy' }
            : { action }
        ),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Action failed');
      }

      // Optimistically remove from queue immediately
      setQueueList(prev => prev.filter(l => l.id !== loan.id));

      push({
        tone: 'good',
        title: action === 'approve' ? 'Sanctioned' : 'Rejected',
        body: `${loan.reference} · ${loan.userName ?? ''}`,
      });

      router.refresh();
    } catch (err: any) {
      push({ tone: 'bad', title: 'Action failed', body: err.message || '' });
    } finally {
      setLoadingLoanId(null);
    }
  }

  const kpis = [
    {
      label: 'Borrowers',
      value: String(stats.users.total),
      sub: `${stats.users.newThisWeek} new this week`,
      icon: <IconUsers width={15} height={15} />,
      tone: 'brand',
    },
    {
      label: 'Active loans',
      value: String(stats.loans.active),
      sub: `${stats.loans.pending} awaiting review`,
      icon: <IconDoc width={15} height={15} />,
      tone: 'accent',
    },
    {
      label: 'Sanctioned',
      value: inrCompact(stats.money.sanctioned),
      sub: 'lifetime principal',
      icon: <IconShield width={15} height={15} />,
      tone: 'brand',
    },
    {
      label: 'Disbursed',
      value: inrCompact(stats.money.disbursed),
      sub: 'net of fees',
      icon: <IconBank width={15} height={15} />,
      tone: 'brand',
    },
    {
      label: 'Collected',
      value: inrCompact(stats.money.collected),
      sub: `${stats.collectionRate}% collection rate`,
      icon: <IconCoins width={15} height={15} />,
      tone: 'moss',
    },
    {
      label: 'Outstanding',
      value: inrCompact(stats.money.outstanding),
      sub: 'principal still owed',
      icon: <IconRupee width={15} height={15} />,
      tone: 'brand',
    },
    {
      label: 'Overdue',
      value: inrCompact(stats.money.overdueAmount),
      sub: 'past the grace period',
      icon: <IconAlert width={15} height={15} />,
      tone: 'rust',
    },
    {
      label: 'Fees earned',
      value: inrCompact(stats.money.feesCollected),
      sub: 'processing + late fees',
      icon: <IconClock width={15} height={15} />,
      tone: 'haldi',
    },
  ];

  return (
    <div className="grid gap-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <SectionLabel>Control room</SectionLabel>
          <h1 className="mt-3 font-display text-[clamp(2rem,4.6vw,3.1rem)] font-black leading-none">
            The book, at a glance.
          </h1>
          <p className="mt-3 max-w-xl text-[14px] text-ink-3">
            {stats.kycPending} KYC record{stats.kycPending === 1 ? '' : 's'} waiting for verification ·{' '}
            {stats.dueToday.count} EMI{stats.dueToday.count === 1 ? '' : 's'} due today worth {inr(stats.dueToday.amount)} ·{' '}
            {stats.users.blocked} blocked number{stats.users.blocked === 1 ? '' : 's'}.
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <Link href="/admin/applications">
            <Button variant="accent">
              Open review queue{' '}
              {stats.loans.pending > 0 && (
                <span className="ml-1 rounded-full bg-[#fff6ec]/25 px-2 py-0.5 font-mono text-[10.5px]">
                  {stats.loans.pending}
                </span>
              )}
              <IconArrow width={15} height={15} />
            </Button>
          </Link>
          <a href="/api/admin/export?what=applications">
            <Button variant="outline">Export book (CSV)</Button>
          </a>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid gap-px overflow-hidden rounded-[20px] border border-ink/12 bg-ink/12 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((kpi, idx) => (
          <div
            key={kpi.label}
            className="ledger-row group relative bg-[#fffaf1] px-5 py-5"
            style={{ animation: `kf-fade-up .55s ease ${55 * idx}ms both` }}
          >
            <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">
              <span
                className={
                  kpi.tone === 'accent'
                    ? 'text-accent'
                    : kpi.tone === 'rust'
                    ? 'text-rust'
                    : kpi.tone === 'moss'
                    ? 'text-moss'
                    : kpi.tone === 'haldi'
                    ? 'text-haldi'
                    : 'text-brand'
                }
              >
                {kpi.icon}
              </span>
              {kpi.label}
            </p>
            <p className="mt-2.5 font-display text-[30px] font-black leading-none tabular">{kpi.value}</p>
            <p className="mt-1.5 text-[11.5px] text-ink-3">{kpi.sub}</p>
          </div>
        ))}
      </div>

      {/* Charts Section: 12 Weeks & Portfolio Mix */}
      <div className="grid gap-6 lg:grid-cols-[1.45fr_1fr]">
        <Card className="p-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <SectionLabel>Last 12 weeks</SectionLabel>
              <h2 className="mt-3 font-display text-[22px] font-bold leading-tight">
                Disbursals against collections
              </h2>
            </div>
            <div className="text-right">
              <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">12-week disbursal</p>
              <SparkLine points={(stats?.weekly || []).map((w: any) => w.disbursed)} stroke="#e4572e" />
            </div>
          </div>

          <div className="mt-6">
            <DoubleBarChart
              data={(stats?.weekly || []).map((w: any) => ({
                label: w.label,
                a: w.disbursed,
                b: w.collected,
              }))}
              labelA="Disbursed"
              labelB="Collected"
              height={210}
            />
          </div>

          <div className="mt-6 grid gap-3 border-t border-ink/10 pt-5 sm:grid-cols-3">
            {[
              { k: 'Applications', v: (stats?.weekly || []).reduce((s: number, w: any) => s + w.applications, 0) },
              { k: 'Disbursed', v: inr((stats?.weekly || []).reduce((s: number, w: any) => s + w.disbursed, 0)) },
              { k: 'Collected', v: inr((stats?.weekly || []).reduce((s: number, w: any) => s + w.collected, 0)) },
            ].map(item => (
              <div key={item.k}>
                <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">{item.k}</p>
                <p className="mt-1 font-display text-[21px] font-bold tabular">{item.v}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <SectionLabel>Portfolio mix</SectionLabel>
          <h2 className="mt-3 font-display text-[22px] font-bold leading-tight">Where every loan sits</h2>
          <div className="mt-6">
            <DonutChart
              slices={(stats?.statusMix || []).map((s: any) => ({
                label: s.status,
                value: s.count,
              }))}
              centreValue={String(stats?.loans?.total || 0)}
              centreLabel="applications"
            />
          </div>
          <div className="mt-7 grid gap-2">
            {(stats?.statusMix || []).map((s: any) => (
              <div
                key={s.status}
                className="flex items-center justify-between gap-3 border-b border-ink/8 pb-2 text-[12.5px] last:border-0"
              >
                <span className="capitalize text-ink-2">{s.status}</span>
                <span className="font-mono tabular text-ink-3">{inrCompact(s.amount)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* 3 Secondary Charts: Collections, Cities, Purposes */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="p-6">
          <SectionLabel>Expected collections</SectionLabel>
          <h3 className="mt-3 font-display text-[19px] font-bold leading-tight">EMIs falling due</h3>
          <div className="mt-5">
            <DoubleBarChart
              data={(stats?.upcomingEmi || []).map((u: any) => ({ label: u.label, a: u.amount }))}
              labelA="Due"
              height={150}
            />
          </div>
        </Card>

        <Card className="p-6">
          <SectionLabel>Where they are</SectionLabel>
          <h3 className="mt-3 font-display text-[19px] font-bold leading-tight">Borrowers by city</h3>
          <div className="mt-5">
            <HBarList items={(stats?.cities || []).map((c: any) => ({ name: c.name, value: c.count }))} />
          </div>
        </Card>

        <Card className="p-6">
          <SectionLabel>What for</SectionLabel>
          <h3 className="mt-3 font-display text-[19px] font-bold leading-tight">Loan purposes</h3>
          <div className="mt-5">
            <HBarList
              items={(stats?.purposes || []).map((p: any) => ({ name: p.name, value: p.amount }))}
              format={v => inrCompact(v)}
            />
          </div>
          <div className="mt-5 border-t border-ink/10 pt-4 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-3">
            Avg ticket {inr(stats?.avgTicket || 35000)} · avg tenure {stats?.avgTenure || 6} mo
          </div>
        </Card>

      </div>

      {/* Underwriting Queue Table */}
      <Card className="overflow-hidden p-0">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-ink/10 px-6 py-5">
          <div>
            <SectionLabel>Underwriting queue</SectionLabel>
            <h2 className="mt-3 font-display text-[22px] font-bold leading-tight">
              Applications waiting on a decision
            </h2>
          </div>
          <Link href="/admin/applications" className="text-[13px] font-semibold text-brand link-draw">
            Open full queue →
          </Link>
        </div>

        {queueList.length === 0 ? (
          <div className="p-6">
            <EmptyState
              icon={<IconCheck width={28} height={28} />}
              title="Queue is clear"
              body="Every submitted application has been sanctioned, rejected or disbursed."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead className="bg-paper-2/50 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">
                <tr>
                  <th className="px-5 py-3">Reference</th>
                  <th className="px-5 py-3">Borrower</th>
                  <th className="px-5 py-3">KYC</th>
                  <th className="px-5 py-3 text-right">Amount</th>
                  <th className="px-5 py-3 text-right">EMI</th>
                  <th className="px-5 py-3 text-right">Interest</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="text-[13px]">
                {queueList.map((app: any) => (
                  <tr key={app.id} className="ledger-row border-t border-ink/10">
                    <td className="px-5 py-3.5">
                      <Link
                        href={`/admin/applications/${app.id}`}
                        className="font-mono text-[12px] text-accent hover:underline"
                      >
                        {app.reference}
                      </Link>
                      <p className="mt-0.5 font-mono text-[10.5px] text-ink-3">{relativeTime(app.createdAt)}</p>
                    </td>
                    <td className="px-5 py-3.5">
                      <p className="font-semibold text-ink">{app.userName ?? '—'}</p>
                      <p className="font-mono text-[11px] text-ink-3">
                        +91 {app.userMobile} · {app.userCity ?? '—'}
                      </p>
                    </td>
                    <td className="px-5 py-3.5">
                      {app.kyc ? (
                        <span className="grid gap-0.5 font-mono text-[11px] text-ink-3">
                          <span>{maskPan(app.kyc.panMasked || app.kyc.pan)}</span>
                          <span>{maskAccount(app.kyc.bankAccountNumber)}</span>
                        </span>
                      ) : (
                        <Badge tone="rust">missing</Badge>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono font-semibold tabular">{inr(app.principal)}</td>
                    <td className="px-5 py-3.5 text-right font-mono tabular text-ink-2">{inr(app.emi)}</td>
                    <td className="px-5 py-3.5 text-right font-mono tabular text-ink-3">{inr(app.interest)}</td>
                    <td className="px-5 py-3.5">
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          variant="primary"
                          loading={loadingLoanId === app.id}
                          onClick={() => handleLoanAction(app, 'approve')}
                        >
                          <IconCheck width={13} height={13} /> Sanction
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          loading={loadingLoanId === app.id}
                          onClick={() => handleLoanAction(app, 'reject')}
                        >
                          <IconCross width={13} height={13} /> Reject
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Audit Trail & Portfolio Health */}
      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="p-6">
          <div className="flex items-center justify-between gap-4">
            <div>
              <SectionLabel>Audit trail</SectionLabel>
              <h2 className="mt-3 font-display text-[22px] font-bold leading-tight">Who did what</h2>
            </div>
            <Link href="/admin/activity" className="text-[13px] font-semibold text-brand link-draw">
              Full trail →
            </Link>
          </div>
          <ul className="mt-5 grid gap-1">
            {activity.slice(0, 7).map((log: any) => {
              const isDanger =
                log.action.includes('reject') || log.action.includes('block') || log.action.includes('failed');
              const isSuccess =
                log.action.includes('disburse') ||
                log.action.includes('approve') ||
                log.action.includes('close') ||
                log.action.includes('repay');
              const isWarning = log.action.includes('settings');

              return (
                <li key={log.id} className="ledger-row flex items-start gap-3 rounded-lg px-3 py-2.5">
                  <span
                    className={`mt-1 h-2 w-2 shrink-0 rounded-full ${
                      isDanger ? 'bg-rust' : isSuccess ? 'bg-moss' : isWarning ? 'bg-haldi' : 'bg-brand'
                    }`}
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] text-ink-2">{log.summary ?? log.action}</span>
                    <span className="mt-0.5 block font-mono text-[10.5px] uppercase tracking-[0.12em] text-ink-3">
                      {log.actorName} · {log.action} · {relativeTime(log.createdAt)}
                    </span>
                  </span>
                </li>
              );
            })}
          </ul>
        </Card>

        <Card className="p-6">
          <SectionLabel>Portfolio health</SectionLabel>
          <h2 className="mt-3 font-display text-[22px] font-bold leading-tight">Numbers that matter</h2>
          <div className="mt-5 grid gap-4">
            {[
              { k: 'Collection rate', v: `${stats.collectionRate}%`, p: stats.collectionRate },
              { k: 'KYC pending', v: `${stats.kycPending}`, p: Math.min(100, 12 * stats.kycPending) },
              {
                k: 'Blocked borrowers',
                v: `${stats.users.blocked}`,
                p: Math.min(100, (stats.users.blocked / Math.max(1, stats.users.total)) * 100),
              },
              {
                k: 'Rejected share',
                v: `${Math.round((stats.loans.rejected / Math.max(1, stats.loans.total)) * 100)}%`,
                p: (stats.loans.rejected / Math.max(1, stats.loans.total)) * 100,
              },
            ].map(item => (
              <div key={item.k}>
                <div className="flex items-baseline justify-between gap-3">
                  <span className="text-[13px] text-ink-2">{item.k}</span>
                  <span className="font-mono text-[14px] font-semibold tabular">{item.v}</span>
                </div>
                <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-ink/8">
                  <div
                    className="h-full rounded-full bg-brand transition-[width] duration-1000"
                    style={{ width: `${item.p}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          <p className="mt-6 rounded-xl border border-ink/12 bg-paper-2/50 px-4 py-3 text-[12.5px] leading-relaxed text-ink-3">
            Rates, tenures, fees and every line of website copy live in{' '}
            <Link href="/admin/settings" className="font-semibold text-brand link-draw">
              Site settings
            </Link>
            . Change them there and the borrower app re-prices instantly — no deploy.
          </p>
        </Card>
      </div>

      <ToastStack toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
