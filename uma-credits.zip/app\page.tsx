import React from 'react';
import { getCurrentUser } from '@/lib/auth';
import { AnnouncementTicker, SiteHeader, HeroSection } from '@/components/home/hero';
import {
  HowItWorksSection,
  LiveCalculatorSection,
  WhyLedgerSection,
  StoriesSection,
  EligibilitySection,
  RateBoardSection,
  FaqSection,
  SiteFooter,
} from '@/components/home/sections';

export default function HomePage() {
  const user = getCurrentUser();

  return (
    <main className="relative">
      <AnnouncementTicker />
      <SiteHeader user={user} />
      <HeroSection user={user} />
      <HowItWorksSection />
      <LiveCalculatorSection />
      <WhyLedgerSection />
      <StoriesSection />
      <EligibilitySection />
      <RateBoardSection />
      <FaqSection />
      <SiteFooter />
    </main>
  );
}
