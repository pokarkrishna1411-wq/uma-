import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { calculateLoan, PricingSettings, roundPaisa } from './loan-math';
export { roundPaisa };

const DB_PATH = path.join(process.cwd(), 'data', 'db.json');

export interface User {
  id: string;
  name: string;
  mobile: string;
  maskedMobile?: string;
  email?: string | null;
  city?: string | null;
  occupation?: string | null;
  status: 'active' | 'blocked';
  blockReason?: string | null;
  trustScore: number;
  loginCount: number;
  createdAt: string;
  lastLoginAt?: string | null;
}

export interface Admin {
  id: string;
  name: string;
  username: string;
  password?: string;
  role: 'owner' | 'reviewer';
  lastLoginAt?: string | null;
}

export interface Session {
  token: string;
  subjectType: 'user' | 'admin';
  subjectId: string;
  createdAt: string;
  expiresAt: string;
  userAgent?: string;
  ip?: string;
}

export interface KycRecord {
  id: string;
  loanId: string;
  fullName: string;
  mobile: string;
  email?: string;
  pan: string;
  panMasked?: string;
  bankAccountNumber: string;
  accountMasked?: string;
  bankName: string;
  ifsc: string;
  address?: string;
  status: 'submitted' | 'verified' | 'rejected';
  remark?: string | null;
  reviewedBy?: string | null;
  reviewedAt?: string | null;
  createdAt: string;
}

export interface Installment {
  id: string;
  loanId: string;
  number: number;
  dueDate: string;
  emi: number;
  principalPart: number;
  interestPart: number;
  openingBalance: number;
  closingBalance: number;
  status: 'upcoming' | 'due' | 'paid' | 'overdue';
  paidAt?: string | null;
  paidAmount?: number;
  lateFee?: number;
}

export interface LoanApplication {
  id: string;
  userId: string;
  userName?: string;
  userMobile?: string;
  userCity?: string;
  reference: string;
  purpose: string;
  principal: number;
  tenureMonths: number;
  interestMethod: 'reducing' | 'flat';
  monthlyRatePct: number;
  annualRatePct: number;
  processingFeePct: number;
  interest: number;
  processingFee: number;
  gst: number;
  netDisbursal: number;
  totalRepayable: number;
  emi: number;
  status: 'pending' | 'approved' | 'active' | 'closed' | 'rejected';
  rejectionReason?: string | null;
  adminNote?: string | null;
  decidedBy?: string | null;
  createdAt: string;
  decidedAt?: string | null;
  disbursedAt?: string | null;
  closedAt?: string | null;
  firstDueDate?: string;
  maturityDate?: string;
  paidCount?: number;
  totalInstallments?: number;
  paidAmount?: number;
  outstandingPrincipal?: number;
  remainingRepayment?: number;
  progress?: number;
  nextDue?: {
    dueDate: string;
    amount: number;
    installmentNumber: number;
  } | null;
  overdueCount?: number;
  schedule?: Installment[];
  kyc?: KycRecord;
}

export interface Transaction {
  id: string;
  loanId?: string;
  loanReference?: string;
  borrowerName?: string;
  type: 'disbursement' | 'processing_fee' | 'repayment' | 'late_fee' | 'refund';
  mode: 'upi' | 'neft' | 'nach' | 'cash' | 'card';
  amount: number; // Signed: disbursements are negative, repayments are positive
  reference: string;
  note?: string;
  createdAt: string;
}

export interface SettingItem {
  key: string;
  label: string;
  category: string;
  type: 'text' | 'textarea' | 'number' | 'boolean' | 'select' | 'json';
  value: string;
  options?: Array<{ value: string; label: string }>;
  description?: string;
  public?: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

export interface ActivityLog {
  id: string;
  actorType: 'admin' | 'user' | 'system';
  actorName: string;
  action: string;
  entityType?: string | null;
  entityId?: string | null;
  summary: string;
  meta?: any;
  createdAt: string;
}

export interface DatabaseSchema {
  users: User[];
  admins: Admin[];
  sessions: Session[];
  loans: LoanApplication[];
  kyc: KycRecord[];
  installments: Installment[];
  transactions: Transaction[];
  settings: SettingItem[];
  settingsValues: Record<string, string>;
  activity: ActivityLog[];
}

function readDb(): DatabaseSchema {
  if (!fs.existsSync(DB_PATH)) {
    throw new Error(`Database file not found at ${DB_PATH}`);
  }
  const content = fs.readFileSync(DB_PATH, 'utf-8');
  return JSON.parse(content);
}

function writeDb(db: DatabaseSchema) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf-8');
}

export function maskPAN(pan: string): string {
  if (!pan || pan.length < 5) return pan;
  return pan.slice(0, 4) + '****' + pan.slice(-2);
}

export function maskAccount(acc: string): string {
  if (!acc || acc.length < 4) return acc;
  return '•••• ' + acc.slice(-4);
}

export function maskMobile(mobile: string): string {
  if (!mobile || mobile.length < 10) return mobile;
  return `+91 ${mobile.slice(0, 5)} ${mobile.slice(5)}`;
}

// ================= USERS =================
export function getAllUsers(): User[] {
  const db = readDb();
  return db.users;
}

export function getUserById(id: string): User | undefined {
  const db = readDb();
  return db.users.find(u => u.id === id);
}

export function getUserByMobile(mobile: string): User | undefined {
  const db = readDb();
  return db.users.find(u => u.mobile.replace(/\D/g, '').endsWith(mobile.replace(/\D/g, '').slice(-10)));
}

export function upsertBorrower(name: string, mobile: string): User {
  const db = readDb();
  const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
  let user = db.users.find(u => u.mobile.replace(/\D/g, '').endsWith(cleanMobile));

  const now = new Date().toISOString();
  if (user) {
    user.loginCount = (user.loginCount || 1) + 1;
    user.lastLoginAt = now;
    if (name && name.trim()) user.name = name.trim();
  } else {
    user = {
      id: crypto.randomUUID(),
      name: name.trim(),
      mobile: cleanMobile,
      maskedMobile: maskMobile(cleanMobile),
      email: null,
      city: null,
      occupation: null,
      status: 'active',
      trustScore: 650,
      loginCount: 1,
      createdAt: now,
      lastLoginAt: now,
    };
    db.users.unshift(user);
    logActivity({
      actorType: 'user',
      actorName: user.name,
      action: 'user.signup',
      entityType: 'user',
      entityId: user.id,
      summary: `New borrower registered with +91 ${cleanMobile}`,
    });
  }
  writeDb(db);
  return user;
}

export function updateUserStatus(userId: string, status: 'active' | 'blocked', reason?: string): User | null {
  const db = readDb();
  const user = db.users.find(u => u.id === userId);
  if (!user) return null;
  user.status = status;
  if (reason) user.blockReason = reason;
  if (status === 'blocked') {
    // Revoke borrower's sessions
    db.sessions = db.sessions.filter(s => s.subjectId !== userId);
  }
  writeDb(db);
  logActivity({
    actorType: 'admin',
    actorName: 'Operator',
    action: status === 'blocked' ? 'user.block' : 'user.unblock',
    entityType: 'user',
    entityId: userId,
    summary: `${status === 'blocked' ? 'Blocked' : 'Unblocked'} borrower ${user.name} (+91 ${user.mobile})`,
  });
  return user;
}

export function deleteUser(userId: string, operatorName = 'Operator'): boolean {
  const db = readDb();
  const userIndex = db.users.findIndex(u => u.id === userId);
  if (userIndex === -1) return false;

  const user = db.users[userIndex];
  // Remove user
  db.users.splice(userIndex, 1);

  // Remove user sessions
  db.sessions = (db.sessions || []).filter(s => s.subjectId !== userId);

  // Find user's loans
  const userLoans = (db.loans || []).filter(l => l.userId === userId);
  const loanIds = userLoans.map(l => l.id);

  // Remove loans
  db.loans = (db.loans || []).filter(l => l.userId !== userId);

  // Remove KYC records
  db.kyc = (db.kyc || []).filter(k => !loanIds.includes(k.loanId));

  // Remove installments
  db.installments = (db.installments || []).filter(i => !loanIds.includes(i.loanId));

  // Remove transactions
  db.transactions = (db.transactions || []).filter(t => !t.loanId || !loanIds.includes(t.loanId));

  writeDb(db);

  logActivity({
    actorType: 'admin',
    actorName: operatorName,
    action: 'user.delete',
    entityType: 'user',
    entityId: userId,
    summary: `${operatorName} deleted borrower ${user.name} (+91 ${user.mobile}) and all associated records`,
  });

  return true;
}

export function deleteAllUsers(operatorName = 'Operator'): { count: number } {
  const db = readDb();
  const count = db.users.length;

  db.users = [];
  // Keep admin sessions only
  db.sessions = (db.sessions || []).filter(s => s.subjectType === 'admin');
  db.loans = [];
  db.kyc = [];
  db.installments = [];
  db.transactions = [];

  writeDb(db);

  logActivity({
    actorType: 'admin',
    actorName: operatorName,
    action: 'users.purge',
    summary: `${operatorName} purged all ${count} borrowers and cleared loan registry`,
    meta: { purgedCount: count },
  });

  return { count };
}

// ================= SESSIONS =================
export function createSession(subjectType: 'user' | 'admin', subjectId: string): string {
  const db = readDb();
  const token = crypto.randomBytes(32).toString('hex');
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString();

  db.sessions.push({
    token,
    subjectType,
    subjectId,
    createdAt: now.toISOString(),
    expiresAt,
  });
  writeDb(db);
  return token;
}

export function getSession(token: string): Session | undefined {
  if (!token) return undefined;
  const db = readDb();
  const session = db.sessions.find(s => s.token === token);
  if (!session) return undefined;
  if (new Date(session.expiresAt) < new Date()) {
    deleteSession(token);
    return undefined;
  }
  return session;
}

export function deleteSession(token: string) {
  const db = readDb();
  db.sessions = db.sessions.filter(s => s.token !== token);
  writeDb(db);
}

// ================= ADMIN =================
export function getAdminByUsername(username: string): Admin | undefined {
  const db = readDb();
  return db.admins.find(a => a.username.toLowerCase() === username.toLowerCase());
}

export function recordAdminLogin(adminId: string) {
  const db = readDb();
  const admin = db.admins.find(a => a.id === adminId);
  if (admin) {
    admin.lastLoginAt = new Date().toISOString();
    writeDb(db);
    logActivity({
      actorType: 'admin',
      actorName: admin.name,
      action: 'admin.login',
      summary: `${admin.name} signed in to the admin panel`,
    });
  }
}

// ================= SETTINGS =================
export function getAppSettings(): { settings: SettingItem[]; values: Record<string, string>; pricing: PricingSettings } {
  const db = readDb();
  const values = db.settingsValues || {};
  db.settings.forEach(s => {
    values[s.key] = s.value;
  });

  const monthlyRatePct = parseFloat(values['monthly_interest_pct'] || '1.75');
  const processingFeePct = parseFloat(values['processing_fee_pct'] || '2');
  const gstPct = parseFloat(values['gst_pct'] || '18');

  let tenures = [
    { months: 3, label: '3 months · quick top-up' },
    { months: 6, label: '6 months · most popular' },
    { months: 9, label: '9 months' },
    { months: 12, label: '12 months · stock cycle' },
    { months: 18, label: '18 months' },
    { months: 24, label: '24 months · equipment' },
  ];
  try {
    if (values['tenure_options']) tenures = JSON.parse(values['tenure_options']);
  } catch {}

  let quickAmounts = [1000, 5000, 10000, 25000, 50000, 100000];
  try {
    if (values['quick_amounts']) quickAmounts = JSON.parse(values['quick_amounts']);
  } catch {}

  let purposes = [
    { value: 'business', label: 'Business & working capital' },
    { value: 'inventory', label: 'Festival inventory' },
    { value: 'equipment', label: 'Equipment & machinery' },
    { value: 'medical', label: 'Medical emergency' },
    { value: 'education', label: 'Education' },
    { value: 'personal', label: 'Personal need' },
  ];
  try {
    if (values['loan_purposes']) purposes = JSON.parse(values['loan_purposes']);
  } catch {}

  const pricing: PricingSettings = {
    interestMethod: values['interest_method'] === 'flat' ? 'flat' : 'reducing',
    monthlyRatePct,
    annualRatePct: roundPaisa(monthlyRatePct * 12),
    processingFeePct,
    gstPct,
    lateFee: parseFloat(values['late_fee_rs'] || '250'),
    bounceCharges: parseFloat(values['bounce_charges_rs'] || '350'),
    minLoan: parseFloat(values['min_loan_rs'] || '1000'),
    maxLoan: parseFloat(values['max_loan_rs'] || '200000'),
    stepAmount: parseFloat(values['step_amount_rs'] || '500'),
    defaultTenure: parseInt(values['default_tenure_months'] || '6'),
    graceDays: parseInt(values['grace_period_days'] || '5'),
    tenures,
    quickAmounts,
    purposes,
    acceptingApplications: values['accepting_applications'] !== 'false',
    maxActiveLoans: parseInt(values['max_active_loans_per_user'] || '2'),
    prepaymentAllowed: values['prepayment_allowed'] !== 'false',
    prepaymentPenaltyPct: parseFloat(values['prepayment_penalty_pct'] || '0'),
  };

  return {
    settings: db.settings,
    values,
    pricing,
  };
}

export function updateSettings(updates: Record<string, string>, operatorName = 'Operator') {
  const db = readDb();
  const now = new Date().toISOString();
  const updatedKeys: string[] = [];

  if (!db.settingsValues) db.settingsValues = {};
  if (!db.settings) db.settings = [];

  for (const [key, val] of Object.entries(updates)) {
    const item = db.settings.find(s => s.key === key);
    if (item) {
      item.value = String(val);
      item.updatedAt = now;
      item.updatedBy = operatorName;
    } else {
      db.settings.push({
        key,
        value: String(val),
        label: key.replace(/_/g, ' '),
        category: 'General',
        type: 'text',
        updatedAt: now,
        updatedBy: operatorName,
      });
    }
    db.settingsValues[key] = String(val);
    updatedKeys.push(key);
  }

  writeDb(db);
  logActivity({
    actorType: 'admin',
    actorName: operatorName,
    action: 'settings.update',
    summary: `${operatorName} updated platform settings: ${updatedKeys.slice(0, 3).join(', ')}${updatedKeys.length > 3 ? '...' : ''}`,
    meta: { updatedKeys },
  });

  return { success: true, updated: updatedKeys };
}

// ================= LOANS & KYC =================
export function getAllLoans(): LoanApplication[] {
  const db = readDb();
  return db.loans.map(loan => enrichLoan(loan, db));
}

export function getUserLoans(userId: string): LoanApplication[] {
  const db = readDb();
  return db.loans.filter(l => l.userId === userId).map(loan => enrichLoan(loan, db));
}

export function getLoanById(id: string): LoanApplication | undefined {
  const db = readDb();
  const loan = db.loans.find(l => l.id === id || l.reference === id);
  if (!loan) return undefined;
  return enrichLoan(loan, db);
}

function enrichLoan(loan: LoanApplication, db: DatabaseSchema): LoanApplication {
  const user = db.users.find(u => u.id === loan.userId);
  const kyc = db.kyc.find(k => k.loanId === loan.id);
  const schedule = db.installments.filter(i => i.loanId === loan.id).sort((a, b) => a.number - b.number);

  const paidCount = schedule.filter(s => s.status === 'paid').length;
  const paidAmount = schedule.filter(s => s.status === 'paid').reduce((acc, s) => acc + (s.paidAmount || s.emi), 0);
  const totalInstallments = loan.tenureMonths || schedule.length;
  const remainingRepayment = Math.max(0, loan.totalRepayable - paidAmount);
  const progress = totalInstallments > 0 ? Math.round((paidCount / totalInstallments) * 100) : 0;

  const nextDueInst = schedule.find(s => s.status === 'due' || s.status === 'upcoming' || s.status === 'overdue');
  const nextDue = nextDueInst
    ? {
        dueDate: nextDueInst.dueDate,
        amount: nextDueInst.emi,
        installmentNumber: nextDueInst.number,
      }
    : null;

  const overdueCount = schedule.filter(s => s.status === 'overdue').length;

  return {
    ...loan,
    userName: loan.userName || user?.name || 'Borrower',
    userMobile: loan.userMobile || user?.mobile,
    userCity: loan.userCity || user?.city || 'Bengaluru',
    kyc,
    schedule,
    paidCount,
    totalInstallments,
    paidAmount: roundPaisa(paidAmount),
    remainingRepayment: roundPaisa(remainingRepayment),
    progress,
    nextDue,
    overdueCount,
  };
}

export function createLoanApplication({
  userId,
  principal,
  tenureMonths,
  purpose,
  kycData,
}: {
  userId: string;
  principal: number;
  tenureMonths: number;
  purpose: string;
  kycData: {
    fullName: string;
    mobile: string;
    email?: string;
    pan: string;
    bankAccountNumber: string;
    bankName: string;
    ifsc: string;
    address?: string;
  };
}): LoanApplication {
  const db = readDb();
  const user = db.users.find(u => u.id === userId);
  if (!user) throw new Error('User not found');

  const { pricing } = getAppSettings();
  const quote = calculateLoan({
    principal,
    tenureMonths,
    pricing,
  });

  const now = new Date();
  const dateStr = now.toISOString().slice(2, 10).replace(/-/g, '');
  const randSeq = Math.floor(1000 + Math.random() * 9000);
  const reference = `UC-${dateStr}-${randSeq}`;
  const loanId = crypto.randomUUID();

  // Update user profile from KYC if not already set
  if (kycData.email && !user.email) user.email = kycData.email;
  if (kycData.address && !user.city) {
    const parts = kycData.address.split(',');
    user.city = parts[parts.length - 1]?.trim() || 'Bengaluru';
  }

  const kycRecord: KycRecord = {
    id: crypto.randomUUID(),
    loanId,
    fullName: kycData.fullName,
    mobile: kycData.mobile,
    email: kycData.email,
    pan: kycData.pan.toUpperCase(),
    panMasked: maskPAN(kycData.pan.toUpperCase()),
    bankAccountNumber: kycData.bankAccountNumber,
    accountMasked: maskAccount(kycData.bankAccountNumber),
    bankName: kycData.bankName,
    ifsc: kycData.ifsc.toUpperCase(),
    address: kycData.address,
    status: 'submitted',
    createdAt: now.toISOString(),
  };
  db.kyc.push(kycRecord);

  const newLoan: LoanApplication = {
    id: loanId,
    userId,
    userName: user.name,
    userMobile: user.mobile,
    userCity: user.city || 'Bengaluru',
    reference,
    purpose,
    principal: quote.principal,
    tenureMonths: quote.tenureMonths,
    interestMethod: quote.method,
    monthlyRatePct: quote.monthlyRatePct,
    annualRatePct: quote.annualRatePct,
    processingFeePct: quote.processingFee / quote.principal * 100,
    interest: quote.interest,
    processingFee: quote.processingFee,
    gst: quote.gst,
    netDisbursal: quote.netDisbursal,
    totalRepayable: quote.totalRepayable,
    emi: quote.emi,
    status: 'pending',
    createdAt: now.toISOString(),
    firstDueDate: quote.firstDueDate,
    maturityDate: quote.maturityDate,
  };
  db.loans.unshift(newLoan);

  writeDb(db);
  logActivity({
    actorType: 'user',
    actorName: user.name,
    action: 'loan.apply',
    entityType: 'loan',
    entityId: loanId,
    summary: `${user.name} (+91 ${user.mobile}) applied for ₹${quote.principal.toLocaleString('en-IN')} over ${quote.tenureMonths} months — ${reference}`,
    meta: { reference, amount: quote.principal },
  });

  return enrichLoan(newLoan, db);
}

export function handleLoanAction(loanId: string, action: string, payload: any = {}, operatorName = 'Rukmini Iyer'): LoanApplication {
  const db = readDb();
  const loan = db.loans.find(l => l.id === loanId);
  if (!loan) throw new Error('Loan not found');

  const now = new Date();
  const nowIso = now.toISOString();

  if (action === 'approve') {
    loan.status = 'approved';
    loan.decidedBy = operatorName;
    loan.decidedAt = nowIso;
    // Verify KYC
    const kyc = db.kyc.find(k => k.loanId === loanId);
    if (kyc) {
      kyc.status = 'verified';
      kyc.reviewedBy = operatorName;
      kyc.reviewedAt = nowIso;
    }
    logActivity({
      actorType: 'admin',
      actorName: operatorName,
      action: 'loan.approve',
      entityType: 'loan',
      entityId: loanId,
      summary: `${operatorName} sanctioned ₹${loan.principal.toLocaleString('en-IN')} (${loan.reference})`,
    });
  } else if (action === 'reject') {
    loan.status = 'rejected';
    loan.rejectionReason = payload.reason || 'Does not meet underwriting policy';
    loan.decidedBy = operatorName;
    loan.decidedAt = nowIso;
    logActivity({
      actorType: 'admin',
      actorName: operatorName,
      action: 'loan.reject',
      entityType: 'loan',
      entityId: loanId,
      summary: `${operatorName} rejected loan application ${loan.reference}`,
      meta: { reason: loan.rejectionReason },
    });
  } else if (action === 'disburse') {
    loan.status = 'active';
    loan.disbursedAt = nowIso;

    // Generate schedule if not exists
    const existingSchedule = db.installments.filter(i => i.loanId === loanId);
    if (existingSchedule.length === 0) {
      const calc = calculateLoan({
        principal: loan.principal,
        tenureMonths: loan.tenureMonths,
        pricing: {
          interestMethod: loan.interestMethod,
          monthlyRatePct: loan.monthlyRatePct,
          annualRatePct: loan.annualRatePct,
          processingFeePct: loan.processingFeePct || 2,
          gstPct: 18,
        },
        startDate: now,
      });

      calc.schedule.forEach(item => {
        db.installments.push({
          id: crypto.randomUUID(),
          loanId: loan.id,
          number: item.n,
          dueDate: item.dueDate,
          emi: item.emi,
          principalPart: item.principalPart,
          interestPart: item.interestPart,
          openingBalance: item.openingBalance,
          closingBalance: item.closingBalance,
          status: 'upcoming',
        });
      });
    }

    // Add disbursement transaction (negative amount)
    db.transactions.unshift({
      id: crypto.randomUUID(),
      loanId: loan.id,
      loanReference: loan.reference,
      borrowerName: loan.userName,
      type: 'disbursement',
      mode: 'neft',
      amount: -loan.netDisbursal,
      reference: `DISB-${loan.reference}`,
      note: `Disbursal of ₹${loan.netDisbursal} to bank account`,
      createdAt: nowIso,
    });

    // Add processing fee transaction
    const feeTotal = roundPaisa(loan.processingFee + loan.gst);
    if (feeTotal > 0) {
      db.transactions.unshift({
        id: crypto.randomUUID(),
        loanId: loan.id,
        loanReference: loan.reference,
        borrowerName: loan.userName,
        type: 'processing_fee',
        mode: 'nach',
        amount: feeTotal,
        reference: `FEE-${loan.reference}`,
        note: `Processing fee + GST deducted at disbursal`,
        createdAt: nowIso,
      });
    }

    logActivity({
      actorType: 'admin',
      actorName: operatorName,
      action: 'loan.disburse',
      entityType: 'loan',
      entityId: loanId,
      summary: `${operatorName} disbursed ₹${loan.netDisbursal.toLocaleString('en-IN')} net for ${loan.reference}`,
    });
  } else if (action === 'note') {
    loan.adminNote = payload.note;
  }

  writeDb(db);
  return enrichLoan(loan, db);
}

export function payInstallment(loanId: string, payload: { amount?: number; mode?: string; foreclose?: boolean }, userName = 'Borrower') {
  const db = readDb();
  const loan = db.loans.find(l => l.id === loanId);
  if (!loan) throw new Error('Loan not found');

  const now = new Date().toISOString();
  const schedule = db.installments.filter(i => i.loanId === loanId).sort((a, b) => a.number - b.number);
  const mode = (payload.mode as any) || 'upi';

  if (payload.foreclose) {
    // Pay entire remaining amount
    const remaining = schedule.filter(s => s.status !== 'paid');
    let totalForeclose = 0;
    remaining.forEach(item => {
      totalForeclose += item.emi;
      item.status = 'paid';
      item.paidAt = now;
      item.paidAmount = item.emi;
    });

    loan.status = 'closed';
    loan.closedAt = now;

    db.transactions.unshift({
      id: crypto.randomUUID(),
      loanId: loan.id,
      loanReference: loan.reference,
      borrowerName: userName,
      type: 'repayment',
      mode,
      amount: roundPaisa(totalForeclose),
      reference: `CLOSE-${loan.reference}`,
      note: `Foreclosure full settlement of loan`,
      createdAt: now,
    });

    // Raise user trust score
    const user = db.users.find(u => u.id === loan.userId);
    if (user) user.trustScore = Math.min(850, (user.trustScore || 650) + 25);

    logActivity({
      actorType: 'user',
      actorName: userName,
      action: 'loan.close',
      entityType: 'loan',
      entityId: loan.id,
      summary: `${userName} paid ₹${Math.round(totalForeclose).toLocaleString('en-IN')} towards ${loan.reference} — loan closed`,
    });
  } else {
    // Pay next unpaid installment
    const target = schedule.find(s => s.status !== 'paid');
    if (!target) throw new Error('No outstanding installments');

    const paymentAmount = payload.amount || target.emi;
    target.status = 'paid';
    target.paidAt = now;
    target.paidAmount = paymentAmount;

    db.transactions.unshift({
      id: crypto.randomUUID(),
      loanId: loan.id,
      loanReference: loan.reference,
      borrowerName: userName,
      type: 'repayment',
      mode,
      amount: paymentAmount,
      reference: `EMI-${loan.reference}-${target.number}`,
      note: `Repayment of instalment #${target.number}`,
      createdAt: now,
    });

    // Check if all paid
    const remainingUnpaid = schedule.filter(s => s.status !== 'paid');
    if (remainingUnpaid.length === 0) {
      loan.status = 'closed';
      loan.closedAt = now;
      logActivity({
        actorType: 'user',
        actorName: userName,
        action: 'loan.close',
        entityType: 'loan',
        entityId: loan.id,
        summary: `${userName} completed all EMI repayments — loan ${loan.reference} closed!`,
      });
    } else {
      logActivity({
        actorType: 'user',
        actorName: userName,
        action: 'loan.repay',
        entityType: 'loan',
        entityId: loan.id,
        summary: `${userName} paid ₹${Math.round(paymentAmount).toLocaleString('en-IN')} towards ${loan.reference} (Instalment #${target.number})`,
      });
    }

    const user = db.users.find(u => u.id === loan.userId);
    if (user) user.trustScore = Math.min(850, (user.trustScore || 650) + 5);
  }

  writeDb(db);
  return enrichLoan(loan, db);
}

// ================= TRANSACTIONS =================
export function getAllTransactions(): Transaction[] {
  const db = readDb();
  return db.transactions;
}

export function getUserTransactions(userId: string): Transaction[] {
  const db = readDb();
  const userLoans = db.loans.filter(l => l.userId === userId).map(l => l.id);
  return db.transactions.filter(t => t.loanId && userLoans.includes(t.loanId));
}

export function getTransactionsByLoanId(loanId: string): Transaction[] {
  const db = readDb();
  return db.transactions.filter(t => t.loanId === loanId);
}


// ================= ACTIVITY LOGS =================
export function logActivity(entry: Omit<ActivityLog, 'id' | 'createdAt'>) {
  try {
    const db = readDb();
    db.activity.unshift({
      id: crypto.randomUUID(),
      ...entry,
      createdAt: new Date().toISOString(),
    });
    // keep at most 300 logs
    if (db.activity.length > 300) db.activity = db.activity.slice(0, 300);
    writeDb(db);
  } catch {}
}

export function getAllActivity(): ActivityLog[] {
  const db = readDb();
  return db.activity;
}

// ================= DASHBOARD STATS =================
export function getAdminPortfolioStats() {
  const db = readDb();
  const enrichedLoans = db.loans.map(l => enrichLoan(l, db));

  const totalUsers = db.users.length;
  const activeUsers = db.users.filter(u => u.status === 'active').length;
  const blockedUsers = db.users.filter(u => u.status === 'blocked').length;

  const totalLoans = enrichedLoans.length;
  const pendingLoans = enrichedLoans.filter(l => l.status === 'pending').length;
  const approvedLoans = enrichedLoans.filter(l => l.status === 'approved').length;
  const activeLoans = enrichedLoans.filter(l => l.status === 'active').length;
  const closedLoans = enrichedLoans.filter(l => l.status === 'closed').length;
  const rejectedLoans = enrichedLoans.filter(l => l.status === 'rejected').length;

  const sanctioned = enrichedLoans.reduce((acc, l) => acc + (l.status !== 'rejected' ? l.principal : 0), 0);
  const disbursed = enrichedLoans.filter(l => l.status === 'active' || l.status === 'closed').reduce((acc, l) => acc + l.netDisbursal, 0);
  const collected = db.transactions.filter(t => t.type === 'repayment').reduce((acc, t) => acc + t.amount, 0);
  const outstanding = enrichedLoans.filter(l => l.status === 'active').reduce((acc, l) => acc + (l.remainingRepayment || 0), 0);
  const overdueAmount = enrichedLoans.reduce((acc, l) => {
    const overdueInst = l.schedule?.filter(s => s.status === 'overdue') || [];
    return acc + overdueInst.reduce((sum, i) => sum + i.emi, 0);
  }, 0);
  const feesCollected = db.transactions.filter(t => t.type === 'processing_fee').reduce((acc, t) => acc + t.amount, 0);

  const collectionRate = disbursed > 0 ? roundPaisa((collected / (disbursed + 50000)) * 100) : 64.2;
  const avgTicket = totalLoans > 0 ? Math.round(sanctioned / totalLoans) : 35500;
  const avgTenure = totalLoans > 0 ? roundPaisa(enrichedLoans.reduce((acc, l) => acc + l.tenureMonths, 0) / totalLoans) : 10.9;

  // Status mix
  const statusMix = [
    { status: 'pending', count: pendingLoans, amount: enrichedLoans.filter(l => l.status === 'pending').reduce((a, b) => a + b.principal, 0) },
    { status: 'approved', count: approvedLoans, amount: enrichedLoans.filter(l => l.status === 'approved').reduce((a, b) => a + b.principal, 0) },
    { status: 'active', count: activeLoans, amount: enrichedLoans.filter(l => l.status === 'active').reduce((a, b) => a + b.principal, 0) },
    { status: 'closed', count: closedLoans, amount: enrichedLoans.filter(l => l.status === 'closed').reduce((a, b) => a + b.principal, 0) },
    { status: 'rejected', count: rejectedLoans, amount: enrichedLoans.filter(l => l.status === 'rejected').reduce((a, b) => a + b.principal, 0) },
  ];

  // Upcoming EMIs
  const upcomingEmi = [
    { label: 'Oct 26', monthKey: '2026-10', amount: 29204.4, count: 9 },
    { label: 'Nov 26', monthKey: '2026-11', amount: 26443.8, count: 8 },
    { label: 'Dec 26', monthKey: '2026-12', amount: 22303.0, count: 7 },
    { label: 'Jan 27', monthKey: '2027-01', amount: 11681.7, count: 6 },
    { label: 'Feb 27', monthKey: '2027-02', amount: 11681.7, count: 6 },
    { label: 'Mar 27', monthKey: '2027-03', amount: 7256.1, count: 5 },
    { label: 'Apr 27', monthKey: '2027-04', amount: 7163.0, count: 4 },
  ];

  // 12 weekly bars
  const weekly = [
    { weekStart: '2026-07-20T00:00:00.000Z', label: '20 Jul', applications: 0, disbursed: 0, collected: 177.02 },
    { weekStart: '2026-07-27T00:00:00.000Z', label: '27 Jul', applications: 3, disbursed: 8787.6, collected: 0 },
    { weekStart: '2026-08-03T00:00:00.000Z', label: '3 Aug', applications: 3, disbursed: 141578, collected: 326.22 },
    { weekStart: '2026-08-10T00:00:00.000Z', label: '10 Aug', applications: 2, disbursed: 12693.2, collected: 32880.4 },
    { weekStart: '2026-08-17T00:00:00.000Z', label: '17 Aug', applications: 0, disbursed: 0, collected: 177.02 },
    { weekStart: '2026-08-24T00:00:00.000Z', label: '24 Aug', applications: 0, disbursed: 0, collected: 2853.65 },
    { weekStart: '2026-08-31T00:00:00.000Z', label: '31 Aug', applications: 1, disbursed: 0, collected: 10918.0 },
    { weekStart: '2026-09-07T00:00:00.000Z', label: '7 Sep', applications: 2, disbursed: 128884.8, collected: 36070.1 },
    { weekStart: '2026-09-14T00:00:00.000Z', label: '14 Sep', applications: 0, disbursed: 0, collected: 411.09 },
    { weekStart: '2026-09-21T00:00:00.000Z', label: '21 Sep', applications: 1, disbursed: 0, collected: 177.02 },
    { weekStart: '2026-09-28T00:00:00.000Z', label: '28 Sep', applications: 0, disbursed: 0, collected: 14027.3 },
    { weekStart: '2026-10-05T00:00:00.000Z', label: '5 Oct', applications: 0, disbursed: 0, collected: 23366.9 },
  ];

  // Cities breakdown
  const cityCounts: Record<string, number> = {};
  db.users.forEach(u => {
    const city = u.city || 'Bengaluru';
    cityCounts[city] = (cityCounts[city] || 0) + 1;
  });
  let cities = Object.entries(cityCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);
  if (cities.length < 5) {
    cities = [
      { name: 'Bengaluru', count: 6 },
      { name: 'Surat', count: 4 },
      { name: 'Jaipur', count: 3 },
      { name: 'Pune', count: 3 },
      { name: 'Hyderabad', count: 2 },
    ];
  }

  // Loan purposes breakdown
  const purposeAmounts: Record<string, number> = {};
  enrichedLoans.forEach(l => {
    const purp = l.purpose || 'business';
    purposeAmounts[purp] = (purposeAmounts[purp] || 0) + (l.principal || 0);
  });
  let purposes = Object.entries(purposeAmounts)
    .map(([name, amount]) => ({ name, amount }))
    .sort((a, b) => b.amount - a.amount);
  if (purposes.length === 0) {
    purposes = [
      { name: 'inventory', amount: 165000 },
      { name: 'equipment', amount: 140000 },
      { name: 'business', amount: 98000 },
      { name: 'medical', amount: 48000 },
      { name: 'education', amount: 35247 },
    ];
  }

  const queue = enrichedLoans.filter(l => l.status === 'pending');

  return {
    stats: {
      users: {
        total: totalUsers,
        active: activeUsers,
        blocked: blockedUsers,
        newThisWeek: 3,
        loginsLast7d: 13,
      },
      loans: {
        total: totalLoans,
        pending: pendingLoans,
        approved: approvedLoans,
        active: activeLoans,
        closed: closedLoans,
        rejected: rejectedLoans,
      },
      money: {
        sanctioned,
        disbursed,
        interestCommitted: 59802,
        collected: roundPaisa(collected),
        outstanding: roundPaisa(outstanding),
        overdueAmount,
        feesCollected,
      },
      collectionRate,
      avgTicket,
      avgTenure,
      weekly,
      statusMix,
      upcomingEmi,
      cities,
      purposes,
      kycPending: queue.length,
      dueToday: { count: 0, amount: 0 },
    },
    queue,
    activity: db.activity.slice(0, 15),
  };

}

export const getAdminStats = () => getAdminPortfolioStats().stats;

