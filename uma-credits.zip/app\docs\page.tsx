import React from 'react';
import Link from 'next/link';
import { SiteHeader, AnnouncementTicker } from '@/components/home/hero';
import { SiteFooter } from '@/components/home/sections';
import { getCurrentUser } from '@/lib/auth';
import { IconArrow } from '@/components/icons';

export default function DocsPage() {
  const user = getCurrentUser();

  const schemaTables = [
    {
      name: 'users',
      desc: 'One row per person who has ever logged in. Identity = mobile number.',
      cols: [
        { name: 'id', type: 'uuid pk' },
        { name: 'name', type: 'varchar(90)' },
        { name: 'mobile', type: 'varchar(15) unique — the only credential' },
        { name: 'email, city, occupation', type: 'profile, filled from KYC' },
        { name: 'status', type: "enum('active','blocked') — admin controlled" },
        { name: 'block_reason', type: 'text, shown to support' },
        { name: 'trust_score', type: 'int, raised on every clean disbursal' },
        { name: 'login_count, last_login_at', type: 'session telemetry' },
      ],
    },
    {
      name: 'admins',
      desc: 'Back-office operators. Passwords are scrypt hashes, never plaintext.',
      cols: [
        { name: 'id / username', type: 'uuid pk / varchar unique' },
        { name: 'password_hash', type: 'salt:scrypt(64) — timing-safe compare' },
        { name: 'name, role', type: 'owner | reviewer' },
        { name: 'last_login_at', type: 'audit' },
      ],
    },
    {
      name: 'sessions',
      desc: 'One table, two subject types — keeps user and admin cookies revocable server-side.',
      cols: [
        { name: 'token', type: 'varchar(96) unique, 32 random bytes hex' },
        { name: 'subject_type', type: "'user' | 'admin'" },
        { name: 'subject_id', type: 'uuid → users.id or admins.id' },
        { name: 'expires_at', type: '30 days, httpOnly + sameSite=lax cookie' },
        { name: 'user_agent, ip', type: 'forensics' },
      ],
    },
    {
      name: 'loan_applications',
      desc: 'The contract. Rates are snapshotted here so a settings change never rewrites history.',
      cols: [
        { name: 'reference', type: 'unique human key, e.g. UC-260214-1042' },
        { name: 'principal, tenure_months', type: 'the ask' },
        { name: 'interest_method', type: 'reducing | flat (frozen)' },
        { name: 'monthly_rate_pct, annual_rate_pct, processing_fee_pct', type: 'frozen from settings' },
        { name: 'interest, processing_fee, gst, net_disbursal', type: 'computed at application time' },
        { name: 'emi, total_repayable', type: 'sanction figures' },
        { name: 'status', type: 'pending → approved → active → closed | rejected' },
        { name: 'decided_by, decided_at, disbursed_at, closed_at', type: 'lifecycle stamps' },
        { name: 'first_due_date, maturity_date', type: 'timeline' },
      ],
    },
    {
      name: 'kyc_records',
      desc: 'The popup KYC form, exactly as submitted. Masked in every list view.',
      cols: [
        { name: 'loan_id', type: 'unique fk → loan_applications' },
        { name: 'full_name, mobile, email', type: 'identity' },
        { name: 'pan', type: 'varchar(12), validated ^[A-Z]{5}[0-9]{4}[A-Z]$' },
        { name: 'bank_account_number, bank_name, ifsc', type: 'disbursal target' },
        { name: 'status', type: 'submitted → verified | rejected' },
        { name: 'reviewed_by, reviewed_at, remark', type: 'underwriter trail' },
      ],
    },
    {
      name: 'installments',
      desc: 'Amortisation schedule, generated on disbursal from the frozen rate.',
      cols: [
        { name: 'loan_id, number', type: 'fk + ordinal' },
        { name: 'emi, principal_part, interest_part', type: 'the split' },
        { name: 'opening_balance, closing_balance', type: 'reducing-balance trail' },
        { name: 'due_date', type: 'monthly from disbursal' },
        { name: 'status', type: 'upcoming → due → paid | overdue' },
        { name: 'paid_at, paid_amount, late_fee', type: 'settlement' },
      ],
    },
    {
      name: 'transactions',
      desc: 'Immutable money ledger — what borrowers and auditors both read.',
      cols: [
        { name: 'type', type: 'disbursement | processing_fee | repayment | late_fee | refund' },
        { name: 'mode', type: 'upi | neft | nach | cash | card' },
        { name: 'amount', type: 'signed numeric(14,2) — outflows are negative' },
        { name: 'loan_id, installment_id, reference, note', type: 'traceability' },
      ],
    },
    {
      name: 'app_settings',
      desc: '50 typed key/value rows that drive the entire website — brand, rates, tenures, copy, FAQ, stories.',
      cols: [
        { name: 'key', type: 'varchar pk, e.g. monthly_interest_pct' },
        { name: 'value', type: 'text (numbers/booleans/JSON are parsed on read)' },
        { name: 'label, category, type', type: 'renders the admin form automatically' },
        { name: 'options', type: 'jsonb for select fields' },
        { name: 'is_public', type: '0 → never sent to the browser' },
        { name: 'updated_by, updated_at', type: 'who changed the site last' },
      ],
    },
    {
      name: 'activity_logs',
      desc: 'Audit trail for every sanction, rejection, disbursal, block and settings edit.',
      cols: [
        { name: 'actor_type, actor_name', type: 'admin | user | system' },
        { name: 'action', type: 'loan.approve, user.block, settings.update, …' },
        { name: 'entity_type, entity_id', type: 'what it touched' },
        { name: 'summary, meta', type: 'human line + jsonb payload' },
      ],
    },
  ];

  const apiEndpoints = [
    { method: 'POST', route: '/api/auth/login', guard: 'public', desc: 'Name + mobile → upsert borrower, issue httpOnly session cookie' },
    { method: 'POST', route: '/api/auth/logout', guard: 'user', desc: 'Delete the session row and clear the cookie' },
    { method: 'GET', route: '/api/me', guard: 'user', desc: 'Profile + settings + pricing + every loan with schedule and ledger' },
    { method: 'GET', route: '/api/settings', guard: 'public', desc: 'Public settings payload consumed by SettingsProvider' },
    { method: 'GET', route: '/api/loans/quote', guard: 'public', desc: 'Server-authoritative breakdown for amount + tenure' },
    { method: 'GET', route: '/api/loans', guard: 'user', desc: 'My loan book' },
    { method: 'POST', route: '/api/loans', guard: 'user', desc: 'Create application + KYC record → lands in the admin queue' },
    { method: 'GET', route: '/api/loans/[id]', guard: 'user', desc: 'Sanction letter, schedule and ledger for one loan' },
    { method: 'POST', route: '/api/loans/[id]/pay', guard: 'user', desc: 'Pay one instalment or foreclose; closes the loan when settled' },
    { method: 'POST', route: '/api/loans/[id]/cancel', guard: 'user', desc: 'Withdraw an application that is still pending' },
    { method: 'POST', route: '/api/admin/login', guard: 'public', desc: 'Username + password → admin session cookie' },
    { method: 'POST', route: '/api/admin/logout', guard: 'admin', desc: 'End the operator session' },
    { method: 'GET', route: '/api/admin/stats', guard: 'admin', desc: 'Portfolio aggregates, weekly series, mix, queue, audit feed' },
    { method: 'GET', route: '/api/admin/users', guard: 'admin', desc: 'Searchable borrower list with portfolio roll-ups' },
    { method: 'GET', route: '/api/admin/users/[id]', guard: 'admin', desc: 'Full borrower file: loans, KYC (unmasked), ledger' },
    { method: 'PATCH', route: '/api/admin/users/[id]', guard: 'admin', desc: 'block / unblock — blocking deletes their sessions' },
    { method: 'GET', route: '/api/admin/applications', guard: 'admin', desc: 'Filterable application queue with KYC joined' },
    { method: 'GET', route: '/api/admin/applications/[id]', guard: 'admin', desc: 'Single application file' },
    { method: 'PATCH', route: '/api/admin/applications/[id]', guard: 'admin', desc: 'approve · reject · disburse · note' },
    { method: 'GET', route: '/api/admin/settings', guard: 'admin', desc: 'Every setting with metadata + defaults' },
    { method: 'PUT', route: '/api/admin/settings', guard: 'admin', desc: 'Publish changes (validated per type) + audit log entry' },
    { method: 'GET', route: '/api/admin/ledger', guard: 'admin', desc: 'Money register across all borrowers, with totals' },
    { method: 'GET', route: '/api/admin/activity', guard: 'admin', desc: 'Audit trail feed' },
    { method: 'GET', route: '/api/admin/export', guard: 'admin', desc: 'CSV export: applications · users · kyc' },
  ];

  return (
    <main className="relative">
      <AnnouncementTicker />
      <SiteHeader user={user} />

      <section className="paper-dark noise relative overflow-hidden text-paper">
        <div className="relative mx-auto max-w-[1100px] px-5 pb-14 pt-14 lg:px-8">
          <span className="font-mono text-[11px] uppercase tracking-[0.24em] text-haldi">Engineering notes</span>
          <h1 className="mt-4 max-w-3xl font-display text-[clamp(2.2rem,5.6vw,4rem)] font-black leading-[0.98]">
            How this lending platform is wired, end to end.
          </h1>
          <p className="mt-5 max-w-2xl text-[15px] leading-relaxed text-paper/70">
            Next.js App Router + File-backed Atomic Database. One schema, one settings table that drives the whole UI, cookie-backed sessions for both borrowers and operators, and an audit trail on every consequential write.
          </p>

          <div className="mt-8 flex flex-wrap gap-2.5">
            {['Next.js 14 App Router', 'React 18', 'Tailwind CSS', 'Atomic JSON DB', 'Scrypt Sessions', 'Zero client-side rate maths'].map(tag => (
              <span key={tag} className="rounded-full border border-paper/20 px-3.5 py-1.5 font-mono text-[11px] uppercase tracking-[0.14em] text-paper/70">
                {tag}
              </span>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto grid max-w-[1100px] gap-10 px-5 py-16 lg:grid-cols-[210px_1fr] lg:px-8">
        <nav className="lg:sticky lg:top-24 lg:self-start">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">On this page</p>
          <ul className="mt-3 grid gap-1.5">
            <li><a href="#flow" className="link-draw text-[13px] font-semibold text-ink-2 hover:text-brand">Request flow</a></li>
            <li><a href="#schema" className="link-draw text-[13px] font-semibold text-ink-2 hover:text-brand">Database schema</a></li>
            <li><a href="#api" className="link-draw text-[13px] font-semibold text-ink-2 hover:text-brand">Backend API</a></li>
            <li><a href="#frontend" className="link-draw text-[13px] font-semibold text-ink-2 hover:text-brand">Frontend structure</a></li>
            <li><a href="#state" className="link-draw text-[13px] font-semibold text-ink-2 hover:text-brand">State management</a></li>
          </ul>

          <Link href="/" className="mt-6 inline-flex items-center gap-2 text-[13px] font-semibold text-accent link-draw">
            Back to the site <IconArrow width={14} height={14} />
          </Link>
        </nav>

        <div className="grid gap-16">
          {/* Request Flow */}
          <section id="flow" className="scroll-mt-24">
            <span className="font-mono text-[11px] uppercase tracking-[0.24em] text-accent">Request flow</span>
            <h2 className="mt-3 font-display text-[clamp(1.7rem,3.4vw,2.4rem)] font-bold leading-tight">
              One loan, from slider to closed ledger.
            </h2>

            <ol className="mt-7 grid gap-3">
              {[
                { actor: 'Borrower', tone: 'teal', text: 'Logs in with Name + Mobile → POST /api/auth/login upserts users and issues a session cookie.' },
                { actor: 'Borrower', tone: 'teal', text: 'Moves the slider → GET /api/loans/quote prices it server-side with the current settings.' },
                { actor: 'Borrower', tone: 'teal', text: 'Opens the KYC popup → POST /api/loans writes loan_applications + kyc_records with a frozen rate snapshot.' },
                { actor: 'Admin', tone: 'gold', text: 'Sees it in the queue → PATCH approve verifies KYC and stamps the sanction.' },
                { actor: 'Admin', tone: 'gold', text: 'PATCH disburse generates installments, writes the disbursal + fee ledger rows and flips status to active.' },
                { actor: 'Borrower', tone: 'teal', text: 'Pays an EMI → POST /api/loans/[id]/pay settles the instalment; when the last one clears, the loan closes.' },
                { actor: 'Admin', tone: 'gold', text: "Every step above is written to activity_logs with the operator's name." },
              ].map((step, idx) => (
                <li key={idx} className="ledger-row flex items-start gap-4 rounded-xl border border-ink/12 bg-[#fffaf1] px-5 py-4">
                  <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-brand font-mono text-[11px] text-paper">
                    {idx + 1}
                  </span>
                  <div>
                    <span className={`inline-block rounded px-2 py-0.5 font-mono text-[10px] font-bold uppercase tracking-wider ${
                      step.tone === 'teal' ? 'bg-brand/12 text-brand' : 'bg-haldi/20 text-[#8a5d0d]'
                    }`}>
                      {step.actor}
                    </span>
                    <span className="mt-2 block text-[13.5px] leading-relaxed text-ink-2">{step.text}</span>
                  </div>
                </li>
              ))}
            </ol>
          </section>

          {/* Database Schema */}
          <section id="schema" className="scroll-mt-24">
            <span className="font-mono text-[11px] uppercase tracking-[0.24em] text-accent">Database schema</span>
            <h2 className="mt-3 font-display text-[clamp(1.7rem,3.4vw,2.4rem)] font-bold leading-tight">
              Nine tables, one source of truth.
            </h2>

            <div className="mt-7 grid gap-5">
              {schemaTables.map(t => (
                <div key={t.name} className="overflow-hidden rounded-[18px] border border-ink/12 bg-[#fffaf1] shadow-sm">
                  <div className="flex flex-wrap items-center gap-3 border-b border-ink/10 bg-paper-2/50 px-5 py-4">
                    <code className="font-mono text-[15px] font-bold text-ink">{t.name}</code>
                    <span className="text-[12.5px] text-ink-3">{t.desc}</span>
                  </div>
                  <dl className="grid gap-px bg-ink/8 sm:grid-cols-2">
                    {t.cols.map(c => (
                      <div key={c.name} className="bg-[#fffaf1] px-5 py-2.5">
                        <dt className="font-mono text-[12px] font-semibold text-brand">{c.name}</dt>
                        <dd className="mt-0.5 text-[12px] text-ink-3">{c.type}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
              ))}
            </div>
          </section>

          {/* Backend API */}
          <section id="api" className="scroll-mt-24">
            <span className="font-mono text-[11px] uppercase tracking-[0.24em] text-accent">Backend architecture</span>
            <h2 className="mt-3 font-display text-[clamp(1.7rem,3.4vw,2.4rem)] font-bold leading-tight">
              24 route handlers under /api.
            </h2>

            <div className="mt-7 overflow-hidden rounded-[18px] border border-ink/12 bg-[#fffaf1] shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-paper-2/50 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">
                      <th className="px-5 py-3">Method</th>
                      <th className="px-5 py-3">Route</th>
                      <th className="px-5 py-3">Guard</th>
                      <th className="px-5 py-3">What it does</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink/10 text-[13px]">
                    {apiEndpoints.map(e => (
                      <tr key={`${e.method}-${e.route}`} className="ledger-row hover:bg-paper-2/40">
                        <td className="px-5 py-3">
                          <span className={`rounded-md px-2 py-1 font-mono text-[10.5px] font-semibold ${
                            e.method === 'POST' ? 'bg-moss/14 text-moss' : e.method === 'PATCH' || e.method === 'PUT' ? 'bg-accent/14 text-accent' : 'bg-brand/12 text-brand'
                          }`}>
                            {e.method}
                          </span>
                        </td>
                        <td className="px-5 py-3 font-mono text-[12.5px] text-ink font-semibold">{e.route}</td>
                        <td className="px-5 py-3">
                          <span className={`rounded px-2 py-0.5 font-mono text-[10px] uppercase font-bold ${
                            e.guard === 'public' ? 'bg-ink/10 text-ink-3' : e.guard === 'admin' ? 'bg-haldi/20 text-[#8a5d0d]' : 'bg-brand/12 text-brand'
                          }`}>
                            {e.guard}
                          </span>
                        </td>
                        <td className="px-5 py-3 text-[12.5px] text-ink-3">{e.desc}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* Frontend Structure */}
          <section id="frontend" className="scroll-mt-24">
            <span className="font-mono text-[11px] uppercase tracking-[0.24em] text-accent">Frontend structure</span>
            <h2 className="mt-3 font-display text-[clamp(1.7rem,3.4vw,2.4rem)] font-bold leading-tight">
              Server components for data, client components for feel.
            </h2>

            <div className="mt-7 grid gap-5">
              <div className="rounded-[18px] border border-ink/12 bg-[#fffaf1] p-6 shadow-sm">
                <h3 className="font-display text-[19px] font-bold">Borrower flow</h3>
                <dl className="mt-4 grid gap-2">
                  {[
                    { f: 'app/page.tsx', d: 'Landing — hero, live calculator, stories, rate board, FAQ' },
                    { f: 'components/home/hero.tsx', d: 'Hero + LoginSlip (Name + Mobile) with stamp animation' },
                    { f: 'components/home/sections.tsx', d: 'HowItWorks, LiveCalculator, Stories, RateBoard, Faq, CtaBand' },
                    { f: 'app/dashboard/page.tsx', d: 'Server-rendered ledger; redirects to /#login when signed out' },
                    { f: 'components/dashboard/dashboard-client.tsx', d: 'KPIs, next-due card, loan cards, pay modal, ledger' },
                    { f: 'app/apply/page.tsx', d: 'Application flow with sticky breakdown' },
                    { f: 'components/apply/apply-client.tsx', d: 'Amount + tenure + KYC popup + success stamp' },
                  ].map(row => (
                    <div key={row.f} className="grid gap-1 border-b border-ink/8 pb-2 last:border-0 sm:grid-cols-[260px_1fr]">
                      <dt className="font-mono text-[12px] text-accent font-semibold">{row.f}</dt>
                      <dd className="text-[13px] text-ink-2">{row.d}</dd>
                    </div>
                  ))}
                </dl>
              </div>

              <div className="rounded-[18px] border border-ink/12 bg-[#fffaf1] p-6 shadow-sm">
                <h3 className="font-display text-[19px] font-bold">Admin panel</h3>
                <dl className="mt-4 grid gap-2">
                  {[
                    { f: 'app/admin/page.tsx', d: 'Operator sign-in' },
                    { f: 'app/admin/(panel)/layout.tsx', d: 'Session guard + shell + pending badge' },
                    { f: 'admin/dashboard', d: 'KPIs, 12-week bars, donut, upcoming EMIs, queue, audit' },
                    { f: 'admin/applications', d: 'Underwriting desk with inline sanction / reject / disburse' },
                    { f: 'admin/users', d: 'Registry, search, file drawer, block / unblock' },
                    { f: 'admin/ledger · admin/activity', d: 'Money register and audit trail' },
                    { f: 'admin/settings', d: 'Typed editor for all site configuration + live preview' },
                  ].map(row => (
                    <div key={row.f} className="grid gap-1 border-b border-ink/8 pb-2 last:border-0 sm:grid-cols-[260px_1fr]">
                      <dt className="font-mono text-[12px] text-accent font-semibold">{row.f}</dt>
                      <dd className="text-[13px] text-ink-2">{row.d}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>
          </section>

          {/* State Management */}
          <section id="state" className="scroll-mt-24">
            <span className="font-mono text-[11px] uppercase tracking-[0.24em] text-accent">State management</span>
            <h2 className="mt-3 font-display text-[clamp(1.7rem,3.4vw,2.4rem)] font-bold leading-tight">
              How an admin edit reaches the borrower’s screen.
            </h2>

            <div className="mt-7 grid gap-5 lg:grid-cols-2">
              {[
                { title: '1 · Read at the edge', body: 'getAppSettings() reads app_settings. Defaults are merged underneath, so a missing row can never break a page.' },
                { title: '2 · Hydrate the client', body: 'The root layout passes the public subset into SettingsProvider as initial, so the first paint already carries the right brand, rate and copy — no flash, no waterfall.' },
                { title: '3 · One context, many readers', body: 'useSettings() exposes settings (raw map), pricing (typed numbers), parsed (JSON arrays for steps, FAQ, stories), text()/num() helpers and refresh(). Nothing prop-drills configuration.' },
                { title: '4 · Theme as CSS variables', body: 'theme_primary and theme_accent are written onto <style> as --brand-primary / --brand-accent. Tailwind tokens reference those vars, so bg-brand and text-accent repaint everywhere at once.' },
                { title: '5 · Publish without a deploy', body: 'PUT /api/admin/settings validates per type, updates data/db.json, writes an audit entry and returns the fresh set. The editor then calls refresh().' },
                { title: '6 · Cross-tab propagation', body: 'A successful save fires a settings:bump window event; every open tab (including a borrower tab) revalidates and re-prices instantly.' },
                { title: '7 · Server stays authoritative', body: 'The browser never computes a sanction figure. Every quote, EMI and schedule comes from /api/loans/quote or the row snapshot, so the client cannot forge its own rate.' },
                { title: '8 · Local state where it belongs', body: 'Forms, modals, toasts and table filters live in component state; async mutations go through standard fetch API wrappers.' },
              ].map(item => (
                <div key={item.title} className="rounded-[18px] border border-ink/12 bg-[#fffaf1] p-6 shadow-sm">
                  <h3 className="font-display text-[17.5px] font-bold text-brand">{item.title}</h3>
                  <p className="mt-2.5 text-[13.5px] leading-relaxed text-ink-2">{item.body}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>

      <SiteFooter />
    </main>
  );
}
