import { NextRequest, NextResponse } from 'next/server';
import { getAllLoans, getAllUsers } from '@/lib/db';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const what = searchParams.get('what') || 'applications';

  if (what === 'users') {
    const users = getAllUsers();
    let csv = 'ID,Name,Mobile,City,Status,TrustScore,CreatedAt\n';
    users.forEach(u => {
      csv += `"${u.id}","${u.name}","${u.mobile}","${u.city || ''}","${u.status}",${u.trustScore},"${u.createdAt}"\n`;
    });
    return new Response(csv, {
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename="users.csv"',
      },
    });
  }

  const loans = getAllLoans();
  let csv = 'Reference,BorrowerName,Mobile,Principal,TenureMonths,EMI,TotalRepayable,NetDisbursal,Status,CreatedAt\n';
  loans.forEach(l => {
    csv += `"${l.reference}","${l.userName}","${l.userMobile}",${l.principal},${l.tenureMonths},${l.emi},${l.totalRepayable},${l.netDisbursal},"${l.status}","${l.createdAt}"\n`;
  });

  return new Response(csv, {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="loan_applications.csv"',
    },
  });
}
