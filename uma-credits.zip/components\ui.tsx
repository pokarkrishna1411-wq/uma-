'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { IconAlert, IconCheck, IconCross } from '@/components/icons';

// Formatter and utility functions
const inrFmt = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  maximumFractionDigits: 0,
});

const inrExactFmt = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const numFmt = new Intl.NumberFormat('en-IN', {
  maximumFractionDigits: 0,
});

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function fmtDate(val: any): string {
  if (!val) return '—';
  const d = typeof val === 'string' ? new Date(val) : val;
  if (isNaN(d.getTime())) return '—';
  return `${String(d.getDate()).padStart(2, '0')} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

export function fmtDateTime(val: any): string {
  if (!val) return '—';
  const d = typeof val === 'string' ? new Date(val) : val;
  if (isNaN(d.getTime())) return '—';
  const hrs = String(d.getHours()).padStart(2, '0');
  const mins = String(d.getMinutes()).padStart(2, '0');
  return `${fmtDate(d)}, ${hrs}:${mins}`;
}

export function dueLabel(dueDate: any): string {
  const d = dueDate ? Math.ceil(((typeof dueDate === 'string' ? new Date(dueDate) : dueDate).getTime() - Date.now()) / 864e5) : 0;
  if (d < 0) return `${Math.abs(d)}d overdue`;
  if (d === 0) return 'Due today';
  if (d === 1) return 'Due tomorrow';
  if (d <= 30) return `Due in ${d} days`;
  return `Due in ${Math.round(d / 30)} months`;
}

export function relativeTime(val: any): string {
  if (!val) return '—';
  const d = typeof val === 'string' ? new Date(val) : val;
  const secs = Math.round((Date.now() - d.getTime()) / 1000);
  if (secs < 60) return 'just now';
  if (secs < 3600) return `${Math.floor(secs / 60)}m ago`;
  if (secs < 86400) return `${Math.floor(secs / 3600)}h ago`;
  if (secs < 2592000) return `${Math.floor(secs / 86400)}d ago`;
  return fmtDate(d);
}

export function maskAccount(acc?: string): string {
  const s = String(acc || '').replace(/\s/g, '');
  return s.length <= 4 ? s : `•••• ${s.slice(-4)}`;
}

export function maskPan(pan?: string): string {
  const s = (pan || '').toUpperCase();
  return s.length < 6 ? s : `${s.slice(0, 4)}****${s.slice(-2)}`;
}

export function initials(name?: string): string {
  return (name || '?')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map(w => w[0]?.toUpperCase() ?? '')
    .join('');
}

export function inr(val: any): string {
  const n = Number(val ?? 0);
  return Number.isFinite(n) ? inrFmt.format(Math.round(n)) : '₹0';
}

export function inrExact(val: any): string {
  const n = Number(val ?? 0);
  return Number.isFinite(n) ? inrExactFmt.format(n) : '₹0.00';
}

export function inrCompact(val: any): string {
  const raw = Number(val) || 0;
  const t = Math.abs(raw);
  const sign = raw < 0 ? '-' : '';
  if (t >= 1e7) return `${sign}₹${(t / 1e7).toFixed(2)}Cr`;
  if (t >= 1e5) return `${sign}₹${(t / 1e5).toFixed(2)}L`;
  if (t >= 1e3) return `${sign}₹${(t / 1e3).toFixed(1)}K`;
  return `${sign}₹${Math.round(t)}`;
}

export function num(val: any): string {
  const n = Number(val ?? 0);
  return numFmt.format(Number.isFinite(n) ? n : 0);
}

// UI Components
const badgeTones: Record<string, string> = {
  green: 'bg-moss/15 text-moss border-moss/30',
  amber: 'bg-haldi/18 text-[#8a5d0d] border-haldi/40',
  rust: 'bg-rust/12 text-rust border-rust/30',
  teal: 'bg-brand/12 text-brand border-brand/25',
  slate: 'bg-ink/8 text-ink-2 border-ink/15',
  gold: 'bg-[#f4e3bd] text-[#6b4d12] border-[#d9bd7f]',
};

export function Badge({ children, tone = 'slate', className = '' }: { children: React.ReactNode; tone?: string; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10.5px] uppercase tracking-[0.14em] ${badgeTones[tone] || badgeTones.slate} ${className}`}>
      {children}
    </span>
  );
}

const btnVariants: Record<string, string> = {
  primary: 'bg-brand text-paper hover:bg-brand-2 shadow-[0_10px_24px_-14px_rgba(15,61,51,.9)]',
  accent: 'bg-accent text-[#fff6ec] hover:bg-accent-2 shadow-[0_10px_24px_-14px_rgba(228,87,46,.95)]',
  outline: 'ink-btn border border-ink/25 text-ink hover:border-ink/60',
  ghost: 'text-ink-2 hover:text-ink hover:bg-ink/6',
  danger: 'bg-rust text-paper hover:brightness-110',
  ink: 'bg-ink text-paper hover:bg-ink-2',
};

const btnSizes: Record<string, string> = {
  sm: 'h-9 px-3.5 text-[13px] gap-1.5',
  md: 'h-11 px-5 text-sm gap-2',
  lg: 'h-14 px-7 text-[15px] gap-2.5',
};

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  className = '',
  children,
  ...rest
}: {
  variant?: 'primary' | 'accent' | 'outline' | 'ghost' | 'danger' | 'ink';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  className?: string;
  children: React.ReactNode;
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      disabled={rest.disabled || loading}
      className={`relative inline-flex items-center justify-center rounded-full font-semibold tracking-tight transition-all duration-300 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-50 ${btnVariants[variant] || btnVariants.primary} ${btnSizes[size] || btnSizes.md} ${className}`}
    >
      {loading && <span className="mr-1 inline-block h-3.5 w-3.5 animate-spin rounded-full border-[2px] border-current border-t-transparent" />}
      {children}
    </button>
  );
}

export function Card({ children, className = '', as: Comp = 'div' }: { children: React.ReactNode; className?: string; as?: any }) {
  return <Comp className={`rounded-[18px] border border-ink/12 bg-[#fffaf1] shadow-ledger ${className}`}>{children}</Comp>;
}

export function EmptyState({ title, body, icon }: { title: string; body?: string; icon?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-ink/20 bg-paper/40 px-6 py-14 text-center">
      {icon && <span className="text-ink-3/70">{icon}</span>}
      <p className="font-display text-lg font-semibold text-ink-2">{title}</p>
      {body && <p className="max-w-sm text-[13.5px] leading-relaxed text-ink-3">{body}</p>}
    </div>
  );
}

export function Field({
  label,
  hint,
  error,
  children,
  required,
  className = '',
}: {
  label: string;
  hint?: string;
  error?: string;
  children: React.ReactNode;
  required?: boolean;
  className?: string;
}) {
  return (
    <label className={`block ${className}`}>
      <span className="flex items-baseline justify-between gap-3">
        <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">
          {label}
          {required && <span className="ml-1 text-accent">*</span>}
        </span>
        {hint && <span className="text-[11px] text-ink-3/80">{hint}</span>}
      </span>
      <span className="mt-1.5 block">{children}</span>
      {error && (
        <span className="mt-1.5 flex items-center gap-1.5 text-[12px] font-medium text-rust">
          <IconAlert width={13} height={13} /> {error}
        </span>
      )}
    </label>
  );
}

const inputBaseClass =
  'w-full rounded-xl border bg-paper/70 px-3.5 py-2.5 text-[14.5px] text-ink placeholder:text-ink-3/60 transition-all duration-200 focus:bg-[#fffdf7] focus:outline-none';

export function Input({ invalid, className = '', ...rest }: { invalid?: boolean; className?: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...rest}
      className={`${inputBaseClass} ${invalid ? 'border-rust/70 focus:border-rust' : 'border-ink/18 focus:border-brand'} ${className}`}
    />
  );
}

export function Textarea({
  invalid,
  className = '',
  ...rest
}: { invalid?: boolean; className?: string } & React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...rest}
      className={`${inputBaseClass} min-h-24 resize-y ${invalid ? 'border-rust/70 focus:border-rust' : 'border-ink/18 focus:border-brand'} ${className}`}
    />
  );
}

export function Select({ className = '', children, ...rest }: { className?: string; children: React.ReactNode } & React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...rest}
      className={`${inputBaseClass} cursor-pointer appearance-none border-ink/18 bg-[url('data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%2214%22 height=%2214%22 fill=%22none%22 stroke=%22%236d6154%22 stroke-width=%221.8%22><path d=%22M3 5l4 4 4-4%22/></svg>')] bg-[length:14px] bg-[right_0.9rem_center] bg-no-repeat pr-9 focus:border-brand ${className}`}
    >
      {children}
    </select>
  );
}

export function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { value: string; label: string; count?: number }[];
  active: string;
  onChange: (val: string) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1.5 rounded-full border border-ink/12 bg-paper-2/60 p-1">
      {tabs.map(t => {
        const isActive = t.value === active;
        return (
          <button
            key={t.value}
            type="button"
            onClick={() => onChange(t.value)}
            className={`rounded-full px-3.5 py-1.5 text-[12.5px] font-semibold transition-all duration-300 ${
              isActive ? 'bg-ink text-paper shadow-[0_8px_18px_-12px_rgba(23,19,15,.9)]' : 'text-ink-3 hover:text-ink'
            }`}
          >
            {t.label}
            {typeof t.count === 'number' && (
              <span className={`ml-1.5 font-mono text-[10.5px] ${isActive ? 'text-paper/70' : 'text-ink-3/70'}`}>{t.count}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  width = 'max-w-2xl',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  width?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCloseRef.current?.();
    };
    document.addEventListener('keydown', handleKey);
    const origOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    const timer = setTimeout(() => {
      if (containerRef.current && !containerRef.current.contains(document.activeElement)) {
        const auto = containerRef.current.querySelector<HTMLElement>('textarea, input, [autofocus]');
        if (auto) {
          auto.focus();
        } else {
          containerRef.current.focus();
        }
      }
    }, 40);

    return () => {
      clearTimeout(timer);
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = origOverflow;
    };
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" aria-label="Close dialog" onClick={onClose} className="absolute inset-0 cursor-default bg-night/55 backdrop-blur-[3px]" />
      <div
        ref={containerRef}
        tabIndex={-1}
        className={`fade-up relative w-full ${width} max-h-[92vh] overflow-y-auto rounded-t-[22px] border border-ink/15 bg-paper shadow-[0_40px_90px_-30px_rgba(16,27,24,.75)] sm:rounded-[22px]`}
      >
        <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-ink/12 bg-paper/95 px-6 py-4 backdrop-blur">
          <div>
            <h3 className="text-[22px] font-semibold leading-tight">{title}</h3>
            {subtitle && <p className="mt-1 text-[13px] text-ink-3">{subtitle}</p>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-full border border-ink/15 p-1.5 text-ink-2 transition-colors hover:border-rust hover:bg-rust/10 hover:text-rust"
          >
            <IconCross width={16} height={16} />
          </button>
        </div>
        <div className="px-6 py-5">{children}</div>
      </div>
    </div>
  );
}

export function Progress({ value, tone = 'brand' }: { value: number; tone?: string }) {
  const bg = tone === 'accent' ? 'bg-accent' : tone === 'moss' ? 'bg-moss' : 'bg-brand';
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-ink/10">
      <div className={`h-full rounded-full ${bg} transition-[width] duration-1000 ease-out`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function SectionLabel({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3 ${className}`}>
      <span className="inline-block h-px w-7 bg-accent" />
      {children}
    </span>
  );
}

export function Skeleton({ className = '' }: { className?: string }) {
  return <div className={`animate-pulse rounded-lg bg-ink/8 ${className}`} />;
}

export function LiveNumber({ value, className = '' }: { value: number; className?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || typeof IntersectionObserver === 'undefined') {
      setVal(value);
      return;
    }
    const observer = new IntersectionObserver(
      entries => {
        if (!entries[0].isIntersecting) return;
        observer.disconnect();
        const start = performance.now();
        const step = (now: number) => {
          const p = Math.min(1, (now - start) / 1200);
          setVal(value * (1 - Math.pow(1 - p, 3)));
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      },
      { threshold: 0.4 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [value]);

  return (
    <span ref={ref} className={`tabular ${className}`}>
      {Math.round(val).toLocaleString('en-IN')}
    </span>
  );
}

export interface ToastItem {
  id?: number | string;
  tone?: 'good' | 'bad' | 'info';
  title: string;
  body?: string;
}

export function useToasts() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const push = useCallback((t: ToastItem) => {
    const id = Date.now() + Math.random();
    setToasts(prev => [...prev, { ...t, id }]);
    window.setTimeout(() => {
      setToasts(prev => prev.filter(x => x.id !== id));
    }, 5200);
  }, []);

  const dismiss = useCallback((id: any) => {
    setToasts(prev => prev.filter(x => x.id !== id));
  }, []);

  return { toasts, push, dismiss };
}

export function ToastStack({ toasts, onDismiss }: { toasts: ToastItem[]; onDismiss: (id: any) => void }) {
  return (
    <div className="pointer-events-none fixed bottom-5 right-5 z-[70] flex w-[min(92vw,360px)] flex-col gap-2.5">
      {toasts.map(t => (
        <div
          key={t.id}
          className={`fade-up pointer-events-auto flex items-start gap-3 rounded-2xl border px-4 py-3 shadow-card backdrop-blur ${
            t.tone === 'bad' ? 'border-rust/35 bg-[#fdf0ea]' : t.tone === 'good' ? 'border-moss/35 bg-[#eef5ec]' : 'border-ink/15 bg-[#fffaf1]'
          }`}
        >
          <span
            className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${
              t.tone === 'bad' ? 'bg-rust text-paper' : t.tone === 'good' ? 'bg-moss text-paper' : 'bg-brand text-paper'
            }`}
          >
            {t.tone === 'bad' ? <IconAlert width={12} height={12} /> : <IconCheck width={12} height={12} />}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] font-semibold leading-snug text-ink">{t.title}</p>
            {t.body && <p className="mt-0.5 text-[12.5px] leading-snug text-ink-3">{t.body}</p>}
          </div>
          <button type="button" onClick={() => onDismiss(t.id)} aria-label="Dismiss" className="text-ink-3 hover:text-ink">
            <IconCross width={14} height={14} />
          </button>
        </div>
      ))}
    </div>
  );
}

export function useReveal(opts?: { threshold?: number; once?: boolean; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      setShown(true);
      return;
    }
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            if (opts?.delay) window.setTimeout(() => setShown(true), opts.delay);
            else setShown(true);
            if (opts?.once !== false) observer.unobserve(entry.target);
          } else if (opts?.once === false) {
            setShown(false);
          }
        });
      },
      { threshold: opts?.threshold ?? 0.15, rootMargin: '0px 0px -8% 0px' }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [opts?.threshold, opts?.once, opts?.delay]);

  return { ref, shown, className: shown ? 'reveal is-in' : 'reveal' };
}
