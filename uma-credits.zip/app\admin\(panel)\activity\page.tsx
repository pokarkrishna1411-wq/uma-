import React from 'react';
import { ActivityView } from '@/components/admin/activity-view';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function ActivityPage() {
  return <ActivityView />;
}
