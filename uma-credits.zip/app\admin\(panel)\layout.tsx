import React from 'react';
import { getCurrentAdmin } from '@/lib/auth';
import { getAdminStats } from '@/lib/db';
import { AdminShell } from '@/components/admin/shell';

export default function AdminPanelLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const admin = getCurrentAdmin() || {
    name: 'Rukmini Iyer',
    username: 'admin',
    role: 'Chief Underwriter',
  };

  const stats = getAdminStats();
  const pendingCount = stats?.loans?.pending || 0;

  return (
    <AdminShell
      admin={{
        name: admin.name,
        username: admin.username,
        role: admin.role,
      }}
      pendingCount={pendingCount}
    >
      {children}
    </AdminShell>
  );
}
