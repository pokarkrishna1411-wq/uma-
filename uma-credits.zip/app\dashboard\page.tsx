import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { getUserLoans, getUserTransactions } from '@/lib/db';
import { DashboardClient } from '@/components/dashboard/dashboard-client';

export default function DashboardPage() {
  const user = getCurrentUser();
  if (!user) {
    redirect('/#login');
  }

  const loans = getUserLoans(user.id);
  const transactions = getUserTransactions(user.id);

  return (
    <DashboardClient
      user={user}
      initialLoans={loans}
      initialTransactions={transactions}
    />
  );
}
