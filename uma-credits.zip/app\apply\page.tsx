import React, { Suspense } from 'react';
import { getCurrentUser } from '@/lib/auth';
import { ApplyClient } from '@/components/apply/apply-client';

export default function ApplyPage() {
  const user = getCurrentUser();

  return (
    <Suspense fallback={<div className="min-h-screen bg-paper" />}>
      <ApplyClient user={user} />
    </Suspense>
  );
}
