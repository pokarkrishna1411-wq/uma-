'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import { useSettings } from '@/components/settings-provider';
import { calculateLoan, formatINR, formatNumberINR } from '@/lib/loan-math';
import {
  IconArrow,
  IconCoins,
  IconPercent,
  IconDoc,
  IconShield,
  IconCalendar,
  IconClock,
  IconSparkles,
  IconCheck,
  IconChevronDown,
  IconShop,
} from '@/components/icons';


export function HowItWorksSection() {
  const { parsed } = useSettings();
  const steps = parsed.howItWorks.length
    ? parsed.howItWorks
    : [
        { title: 'Tell us your name', body: 'Login takes 10 seconds — name and mobile number, nothing else.' },
        { title: 'Pick the amount', body: 'Slide between ₹1,000 and ₹2,00,000 and choose how many months you want to repay over.' },
        { title: 'Read the full cost', body: 'The breakdown shows interest, processing fee, GST, net disbursal and every EMI date.' },
        { title: 'Complete KYC', body: 'PAN, bank account and email — captured once in a popup, encrypted at rest.' },
        { title: 'Money in your account', body: 'Admin approval is manual and human. Disbursal follows within the promised SLA.' },
      ];

  return (
    <section id="how" className="mx-auto max-w-[1240px] scroll-mt-24 px-5 py-24 lg:px-8">
      <div>
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
              <span className="inline-block h-px w-7 bg-accent" />
              The counter process
            </span>
            <h2 className="mt-4 max-w-2xl font-display text-[clamp(2rem,4.4vw,3.3rem)] font-bold leading-[1.02]">
              Five steps between <em className="font-display italic text-accent">“I need ₹1,000”</em> and money in your account.
            </h2>
          </div>
          <p className="max-w-sm text-[14px] leading-relaxed text-ink-3">
            Nothing here is hidden behind a sales call. The same numbers you see in the calculator are the numbers printed on your sanction letter.
          </p>
        </div>

        <ol className="mt-14 grid gap-px overflow-hidden rounded-[20px] border border-ink/12 bg-ink/12 md:grid-cols-2 lg:grid-cols-5">
          {steps.map((step: any, i: number) => (
            <li key={i} className="ledger-row group relative bg-[#fffaf1] p-6">
              <span className="font-mono text-[11px] tracking-[0.2em] text-accent">
                {String(i + 1).padStart(2, '0')}
              </span>
              <h3 className="mt-3 font-display text-[19px] font-bold leading-tight">{step.title}</h3>
              <p className="mt-2.5 text-[13.5px] leading-relaxed text-ink-3">{step.body}</p>
              <span className="mt-5 block h-px w-full bg-ink/10 transition-all duration-500 group-hover:bg-accent" />
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function LiveCalculatorSection() {
  const { pricing, parsed, text } = useSettings();
  const [amount, setAmount] = useState<number>(10000);
  const [tenure, setTenure] = useState<number>(pricing.defaultTenure || 6);
  const [purpose, setPurpose] = useState<string>('business');
  const [repaymentMode, setRepaymentMode] = useState<string>('UPI autopay (GPay / PhonePe / Paytm)');
  const [showSchedule, setShowSchedule] = useState(false);

  const quote = useMemo(() => {
    return calculateLoan({
      principal: amount,
      tenureMonths: tenure,
      pricing,
    });
  }, [amount, tenure, pricing]);

  const minL = pricing.minLoan || 1000;
  const maxL = pricing.maxLoan || 200000;
  const fillPct = ((amount - minL) / (maxL - minL)) * 100;

  const quickAmounts = pricing.quickAmounts || [1000, 5000, 10000, 25000, 50000, 100000];
  const tenures = pricing.tenures || [
    { months: 3, label: '3' },
    { months: 6, label: '6' },
    { months: 9, label: '9' },
    { months: 12, label: '12' },
    { months: 18, label: '18' },
    { months: 24, label: '24' },
  ];

  const loanInstructions = parsed.loanInstructions.length
    ? parsed.loanInstructions
    : [
        'Interest is calculated on a reducing balance, so every EMI you pay lowers the next month\'s interest.',
        'The processing fee plus GST is deducted once, at disbursal — your bank receives the net amount.',
        'EMIs are auto-debited through NACH/e-mandate on the due date. Keep your account funded a day early.',
        'You get a 5-day grace period. After that a late fee applies and the instalment is reported overdue.',
      ];

  const purposes = pricing.purposes || [
    { value: 'business', label: 'Business & working capital' },
    { value: 'inventory', label: 'Festival inventory' },
    { value: 'equipment', label: 'Equipment & machinery' },
    { value: 'medical', label: 'Medical emergency' },
    { value: 'education', label: 'Education' },
    { value: 'personal', label: 'Personal need' },
  ];

  const repaymentModes = parsed.repaymentModes.length
    ? parsed.repaymentModes
    : [
        'UPI autopay (GPay / PhonePe / Paytm)',
        'NACH e-mandate from your bank account',
        'NEFT / IMPS to the Uma Credits current account',
        'Cash at a partner branch (above ₹5,000 a fee applies)',
      ];

  return (
    <section id="calculator" className="relative scroll-mt-24 overflow-hidden bg-paper-2/60 py-24">
      <div className="relative mx-auto max-w-[1240px] px-5 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
              <span className="inline-block h-px w-7 bg-accent" />
              Live sanction calculator
            </span>
            <h2 className="mt-4 max-w-2xl font-display text-[clamp(2rem,4.4vw,3.3rem)] font-bold leading-[1.02]">
              Move the slider. The server re-prices your loan.
            </h2>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[10.5px] uppercase tracking-[0.14em] bg-brand/12 text-brand border-brand/25">
            <IconSparkles width={12} height={12} />
            Computed by GET /api/loans/quote
          </span>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-[1fr_0.92fr] lg:items-start">
          <div className="rounded-[18px] border border-ink/12 bg-[#fffaf1] shadow-ledger p-6 sm:p-8">
            <div className="flex items-baseline justify-between gap-4">
              <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink-3">Loan amount</p>
              <p className="font-display text-[40px] font-black leading-none text-brand tabular">
                {formatINR(amount)}
              </p>
            </div>

            <input
              type="range"
              className="rupee-range mt-4"
              style={{ ['--fill' as any]: `${fillPct}%` }}
              min={minL}
              max={maxL}
              step={pricing.stepAmount || 500}
              aria-label="Loan amount in rupees"
              value={amount}
              onChange={e => setAmount(Number(e.target.value))}
            />

            <div className="flex justify-between font-mono text-[10.5px] uppercase tracking-[0.14em] text-ink-3">
              <span>{formatINR(minL)}</span>
              <span>{formatINR(maxL)}</span>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              {quickAmounts.map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmount(val)}
                  className={`rounded-full border px-3.5 py-1.5 font-mono text-[12px] transition-all duration-300 ${
                    amount === val
                      ? 'border-accent bg-accent text-[#fff6ec]'
                      : 'border-ink/18 text-ink-2 hover:border-accent hover:text-accent'
                  }`}
                >
                  {formatINR(val)}
                </button>
              ))}
            </div>

            <div className="mt-8 h-px w-full bg-ink/10" />

            <p className="mt-7 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-3">Repay over</p>
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
              {tenures.map(t => (
                <button
                  key={t.months}
                  type="button"
                  onClick={() => setTenure(t.months)}
                  className={`rounded-xl border px-2 py-3 text-center transition-all duration-300 ${
                    tenure === t.months
                      ? 'border-brand bg-brand text-paper shadow-[0_12px_24px_-16px_rgba(15,61,51,1)]'
                      : 'border-ink/15 bg-paper/60 text-ink-2 hover:border-brand/50'
                  }`}
                >
                  <span className="block font-display text-[19px] font-bold leading-none">{t.months}</span>
                  <span className="mt-1 block font-mono text-[9.5px] uppercase tracking-[0.14em] opacity-70">months</span>
                </button>
              ))}
            </div>

            <div className="mt-7 grid gap-4 sm:grid-cols-2">
              <label className="block">
                <span className="flex items-baseline justify-between gap-3">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Purpose</span>
                </span>
                <span className="mt-1.5 block">
                  <select
                    className="w-full rounded-xl border bg-paper/70 px-3.5 py-2.5 text-[14.5px] text-ink transition-all duration-200 focus:bg-[#fffdf7] focus:outline-none cursor-pointer appearance-none border-ink/18 focus:border-brand"
                    value={purpose}
                    onChange={e => setPurpose(e.target.value)}
                  >
                    {purposes.map(p => (
                      <option key={p.value} value={p.value}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </span>
              </label>

              <label className="block">
                <span className="flex items-baseline justify-between gap-3">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Repayment mode</span>
                  <span className="text-[11px] text-ink-3/80">auto-debit</span>
                </span>
                <span className="mt-1.5 block">
                  <select
                    className="w-full rounded-xl border bg-paper/70 px-3.5 py-2.5 text-[14.5px] text-ink transition-all duration-200 focus:bg-[#fffdf7] focus:outline-none cursor-pointer appearance-none border-ink/18 focus:border-brand"
                    value={repaymentMode}
                    onChange={e => setRepaymentMode(e.target.value)}
                  >
                    {repaymentModes.map((m: string) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                </span>
              </label>
            </div>

            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Link
                href={`/apply?amount=${amount}&tenure=${tenure}&purpose=${purpose}`}
                className="inline-flex h-12 items-center gap-2 rounded-full bg-accent px-6 text-[14px] font-bold text-[#fff6ec] transition-transform duration-300 hover:-translate-y-0.5"
              >
                Apply for {formatINR(amount)} <IconArrow width={16} height={16} />
              </Link>
              <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">
                {text('approval_sla_hours', '4')}h sanction · {text('disbursal_sla_hours', '24')}h disbursal
              </span>
            </div>
          </div>

          <div className="lg:sticky lg:top-24">
            <div className="paper-dark noise relative overflow-hidden rounded-[20px] p-6 text-paper shadow-card sm:p-8">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-haldi">Breakdown · draft sanction</p>
                  <p className="mt-2 font-display text-[15px] text-paper/70">Monthly instalment</p>
                  <p className="font-display text-[clamp(2.6rem,6vw,3.6rem)] font-black leading-none text-paper tabular">
                    {formatINR(quote.emi)}
                  </p>
                </div>
                <span className="text-haldi/80">
                  <IconShop width={44} height={44} />
                </span>
              </div>

              <dl className="mt-7 grid gap-px overflow-hidden rounded-xl bg-paper/12">
                <div className="flex items-center justify-between gap-4 bg-[#101f1a] px-4 py-3">
                  <dt className="flex items-center gap-2.5 text-[13px] text-paper/70">
                    <span className="text-haldi"><IconCoins width={14} height={14} /></span>
                    Principal borrowed
                  </dt>
                  <dd className="font-mono text-[13.5px] text-paper tabular">{formatINR(quote.principal)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-[#101f1a] px-4 py-3">
                  <dt className="flex items-center gap-2.5 text-[13px] text-paper/70">
                    <span className="text-haldi"><IconPercent width={14} height={14} /></span>
                    Interest · {quote.monthlyRatePct}% / month
                  </dt>
                  <dd className="font-mono text-[13.5px] text-paper tabular">{formatINR(quote.interest)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-[#101f1a] px-4 py-3">
                  <dt className="flex items-center gap-2.5 text-[13px] text-paper/70">
                    <span className="text-haldi"><IconDoc width={14} height={14} /></span>
                    Processing fee · {pricing.processingFeePct}%
                  </dt>
                  <dd className="font-mono text-[13.5px] text-paper tabular">{formatINR(quote.processingFee)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-[#101f1a] px-4 py-3">
                  <dt className="flex items-center gap-2.5 text-[13px] text-paper/70">
                    <span className="text-haldi"><IconShield width={14} height={14} /></span>
                    GST on fee · {pricing.gstPct}%
                  </dt>
                  <dd className="font-mono text-[13.5px] text-paper tabular">{formatINR(quote.gst)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-accent/90 px-4 py-3.5">
                  <dt className="text-[13px] font-semibold text-[#fff6ec]">Net amount you receive</dt>
                  <dd className="font-mono text-[15px] font-semibold text-[#fff6ec] tabular">{formatINR(quote.netDisbursal)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-[#0b1714] px-4 py-3.5">
                  <dt className="text-[13px] text-paper/75">Total you repay over {quote.tenureMonths} months</dt>
                  <dd className="font-mono text-[15px] text-paper tabular">{formatINR(quote.totalRepayable)}</dd>
                </div>
              </dl>

              <div className="mt-7">
                <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-haldi">
                  <IconCalendar width={13} height={13} /> Timeline to close the loan
                </p>
                <div className="mt-3 flex items-center gap-3">
                  <span className="font-mono text-[11px] text-paper/60">Today</span>
                  <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-paper/15">
                    <div className="absolute inset-y-0 left-0 w-full bg-gradient-to-r from-haldi/70 to-accent" />
                  </div>
                  <span className="font-mono text-[11px] text-paper/85">
                    {new Date(quote.maturityDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                  </span>
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-2">
                  <p className="flex items-center gap-2 text-[12.5px] text-paper/70">
                    <IconClock width={13} height={13} className="text-haldi" />
                    First EMI {new Date(quote.firstDueDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })} · Due in 1 month
                  </p>
                  <p className="flex items-center gap-2 text-[12.5px] text-paper/70">
                    <IconCoins width={13} height={13} className="text-haldi" />
                    Cost of credit {quote.costOfCreditPct}% · ≈₹{quote.perDayCost}/day
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowSchedule(!showSchedule)}
                className="mt-6 flex w-full items-center justify-between rounded-xl border border-paper/20 px-4 py-3 text-[13px] font-semibold text-paper/85 transition-colors hover:border-haldi hover:text-haldi"
              >
                <span className="flex items-center gap-2">
                  <IconCalendar width={15} height={15} />
                  {showSchedule ? 'Hide' : 'Show'} month-by-month schedule
                </span>
                <IconChevronDown
                  width={15}
                  height={15}
                  className={`transition-transform duration-300 ${showSchedule ? 'rotate-180' : ''}`}
                />
              </button>

              {showSchedule && (
                <div className="mt-4 max-h-60 overflow-y-auto rounded-xl border border-paper/15 bg-[#0b1714] p-3 text-[12px]">
                  <table className="w-full text-left font-mono">
                    <thead>
                      <tr className="border-b border-paper/10 text-[10px] uppercase text-paper/50">
                        <th className="py-1">#</th>
                        <th className="py-1">Due Date</th>
                        <th className="py-1">Principal</th>
                        <th className="py-1">Interest</th>
                        <th className="py-1 text-right">EMI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-paper/10 text-paper/80">
                      {quote.schedule.map(s => (
                        <tr key={s.n}>
                          <td className="py-1">{s.n}</td>
                          <td className="py-1">{new Date(s.dueDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}</td>
                          <td className="py-1">₹{formatNumberINR(s.principalPart)}</td>
                          <td className="py-1">₹{formatNumberINR(s.interestPart)}</td>
                          <td className="py-1 text-right font-semibold text-paper">₹{formatNumberINR(s.emi)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="mt-5 rounded-[18px] border border-ink/12 bg-[#fffaf1] p-6">
              <p className="font-mono text-[10.5px] uppercase tracking-[0.22em] text-ink-3">Read before you borrow</p>
              <ol className="mt-4 grid gap-3">
                {loanInstructions.slice(0, 4).map((inst: string, idx: number) => (
                  <li key={idx} className="flex gap-3 text-[13px] leading-relaxed text-ink-2">
                    <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-brand/10 font-mono text-[10px] text-brand">
                      {idx + 1}
                    </span>
                    {inst}
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function WhyLedgerSection() {
  const { parsed } = useSettings();
  const valueProps = parsed.valueProps.length
    ? parsed.valueProps
    : [
        { title: 'No hidden spread', body: 'The rate you see on the quote is the rate frozen on your sanction letter.' },
        { title: 'Human underwriting', body: 'A person reviews your KYC, not a black-box model that says no at 2 a.m.' },
        { title: 'Early exit, no fine', body: 'Close the loan any time. Interest stops the day you repay.' },
        { title: 'Ledger you can read', body: 'Every disbursement, EMI and fee appears in your own transaction register.' },
      ];

  const icons = [IconShield, IconSparkles, IconCheck, IconDoc];

  return (
    <section className="mx-auto max-w-[1240px] px-5 py-24 lg:px-8">
      <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
            <span className="inline-block h-px w-7 bg-accent" />
            Why the ledger stays with us
          </span>
          <h2 className="mt-4 font-display text-[clamp(2rem,4.2vw,3.1rem)] font-bold leading-[1.03]">
            Lending is only honest when the maths is on the table.
          </h2>
          <p className="mt-5 max-w-md text-[14.5px] leading-relaxed text-ink-3">
            Most loan apps show you the EMI. We show you the interest, the fee, the GST, the net amount that actually lands in your account, and the exact date the balance hits zero.
          </p>
          <div className="mt-8 overflow-hidden rounded-[18px] border border-ink/12">
            <img
              src="https://images.pexels.com/photos/12495827/pexels-photo-12495827.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Bahi-khata ledger book"
              className="kenburns h-64 w-full object-cover"
              loading="lazy"
            />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          {valueProps.map((prop: any, idx: number) => {
            const Icon = icons[idx % icons.length];
            return (
              <article
                key={idx}
                className="ledger-row group rounded-[18px] border border-ink/12 bg-[#fffaf1] p-6 transition-transform duration-500 hover:-translate-y-1"
              >
                <span className="inline-grid h-10 w-10 place-items-center rounded-xl bg-brand/10 text-brand transition-colors duration-500 group-hover:bg-accent group-hover:text-[#fff6ec]">
                  <Icon width={18} height={18} />
                </span>
                <h3 className="mt-5 font-display text-[19px] font-bold leading-tight">{prop.title}</h3>
                <p className="mt-2.5 text-[13.5px] leading-relaxed text-ink-3">{prop.body}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function StoriesSection() {
  const { parsed } = useSettings();
  const [selectedIdx, setSelectedIdx] = useState(0);

  const stories = parsed.borrowerStories.length
    ? parsed.borrowerStories
    : [
        {
          name: 'Iqbal Ansari',
          role: 'Kirana store owner',
          city: 'Lalbagh, Bengaluru',
          amount: 45000,
          tenure: 12,
          quote: 'Stock for Ramzan used to mean borrowing from a relative. Now it is a slider and a sanction letter.',
          image: 'https://images.pexels.com/photos/12495827/pexels-photo-12495827.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        },
        {
          name: 'Harpreet Sidhu',
          role: 'Textile merchant',
          city: 'Kota, Rajasthan',
          amount: 120000,
          tenure: 18,
          quote: 'The reducing-balance sheet convinced me. I could see exactly how much interest I was still carrying.',
          image: 'https://images.pexels.com/photos/21005657/pexels-photo-21005657.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        },
        {
          name: 'Swastik Arora',
          role: 'Tailoring unit',
          city: 'Kanpur, Uttar Pradesh',
          amount: 25000,
          tenure: 6,
          quote: 'Two machines on EMI. Six months later the machines had paid for themselves twice over.',
          image: 'https://images.pexels.com/photos/13206032/pexels-photo-13206032.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        },
        {
          name: 'Meena Devi',
          role: 'Street fruit vendor',
          city: 'Delhi',
          amount: 8000,
          tenure: 3,
          quote: '₹8,000 for a melon season. I repaid in 74 days and my trust score went up.',
          image: 'https://images.pexels.com/photos/38043952/pexels-photo-38043952.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200',
        },
      ];

  const current = stories[selectedIdx] || stories[0];

  return (
    <section id="stories" className="relative scroll-mt-24 overflow-hidden bg-paper-2/50 py-24">
      <div className="relative mx-auto max-w-[1240px] px-5 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
              <span className="inline-block h-px w-7 bg-accent" />
              Who borrows with us
            </span>
            <h2 className="mt-4 max-w-xl font-display text-[clamp(2rem,4.4vw,3.3rem)] font-bold leading-[1.02]">
              Counter stories from the ledger.
            </h2>
          </div>
          <div className="flex gap-2">
            {stories.map((s: any, idx: number) => (
              <button
                key={idx}
                type="button"
                aria-label={`Show story of ${s.name}`}
                onClick={() => setSelectedIdx(idx)}
                className={`h-2.5 rounded-full transition-all duration-500 ${
                  selectedIdx === idx ? 'w-10 bg-accent' : 'w-2.5 bg-ink/20 hover:bg-ink/40'
                }`}
              />
            ))}
          </div>
        </div>

        <div className="mt-14 grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div className="relative">
            <div className="overflow-hidden rounded-[20px] border-[10px] border-[#fffcf4] shadow-card">
              <img
                src={current.image}
                alt={`${current.name}, ${current.role} in ${current.city}`}
                className="kenburns h-[380px] w-full object-cover sm:h-[460px]"
                loading="lazy"
              />
            </div>
            <div
              className="absolute -bottom-6 left-6 rounded-2xl border border-ink/12 bg-[#fffcf4] px-5 py-4 shadow-card"
              style={{ transform: 'rotate(-2.2deg)' }}
            >
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Sanctioned</p>
              <p className="mt-1 font-display text-[26px] font-black leading-none text-brand tabular">
                {formatINR(current.amount)}
              </p>
              <p className="mt-1 font-mono text-[11px] text-ink-3">
                {current.tenure} months · Due in 20 days
              </p>
            </div>
          </div>

          <div>
            <figure className="fade-up">
              <blockquote className="font-display text-[clamp(1.5rem,3vw,2.2rem)] font-semibold leading-[1.24] text-ink">
                <span className="text-accent">“</span>
                {current.quote}
                <span className="text-accent">”</span>
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-4">
                <span className="grid h-12 w-12 place-items-center rounded-full bg-brand font-display text-[17px] font-bold text-paper">
                  {current.name.split(' ').map((n: string) => n[0]).join('')}
                </span>
                <span>
                  <span className="block text-[15px] font-bold text-ink">{current.name}</span>
                  <span className="block font-mono text-[11.5px] uppercase tracking-[0.14em] text-ink-3">
                    {current.role} · {current.city}
                  </span>
                </span>
              </figcaption>
            </figure>

            <div className="mt-10 grid gap-3 sm:grid-cols-2">
              {stories.map((s: any, idx: number) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedIdx(idx)}
                  className={`ledger-row rounded-xl border px-4 py-3 text-left transition-all duration-300 ${
                    selectedIdx === idx
                      ? 'border-brand bg-brand/8 font-bold'
                      : 'border-ink/12 bg-[#fffaf1] hover:border-brand/40'
                  }`}
                >
                  <span className="block text-[13.5px] font-bold text-ink">{s.name}</span>
                  <span className="mt-0.5 block font-mono text-[10.5px] uppercase tracking-[0.14em] text-ink-3">
                    {s.role} · {formatINR(s.amount)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function EligibilitySection() {
  const { parsed } = useSettings();
  const criteria = parsed.eligibilityCriteria.length
    ? parsed.eligibilityCriteria
    : [
        'Indian resident, 21 to 60 years of age',
        'A mobile number linked to your Aadhaar',
        'Valid PAN card in your own name',
        'A bank account with 3 months of statements',
        'Minimum ₹8,000 monthly income — salary, business or gig work',
        'No active default with any Uma Credits loan',
      ];

  const docs = parsed.documentsRequired.length
    ? parsed.documentsRequired
    : [
        'PAN card (number, verified against NSDL)',
        'Bank account number + IFSC',
        'Email address for sanction letter',
        'Selfie with PAN (asked for at disbursal stage)',
      ];

  return (
    <section className="mx-auto max-w-[1240px] px-5 py-24 lg:px-8">
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="rounded-[18px] border border-ink/12 bg-[#fffaf1] shadow-ledger p-7 sm:p-9">
          <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
            <span className="inline-block h-px w-7 bg-accent" />
            Eligibility
          </span>
          <h3 className="mt-4 font-display text-[26px] font-bold leading-tight">Who can walk up to the counter</h3>
          <ul className="mt-6 grid gap-3.5">
            {criteria.map((item: string, i: number) => (
              <li key={i} className="flex gap-3 text-[14px] leading-relaxed text-ink-2">
                <IconCheck width={16} height={16} className="mt-1 shrink-0 text-moss" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-[18px] border border-ink/12 bg-[#fffaf1] shadow-ledger p-7 sm:p-9">
          <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
            <span className="inline-block h-px w-7 bg-accent" />
            Documents
          </span>
          <h3 className="mt-4 font-display text-[26px] font-bold leading-tight">What we inspect at the counter</h3>
          <ul className="mt-6 grid gap-3.5">
            {docs.map((doc: string, i: number) => (
              <li key={i} className="flex gap-3 text-[14px] leading-relaxed text-ink-2">
                <IconDoc width={16} height={16} className="mt-1 shrink-0 text-brand" />
                {doc}
              </li>
            ))}
          </ul>

          <div className="mt-8 rounded-xl border border-ink/10 bg-paper-2/60 p-4">
            <p className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-3">Underwriting SLA</p>
            <p className="mt-1 text-[13px] text-ink-2">
              Sanction decisions within 4 hours. Disbursal straight to your bank account in 24 hours.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}

export function RateBoardSection() {
  const { pricing } = useSettings();

  const rates = [
    { label: 'Monthly interest rate', value: `${pricing.monthlyRatePct}% / month` },
    { label: 'Annual percentage rate (APR)', value: `≈ ${pricing.annualRatePct}% APR` },
    { label: 'Calculation method', value: pricing.interestMethod === 'flat' ? 'Flat rate' : 'Reducing balance (RBI-preferred)' },
    { label: 'Processing fee', value: `${pricing.processingFeePct}% + 18% GST` },
    { label: 'Foreclosure penalty', value: pricing.prepaymentPenaltyPct ? `${pricing.prepaymentPenaltyPct}%` : '₹0 · Completely free' },
    { label: 'Grace period', value: `${pricing.graceDays || 5} days before late fee applies` },
    { label: 'Late fee per overdue EMI', value: `₹${pricing.lateFee || 250}` },
    { label: 'NACH / e-mandate bounce fee', value: `₹${pricing.bounceCharges || 350}` },
  ];

  return (
    <section id="rates" className="relative scroll-mt-24 overflow-hidden bg-paper-2/50 py-24">
      <div className="relative mx-auto max-w-[1240px] px-5 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
              <span className="inline-block h-px w-7 bg-accent" />
              Rate board
            </span>
            <h2 className="mt-4 max-w-xl font-display text-[clamp(2rem,4.4vw,3.3rem)] font-bold leading-[1.02]">
              No hidden fees, no compounding traps.
            </h2>
          </div>
          <p className="max-w-sm text-[14px] leading-relaxed text-ink-3">
            Every charge is frozen in the contract. The admin panel operators cannot modify a sanction rate after you accept.
          </p>
        </div>

        <div className="mt-12 overflow-hidden rounded-[20px] border border-ink/12 bg-[#fffaf1] shadow-ledger">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-ink/10 bg-paper-2/60 font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-3">
                <th className="px-6 py-4">Fee / Rate Item</th>
                <th className="px-6 py-4 text-right">Uma Credits Tariff</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink/10 text-[14px]">
              {rates.map((r, i) => (
                <tr key={i} className="ledger-row hover:bg-paper-2/40">
                  <td className="px-6 py-3.5 font-medium text-ink">{r.label}</td>
                  <td className="px-6 py-3.5 text-right font-mono font-semibold text-brand">{r.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

export function FaqSection() {
  const { parsed } = useSettings();
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = parsed.faq.length
    ? parsed.faq
    : [
        {
          q: 'Why is there no password?',
          a: 'Your mobile number is your identity. A session cookie is stored on this device only and you can log out at any time. Admins can block a number instantly if a device is lost.',
        },
        {
          q: 'How fast is the interest calculated?',
          a: 'The quote on the apply page is computed on the server with the exact same formula that generates your sanction letter — reducing balance EMI, rounded to the paisa.',
        },
        {
          q: 'What happens if I pay early?',
          a: 'Interest stops on the day of repayment. There is no prepayment penalty unless the admin turns one on in settings.',
        },
        {
          q: 'Who sees my PAN and bank account?',
          a: 'Only the admin panel operators reviewing your application. Numbers are masked in every list view and never returned to the browser in full.',
        },
        {
          q: 'Is this real lending?',
          a: 'No. This is a demonstration platform. The ledger, sanctions and payments are simulated end to end.',
        },
      ];

  return (
    <section id="faq" className="mx-auto max-w-[1240px] scroll-mt-24 px-5 py-24 lg:px-8">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
            <span className="inline-block h-px w-7 bg-accent" />
            Frequently asked questions
          </span>
          <h2 className="mt-4 max-w-xl font-display text-[clamp(2rem,4.4vw,3.3rem)] font-bold leading-[1.02]">
            Straight answers to counter questions.
          </h2>
        </div>
      </div>

      <div className="mt-12 grid gap-3 max-w-3xl">
        {faqs.map((f: any, i: number) => {
          const isOpen = openIdx === i;
          return (
            <div
              key={i}
              className="rounded-[16px] border border-ink/12 bg-[#fffaf1] overflow-hidden transition-all duration-300"
            >
              <button
                type="button"
                onClick={() => setOpenIdx(isOpen ? null : i)}
                className="flex w-full items-center justify-between p-5 text-left font-display text-[17px] font-bold text-ink"
              >
                <span>{f.q}</span>
                <IconChevronDown
                  width={18}
                  height={18}
                  className={`shrink-0 transition-transform duration-300 text-ink-3 ${isOpen ? 'rotate-180 text-accent' : ''}`}
                />
              </button>
              {isOpen && (
                <div className="px-5 pb-5 text-[14px] leading-relaxed text-ink-2">
                  <p>{f.a}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}

export function SiteFooter() {
  const { text } = useSettings();
  const brandName = text('brand_name', 'Kinara Credit');
  const brandTagline = text('brand_tagline', 'Chhoti zaroorat. Bada bharosa.');
  const brandStory = text(
    'brand_story',
    'Kinara Credit started as a bahi-khata counter in Lalbagh — a red-cloth ledger where shopkeepers recorded who owed what. We kept the ledger and replaced the interest-rate guesswork with a transparent calculator. Every rupee you borrow shows its full cost before you sign.'
  );

  return (
    <footer className="border-t border-ink/12 bg-[#fffcf4] text-ink pt-16 pb-12">
      <div className="mx-auto max-w-[1240px] px-5 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_0.8fr_0.8fr_1fr]">
          <div>
            <div className="flex items-center gap-3">
              <span className="grid h-9 w-9 place-items-center rounded-[10px] font-display text-[17px] font-black bg-accent text-[#fff6ec]">
                K
              </span>
              <div>
                <p className="font-display text-[18px] font-bold">{brandName}</p>
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">{brandTagline}</p>
              </div>
            </div>
            <p className="mt-4 max-w-sm text-[13px] leading-relaxed text-ink-3">{brandStory}</p>
          </div>

          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink-3">Borrow</p>
            <ul className="mt-4 grid gap-2.5 text-[13.5px]">
              <li><Link href="#login" className="link-draw text-ink-2 hover:text-accent">Log in</Link></li>
              <li><Link href="#calculator" className="link-draw text-ink-2 hover:text-accent">EMI calculator</Link></li>
              <li><Link href="#how" className="link-draw text-ink-2 hover:text-accent">How it works</Link></li>
              <li><Link href="/apply" className="link-draw text-ink-2 hover:text-accent">Apply for a loan</Link></li>
              <li><Link href="#rates" className="link-draw text-ink-2 hover:text-accent">Rate board</Link></li>
            </ul>
          </div>

          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink-3">Company</p>
            <ul className="mt-4 grid gap-2.5 text-[13.5px]">
              <li><Link href="#stories" className="link-draw text-ink-2 hover:text-accent">Borrower stories</Link></li>
              <li><Link href="#faq" className="link-draw text-ink-2 hover:text-accent">FAQ</Link></li>
              <li><Link href="/docs" className="link-draw text-ink-2 hover:text-accent">System architecture</Link></li>
              <li><Link href="/admin" className="link-draw text-ink-2 hover:text-accent">Admin panel</Link></li>
            </ul>
          </div>

          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink-3">Reach us</p>
            <div className="mt-4 grid gap-2 text-[13px] text-ink-2">
              <p className="font-mono text-brand font-semibold">{text('support_phone', '+91 80 4718 2200')}</p>
              <p className="font-mono text-ink-3">{text('support_email', 'care@kinaracredit.in')}</p>
              <p className="mt-2 text-ink-3 leading-relaxed">
                {text('registered_office', '3rd Floor, Bahi-Khata Chambers, Lalbagh Road, Bengaluru 560027, Karnataka')}
              </p>
              <p className="mt-2 font-mono text-[11px] text-ink-3/70">
                GSTIN {text('gstin', '29AAKCK1234M1ZP')} · CIN {text('cin', 'U65929KA2019PTC124880')}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-14 border-t border-ink/10 pt-8 flex flex-wrap items-center justify-between gap-4 text-[12px] text-ink-3">
          <p>{text('footer_disclaimer', 'Kinara Credit is a demonstration lending platform. Loans shown here are simulated and no real money is disbursed or collected.')}</p>
          <div className="flex gap-4 font-mono text-[11px]">
            <span>© 2026 {brandName}</span>
            <span>{text('grievance_officer', 'Ms. Rukmini Iyer · grievance@kinaracredit.in')}</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
