'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  IconUsers,
  IconClock,
  IconCheck,
  IconCross,
  IconShield,
  IconBank,
  IconRupee,
  IconDoc,
  IconArrow,
  IconAlert,
  IconStamp,
  Seal,
} from '@/components/icons';
import {
  Button,
  Card,
  Badge,
  SectionLabel,
  Field,
  Select,
  Textarea,
  Modal,
  Progress,
  ToastStack,
  useToasts,
  inr,
  inrExact,
  fmtDate,
  fmtDateTime,
  dueLabel,
  relativeTime,
} from '@/components/ui';

const statusBadgeTones: Record<string, string> = {
  pending: 'amber',
  approved: 'teal',
  active: 'green',
  closed: 'slate',
  rejected: 'rust',
};

export function KycPanel({ kyc }: { kyc: any }) {
  if (!kyc) {
    return (
      <div className="py-6 text-center text-[13.5px] text-ink-3">
        No KYC submitted yet. The borrower has not completed the popup form.
      </div>
    );
  }

  const items = [
    { k: 'Full name', v: kyc.fullName },
    { k: 'Mobile', v: `+91 ${kyc.mobile}` },
    { k: 'PAN card', v: kyc.pan, mono: true },
    { k: 'Email', v: kyc.email },
    { k: 'Bank account', v: kyc.bankAccountNumber, mono: true },
    { k: 'Bank / IFSC', v: `${kyc.bankName ?? '—'} · ${kyc.ifsc ?? '—'}`, mono: true },
    { k: 'Address', v: kyc.address ?? '—' },
    { k: 'Submitted', v: fmtDateTime(kyc.createdAt) },
  ];

  return (
    <dl className="grid gap-3 sm:grid-cols-2">
      {items.map(item => (
        <div key={item.k} className="rounded-xl border border-ink/12 bg-paper-2/40 px-4 py-3">
          <dt className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">{item.k}</dt>
          <dd className={`mt-1 break-words text-[13.5px] font-medium text-ink ${item.mono ? 'font-mono' : ''}`}>
            {item.v}
          </dd>
        </div>
      ))}
    </dl>
  );
}

export function ApplicationFile({ loan: initialLoan, transactions = [] }: { loan: any; transactions?: any[] }) {
  const router = useRouter();
  const { toasts, push, dismiss } = useToasts();
  const [loan, setLoan] = useState<any>(initialLoan);
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [noteOpen, setNoteOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [adminNote, setAdminNote] = useState(initialLoan?.adminNote ?? '');
  const [selectedInstalmentId, setSelectedInstalmentId] = useState<string | null>(null);

  React.useEffect(() => {
    if (noteOpen) {
      setAdminNote(loan.adminNote ?? '');
    }
  }, [noteOpen, loan.adminNote]);

  async function handleAction(action: string, extra: any = {}) {
    const loadingKey = action === 'mark-paid' && extra.installmentId ? `emi-${extra.installmentId}` : action;
    setLoadingAction(loadingKey);
    try {
      const res = await fetch(`/api/admin/applications/${loan.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...extra }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Action failed');
      }

      const resData = await res.json();
      const updated = resData.loan || resData.application;
      if (updated) {
        setLoan(updated);
      } else {
        setLoan((prev: any) => ({
          ...prev,
          status: action === 'approve' ? 'approved' : action === 'disburse' ? 'active' : action === 'reject' ? 'rejected' : prev.status,
          adminNote: action === 'note' ? extra.note : prev.adminNote,
          rejectionReason: action === 'reject' ? extra.reason : prev.rejectionReason,
          decidedBy: action === 'approve' || action === 'reject' ? 'Rukmini Iyer' : prev.decidedBy,
        }));
      }

      push({
        tone: action === 'reject' ? 'info' : 'good',
        title: `${action.replace('-', ' ')} recorded`,
        body: loan.reference,
      });

      setRejectOpen(false);
      setNoteOpen(false);
      router.refresh();
    } catch (err: any) {
      push({ tone: 'bad', title: 'Action failed', body: err.message || '' });
    } finally {
      setLoadingAction(null);
    }
  }

  const terms = [
    { k: 'Principal', v: inr(loan.principal) },
    { k: 'Method', v: loan.interestMethod === 'flat' ? 'Flat rate' : 'Reducing balance' },
    { k: 'Monthly rate', v: `${loan.monthlyRatePct}%` },
    { k: 'Annualised (APR)', v: `${loan.annualRatePct}%` },
    { k: 'Interest payable', v: inr(loan.interest) },
    { k: `Processing fee (${loan.processingFeePct}%)`, v: inr(loan.processingFee) },
    { k: 'GST on fee', v: inr(loan.gst) },
    { k: 'Net disbursal', v: inr(loan.netDisbursal) },
    { k: 'Monthly EMI', v: inrExact(loan.emi) },
    { k: 'Total repayable', v: inr(loan.totalRepayable) },
    { k: 'First due', v: fmtDate(loan.firstDueDate) },
    { k: 'Maturity', v: fmtDate(loan.maturityDate) },
  ];

  return (
    <div className="grid gap-7">
      {/* Top Header */}
      <div className="flex flex-wrap items-start justify-between gap-6">
        <div>
          <nav className="flex items-center gap-2 font-mono text-[10.5px] uppercase tracking-[0.18em] text-ink-3">
            <Link href="/admin/applications" className="hover:text-accent">
              Applications
            </Link>
            <span>/</span>
            <span className="text-accent">{loan.reference}</span>
          </nav>
          <h1 className="mt-3 font-display text-[clamp(2rem,5vw,3.2rem)] font-black leading-none">
            {inr(loan.principal)} <span className="text-ink-3">over {loan.tenureMonths} months</span>
          </h1>
          <p className="mt-3 flex flex-wrap items-center gap-3 text-[13.5px] text-ink-3">
            <span className="flex items-center gap-2">
              <IconUsers width={14} height={14} /> {loan.userName} · +91 {loan.userMobile}
            </span>
            <span className="flex items-center gap-2">
              <IconClock width={14} height={14} /> submitted {relativeTime(loan.createdAt)}
            </span>
            <Badge tone={statusBadgeTones[loan.status] ?? 'slate'}>{loan.status}</Badge>
            {loan.kyc && (
              <Badge tone={loan.kyc.status === 'verified' ? 'green' : loan.kyc.status === 'rejected' ? 'rust' : 'amber'}>
                KYC {loan.kyc.status}
              </Badge>
            )}
          </p>
        </div>

        <div className="flex flex-col items-end gap-3">
          <span className="text-brand/70">
            <Seal short="Uma" size={92} />
          </span>
          <p className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-3">
            {loan.decidedBy ? `decided by ${loan.decidedBy}` : 'awaiting decision'}
          </p>
        </div>
      </div>

      {/* Action Bar Card */}
      <Card className="p-5">
        <div className="flex flex-wrap items-center gap-3">
          {loan.status === 'pending' && (
            <>
              <Button
                variant="primary"
                loading={loadingAction === 'approve'}
                onClick={() => handleAction('approve')}
              >
                <IconCheck width={15} height={15} /> Sanction this loan
              </Button>
              <Button variant="danger" onClick={() => setRejectOpen(true)}>
                <IconCross width={15} height={15} /> Reject
              </Button>
              {loan.kyc?.status === 'submitted' && (
                <Button
                  variant="outline"
                  loading={loadingAction === 'verify-kyc'}
                  onClick={() => handleAction('verify-kyc')}
                >
                  <IconShield width={15} height={15} /> Verify KYC only
                </Button>
              )}
            </>
          )}

          {loan.status === 'approved' && (
            <>
              <Button
                variant="accent"
                loading={loadingAction === 'disburse'}
                onClick={() => handleAction('disburse')}
              >
                <IconBank width={15} height={15} /> Disburse {inr(loan.netDisbursal)}
              </Button>
              <Button variant="danger" onClick={() => setRejectOpen(true)}>
                <IconCross width={15} height={15} /> Reject instead
              </Button>
            </>
          )}

          {loan.status === 'active' && (
            <Button
              variant="primary"
              loading={loadingAction === 'mark-paid'}
              onClick={() => handleAction('mark-paid', { installmentId: selectedInstalmentId || undefined })}
            >
              <IconRupee width={15} height={15} /> Record a cash EMI
            </Button>
          )}

          <Button variant="outline" onClick={() => setNoteOpen(true)}>
            <IconDoc width={15} height={15} /> Credit note
          </Button>

          <Link href="/" className="ml-auto">
            <Button variant="ghost">
              Open borrower site <IconArrow width={15} height={15} />
            </Button>
          </Link>
        </div>

        {loan.status === 'active' && (
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Field label="Collect against instalment">
              <Select
                value={selectedInstalmentId ?? ''}
                onChange={e => setSelectedInstalmentId(e.target.value || null)}
              >
                <option value="">Next unpaid instalment</option>
                {loan.schedule
                  ?.filter((s: any) => s.status !== 'paid')
                  .map((s: any) => (
                    <option key={s.id} value={s.id}>
                      #{s.number} · {fmtDate(s.dueDate)} · {inr(s.emi + (s.lateFee || 0))}{' '}
                      {s.status === 'overdue' ? '(overdue)' : ''}
                    </option>
                  ))}
              </Select>
            </Field>
          </div>
        )}
      </Card>

      {/* Terms and KYC / Progress Grid */}
      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <Card className="p-6">
          <SectionLabel>Sanction terms (frozen at application)</SectionLabel>
          <dl className="mt-5 grid gap-px overflow-hidden rounded-xl bg-ink/10 sm:grid-cols-2">
            {terms.map(t => (
              <div key={t.k} className="flex items-center justify-between gap-4 bg-[#fffaf1] px-4 py-3">
                <dt className="text-[12.5px] text-ink-3">{t.k}</dt>
                <dd className="font-mono text-[13px] font-semibold tabular text-ink">{t.v}</dd>
              </div>
            ))}
          </dl>

          {loan.adminNote && (
            <p className="mt-5 rounded-xl border border-brand/20 bg-brand/6 px-4 py-3 text-[13px] leading-relaxed text-brand">
              <strong className="font-semibold">Credit note:</strong> {loan.adminNote}
            </p>
          )}

          {loan.rejectionReason && (
            <p className="mt-5 flex items-start gap-2 rounded-xl border border-rust/25 bg-rust/8 px-4 py-3 text-[13px] leading-relaxed text-rust">
              <IconAlert width={15} height={15} className="mt-0.5 shrink-0" /> {loan.rejectionReason}
            </p>
          )}
        </Card>

        <div className="grid gap-6">
          <Card className="p-6">
            <SectionLabel>KYC submitted by the borrower</SectionLabel>
            <div className="mt-5">
              <KycPanel kyc={loan.kyc} />
            </div>
            {loan.kyc?.reviewedBy && (
              <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.14em] text-ink-3">
                reviewed by {loan.kyc.reviewedBy} · {fmtDateTime(loan.kyc.reviewedAt)}
              </p>
            )}
          </Card>

          <Card className="p-6">
            <SectionLabel>Repayment progress</SectionLabel>
            <div className="mt-5">
              <Progress value={loan.progress || 0} tone="accent" />
              <div className="mt-2 flex justify-between font-mono text-[11px] text-ink-3">
                <span>
                  {loan.paidCount || 0}/{loan.totalInstallments || loan.tenureMonths} EMIs
                </span>
                <span>{inr(loan.paidAmount || 0)} collected</span>
              </div>
            </div>
            <div className="mt-5 grid gap-2">
              {[
                { k: 'Outstanding principal', v: inr(loan.outstandingPrincipal || 0) },
                { k: 'Remaining repayment', v: inr(loan.remainingRepayment || 0) },
                { k: 'Overdue instalments', v: String(loan.overdueCount || 0) },
                { k: 'Disbursed', v: loan.disbursedAt ? fmtDate(loan.disbursedAt) : 'not yet' },
              ].map(item => (
                <div key={item.k} className="flex items-center justify-between gap-3 border-b border-ink/8 pb-2 text-[12.5px] last:border-0">
                  <span className="text-ink-3">{item.k}</span>
                  <span className="font-mono font-semibold tabular">{item.v}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Instalment Schedule Card */}
      <Card className="overflow-hidden p-0">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-ink/10 px-6 py-5">
          <div>
            <SectionLabel>Instalment schedule</SectionLabel>
            <h2 className="mt-2.5 font-display text-[21px] font-bold leading-tight">
              {loan.schedule && loan.schedule.length > 0
                ? `${loan.schedule.length} instalments generated at disbursal`
                : 'Generated on disbursal'}
            </h2>
          </div>
          {loan.schedule && loan.schedule.length > 0 && (
            <span className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-3">
              {loan.schedule.filter((s: any) => s.status === 'paid').length} paid ·{' '}
              {loan.schedule.filter((s: any) => s.status === 'overdue').length} overdue
            </span>
          )}
        </div>

        {!loan.schedule || loan.schedule.length === 0 ? (
          <p className="px-6 py-12 text-center text-[13.5px] text-ink-3">
            Sanction the loan and disburse it — the schedule is written from the frozen rate snapshot at that moment.
          </p>
        ) : (
          <div className="max-h-[420px] overflow-auto">
            <table className="w-full border-collapse text-left">
              <thead className="sticky top-0 z-10 bg-paper-2/90 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3 backdrop-blur">
                <tr>
                  <th className="px-5 py-3">#</th>
                  <th className="px-5 py-3">Due</th>
                  <th className="px-5 py-3 text-right">Principal</th>
                  <th className="px-5 py-3 text-right">Interest</th>
                  <th className="px-5 py-3 text-right">EMI</th>
                  <th className="px-5 py-3 text-right">Balance</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Collect</th>
                </tr>
              </thead>
              <tbody className="font-mono text-[12.5px] tabular">
                {loan.schedule.map((s: any) => (
                  <tr key={s.id} className="ledger-row border-t border-ink/10">
                    <td className="px-5 py-3 text-accent">{s.number}</td>
                    <td className="px-5 py-3 text-ink-2">{fmtDate(s.dueDate)}</td>
                    <td className="px-5 py-3 text-right">{inr(s.principalPart)}</td>
                    <td className="px-5 py-3 text-right text-ink-3">{inr(s.interestPart)}</td>
                    <td className="px-5 py-3 text-right font-semibold">{inr(s.emi)}</td>
                    <td className="px-5 py-3 text-right text-ink-3">{inr(s.closingBalance)}</td>
                    <td className="px-5 py-3">
                      {s.status === 'paid' ? (
                        <span className="inline-flex items-center gap-1.5 text-moss">
                          <IconCheck width={12} height={12} /> paid {s.paidAt ? fmtDate(s.paidAt) : ''}
                        </span>
                      ) : s.status === 'overdue' ? (
                        <span className="font-semibold text-rust">
                          {s.overdueByDays}d overdue · +{inr(s.lateFee || 0)} fee
                        </span>
                      ) : s.status === 'due' ? (
                        <span className="font-semibold text-[#8a5d0d]">due now</span>
                      ) : (
                        <span className="text-ink-3">upcoming</span>
                      )}
                    </td>
                    <td className="px-5 py-3 text-right">
                      {loan.status === 'active' && s.status !== 'paid' && (
                        <Button
                          size="sm"
                          variant="outline"
                          loading={loadingAction === `emi-${s.id}`}
                          onClick={() => handleAction('mark-paid', { installmentId: s.id })}
                        >
                          Collect
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Ledger Entries Card */}
      <Card className="overflow-hidden p-0">
        <div className="border-b border-ink/10 px-6 py-5">
          <SectionLabel>Ledger entries</SectionLabel>
          <h2 className="mt-2.5 font-display text-[21px] font-bold leading-tight">
            Money that moved on this file
          </h2>
        </div>
        {transactions.length === 0 ? (
          <p className="px-6 py-10 text-center text-[13.5px] text-ink-3">No entries yet.</p>
        ) : (
          <ul className="divide-y divide-ink/10">
            {transactions.map(t => (
              <li key={t.id} className="ledger-row flex items-center justify-between gap-4 px-6 py-3.5">
                <span className="flex min-w-0 items-center gap-3">
                  <span
                    className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${
                      t.amount >= 0 ? 'bg-moss/12 text-moss' : 'bg-rust/10 text-rust'
                    }`}
                  >
                    {t.type === 'disbursement' ? (
                      <IconBank width={15} height={15} />
                    ) : t.type === 'repayment' ? (
                      <IconRupee width={15} height={15} />
                    ) : (
                      <IconStamp width={15} height={15} />
                    )}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-[13.5px] font-semibold capitalize text-ink">
                      {t.type.replace('_', ' ')}
                    </span>
                    <span className="block truncate font-mono text-[11px] text-ink-3">
                      {t.note ?? t.reference} · {fmtDateTime(t.createdAt)}
                    </span>
                  </span>
                </span>
                <span className={`shrink-0 font-mono text-[14px] font-semibold tabular ${t.amount >= 0 ? 'text-moss' : 'text-rust'}`}>
                  {t.amount >= 0 ? '+' : '−'}
                  {inr(Math.abs(t.amount))}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {/* Modals */}
      <Modal open={rejectOpen} onClose={() => setRejectOpen(false)} title={`Reject ${loan.reference}`} width="max-w-md">
        <div className="grid gap-4">
          <Field label="Reason shown to the borrower">
            <Textarea
              value={rejectionReason}
              onChange={e => setRejectionReason(e.target.value)}
              placeholder="Insufficient cash flow in the last 3 statements"
            />
          </Field>
          <div className="flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setRejectOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              loading={loadingAction === 'reject'}
              onClick={() => handleAction('reject', { reason: rejectionReason.trim() || undefined })}
            >
              Reject application
            </Button>
          </div>
        </div>
      </Modal>

      <Modal
        open={noteOpen}
        onClose={() => setNoteOpen(false)}
        title="Credit note"
        subtitle="Visible to the borrower on their sanction letter."
        width="max-w-md"
      >
        <div className="grid gap-4">
          <Field label="Note">
            <Textarea
              autoFocus
              rows={4}
              value={adminNote}
              onChange={e => setAdminNote(e.target.value)}
              placeholder="Repeat borrower, clean ledger — fast-track."
            />
          </Field>
          <div className="flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setNoteOpen(false)}>
              Cancel
            </Button>
            <Button
              loading={loadingAction === 'note'}
              onClick={() => handleAction('note', { note: adminNote })}
            >
              Save note
            </Button>
          </div>
        </div>
      </Modal>

      <ToastStack toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
