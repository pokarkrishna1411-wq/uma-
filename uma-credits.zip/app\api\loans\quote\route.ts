import { NextRequest, NextResponse } from 'next/server';
import { getAppSettings } from '@/lib/db';
import { calculateLoan } from '@/lib/loan-math';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const amount = parseFloat(searchParams.get('amount') || searchParams.get('principal') || '10000');
  const tenure = parseInt(searchParams.get('tenure') || searchParams.get('tenureMonths') || '6');

  const { pricing } = getAppSettings();
  const quote = calculateLoan({
    principal: amount,
    tenureMonths: tenure,
    pricing,
  });

  return NextResponse.json({ quote });
}
