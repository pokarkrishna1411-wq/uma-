'use client';

import React, { useState, useEffect } from 'react';
import {
  IconBank,
  IconRupee,
  IconDoc,
  IconAlert,
  IconCoins,
} from '@/components/icons';
import {
  Card,
  SectionLabel,
  Select,
  Skeleton,
  ToastStack,
  useToasts,
  inr,
  fmtDateTime,
} from '@/components/ui';

export function LedgerView() {
  const { toasts, push, dismiss } = useToasts();
  const [entryType, setEntryType] = useState('all');
  const [transactions, setTransactions] = useState<any[]>([]);
  const [totals, setTotals] = useState({ disbursed: 0, collected: 0, fees: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);

    fetch(`/api/admin/ledger?type=${entryType}&limit=200`)
      .then(res => res.json())
      .then(data => {
        if (!active) return;
        const txs = data.ledger || data.transactions || [];
        setTransactions(txs);
        const disbursed = txs
          .filter((t: any) => t.type === 'disbursement')
          .reduce((sum: number, t: any) => sum + Math.abs(t.amount), 0);
        const collected = txs
          .filter((t: any) => t.type === 'repayment')
          .reduce((sum: number, t: any) => sum + Math.abs(t.amount), 0);
        const fees = txs
          .filter((t: any) => t.type === 'processing_fee' || t.type === 'late_fee')
          .reduce((sum: number, t: any) => sum + Math.abs(t.amount), 0);

        setTotals({ disbursed, collected, fees });
      })
      .catch((err: any) => {
        push({ tone: 'bad', title: 'Could not load the ledger', body: err.message || '' });
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [entryType, push]);

  const typeIcons: Record<string, React.ReactNode> = {
    disbursement: <IconBank width={15} height={15} />,
    repayment: <IconRupee width={15} height={15} />,
    processing_fee: <IconDoc width={15} height={15} />,
    late_fee: <IconAlert width={15} height={15} />,
    refund: <IconCoins width={15} height={15} />,
  };

  return (
    <div className="grid gap-7">
      <header className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <SectionLabel>Money ledger</SectionLabel>
          <h1 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] font-black leading-none">
            Every rupee that moved.
          </h1>
          <p className="mt-3 max-w-xl text-[14px] text-ink-3">
            Disbursals, EMIs, processing fees and late charges across the whole book — the same register borrowers see, unmasked.
          </p>
        </div>
        <div className="flex gap-3">
          <Select value={entryType} onChange={e => setEntryType(e.target.value)} className="w-52">
            <option value="all">All entry types</option>
            <option value="disbursement">Disbursals</option>
            <option value="repayment">Repayments</option>
            <option value="processing_fee">Processing fees</option>
            <option value="late_fee">Late fees</option>
          </Select>
        </div>
      </header>

      {/* Summary totals */}
      <div className="grid gap-px overflow-hidden rounded-[20px] border border-ink/12 bg-ink/12 sm:grid-cols-3">
        {[
          { k: 'Disbursed', v: inr(totals.disbursed), tone: 'text-brand' },
          { k: 'Collected', v: inr(totals.collected), tone: 'text-moss' },
          { k: 'Fees earned', v: inr(totals.fees), tone: 'text-accent' },
        ].map(item => (
          <div key={item.k} className="bg-[#fffaf1] px-6 py-5">
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-ink-3">{item.k}</p>
            <p className={`mt-2 font-display text-[30px] font-black leading-none tabular ${item.tone}`}>
              {item.v}
            </p>
          </div>
        ))}
      </div>

      {/* Ledger Table Card */}
      <Card className="overflow-hidden p-0">
        {loading ? (
          <div className="grid gap-3 p-6">
            {[0, 1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <div className="p-6 text-center text-[13.5px] text-ink-3">No entries of this type yet</div>
        ) : (
          <div className="max-h-[640px] overflow-auto">
            <table className="w-full border-collapse text-left">
              <thead className="sticky top-0 z-10 bg-paper-2/90 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3 backdrop-blur">
                <tr>
                  <th className="px-5 py-3">When</th>
                  <th className="px-5 py-3">Borrower</th>
                  <th className="px-5 py-3">Loan</th>
                  <th className="px-5 py-3">Type</th>
                  <th className="px-5 py-3">Mode</th>
                  <th className="px-5 py-3 text-right">Amount</th>
                </tr>
              </thead>
              <tbody className="text-[13px]">
                {transactions.map(t => (
                  <tr key={t.id} className="ledger-row border-t border-ink/10">
                    <td className="px-5 py-3 font-mono text-[11.5px] text-ink-3">{fmtDateTime(t.createdAt)}</td>
                    <td className="px-5 py-3">
                      <span className="font-semibold text-ink">{t.userName ?? '—'}</span>
                      {t.userMobile && <span className="ml-2 font-mono text-[11px] text-ink-3">+91 {t.userMobile}</span>}
                    </td>
                    <td className="px-5 py-3 font-mono text-[11.5px] text-accent">
                      {t.loanReference ?? '—'}
                    </td>
                    <td className="px-5 py-3">
                      <span className="flex items-center gap-2 capitalize text-ink-2">
                        <span className={t.amount >= 0 ? 'text-moss' : 'text-rust'}>
                          {typeIcons[t.type] || <IconDoc width={15} height={15} />}
                        </span>
                        {t.type.replace('_', ' ')}
                      </span>
                    </td>
                    <td className="px-5 py-3 font-mono text-[11.5px] uppercase text-ink-3">{t.mode}</td>
                    <td
                      className={`px-5 py-3 text-right font-mono font-semibold tabular ${
                        t.amount >= 0 ? 'text-moss' : 'text-rust'
                      }`}
                    >
                      {t.amount >= 0 ? '+' : '−'}
                      {inr(Math.abs(t.amount))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <ToastStack toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
