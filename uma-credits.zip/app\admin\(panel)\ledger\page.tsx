import React from 'react';
import { LedgerView } from '@/components/admin/ledger-view';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function LedgerPage() {
  return <LedgerView />;
}
