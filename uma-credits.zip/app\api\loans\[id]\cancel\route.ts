import { NextRequest, NextResponse } from 'next/server';
import { getLoanById, handleLoanAction } from '@/lib/db';
import { getCurrentUser } from '@/lib/auth';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const loan = getLoanById(params.id);
  if (!loan) {
    return NextResponse.json({ error: 'Loan not found' }, { status: 404 });
  }

  if (loan.status !== 'pending') {
    return NextResponse.json({ error: 'Only pending applications can be cancelled' }, { status: 400 });
  }

  const updatedLoan = handleLoanAction(loan.id, 'reject', { reason: 'Cancelled by borrower' }, 'Borrower');
  return NextResponse.json({ loan: updatedLoan, success: true });
}
