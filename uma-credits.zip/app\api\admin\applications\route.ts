import { NextRequest, NextResponse } from 'next/server';
import { getAllLoans } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status');
  const q = searchParams.get('q')?.toLowerCase().trim();
  const limit = parseInt(searchParams.get('limit') || '100');

  let allLoans = getAllLoans();

  if (q) {
    allLoans = allLoans.filter(l =>
      l.reference.toLowerCase().includes(q) ||
      (l.userName && l.userName.toLowerCase().includes(q)) ||
      (l.userMobile && l.userMobile.includes(q)) ||
      (l.purpose && l.purpose.toLowerCase().includes(q)) ||
      (l.kyc?.pan && l.kyc.pan.toLowerCase().includes(q)) ||
      (l.kyc?.fullName && l.kyc.fullName.toLowerCase().includes(q)) ||
      (l.kyc?.bankAccountNumber && l.kyc.bankAccountNumber.includes(q))
    );
  }

  const counts = {
    all: allLoans.length,
    pending: allLoans.filter(l => l.status === 'pending').length,
    approved: allLoans.filter(l => l.status === 'approved').length,
    active: allLoans.filter(l => l.status === 'active').length,
    closed: allLoans.filter(l => l.status === 'closed').length,
    rejected: allLoans.filter(l => l.status === 'rejected').length,
  };

  let filtered = allLoans;
  if (status && status !== 'all') {
    filtered = filtered.filter(l => l.status === status);
  }

  return NextResponse.json({
    applications: filtered.slice(0, limit),
    total: filtered.length,
    counts,
  });
}
