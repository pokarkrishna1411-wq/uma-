import { NextRequest, NextResponse } from 'next/server';
import { deleteSession } from '@/lib/db';
import { ADMIN_COOKIE } from '@/lib/auth';

export async function POST(req: NextRequest) {
  const token = req.cookies.get(ADMIN_COOKIE)?.value;
  if (token) {
    deleteSession(token);
  }
  const response = NextResponse.json({ success: true });
  response.cookies.delete(ADMIN_COOKIE);
  return response;
}
