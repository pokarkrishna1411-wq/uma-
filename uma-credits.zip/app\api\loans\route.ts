import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getUserLoans, createLoanApplication, upsertBorrower, createSession } from '@/lib/db';
import { USER_COOKIE } from '@/lib/auth';

export async function GET() {
  const user = getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const loans = getUserLoans(user.id);
  return NextResponse.json({ loans });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    let user = getCurrentUser();

    // If not logged in, we can login / upsert using KYC name & mobile
    if (!user) {
      const { kycData } = body;
      if (!kycData || !kycData.fullName || !kycData.mobile) {
        return NextResponse.json({ error: 'Please log in or provide KYC details' }, { status: 401 });
      }
      user = upsertBorrower(kycData.fullName, kycData.mobile);
    }

    if (user.status === 'blocked') {
      return NextResponse.json({ error: 'Your account is blocked. Please contact support.' }, { status: 403 });
    }

    const { principal, tenureMonths, purpose, kycData } = body;

    if (!principal || !tenureMonths) {
      return NextResponse.json({ error: 'Principal amount and tenure are required' }, { status: 400 });
    }

    if (!kycData || !kycData.pan || !kycData.bankAccountNumber || !kycData.ifsc) {
      return NextResponse.json({ error: 'Please fill in all required KYC details' }, { status: 400 });
    }

    // Validate PAN
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
    if (!panRegex.test(kycData.pan.trim().toUpperCase())) {
      return NextResponse.json({ error: 'Invalid PAN format. Must be 5 letters, 4 digits, 1 letter.' }, { status: 400 });
    }

    const loan = createLoanApplication({
      userId: user.id,
      principal: Number(principal),
      tenureMonths: Number(tenureMonths),
      purpose: purpose || 'business',
      kycData: {
        fullName: kycData.fullName || user.name,
        mobile: kycData.mobile || user.mobile,
        email: kycData.email,
        pan: kycData.pan.trim().toUpperCase(),
        bankAccountNumber: kycData.bankAccountNumber.trim(),
        bankName: kycData.bankName || 'Bank',
        ifsc: kycData.ifsc.trim().toUpperCase(),
        address: kycData.address,
      },
    });

    const response = NextResponse.json({ loan });
    // Ensure cookie is set
    const token = createSession('user', user.id);
    response.cookies.set({
      name: USER_COOKIE,
      value: token,
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60,
    });

    return response;
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Application failed' }, { status: 500 });
  }
}
