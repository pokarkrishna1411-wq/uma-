import React from 'react';
import { notFound } from 'next/navigation';
import { getLoanById, getTransactionsByLoanId } from '@/lib/db';
import { ApplicationFile } from '@/components/admin/application-file';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function ApplicationDetailPage({
  params,
}: {
  params: { id: string };
}) {
  const loan = getLoanById(params.id);
  if (!loan) {
    notFound();
  }

  const transactions = getTransactionsByLoanId(loan.id);

  return <ApplicationFile loan={loan} transactions={transactions} />;
}
