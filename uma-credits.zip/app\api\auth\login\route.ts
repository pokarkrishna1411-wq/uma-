import { NextRequest, NextResponse } from 'next/server';
import { upsertBorrower, createSession } from '@/lib/db';
import { USER_COOKIE } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, mobile } = body;

    if (!mobile) {
      return NextResponse.json({ error: 'Mobile number is required' }, { status: 400 });
    }

    const cleanMobile = String(mobile).replace(/\D/g, '').slice(-10);
    if (cleanMobile.length !== 10) {
      return NextResponse.json({ error: 'Please enter a valid 10-digit mobile number' }, { status: 400 });
    }

    const borrowerName = (name && String(name).trim()) || 'Borrower';
    const user = upsertBorrower(borrowerName, cleanMobile);

    if (user.status === 'blocked') {
      return NextResponse.json({ error: 'This mobile number is blocked. Please contact support.' }, { status: 403 });
    }

    const token = createSession('user', user.id);

    const response = NextResponse.json({ user, token });
    response.cookies.set({
      name: USER_COOKIE,
      value: token,
      httpOnly: true,
      path: '/',
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60,
    });

    return response;
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Login failed' }, { status: 500 });
  }
}
