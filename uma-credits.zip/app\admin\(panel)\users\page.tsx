import React from 'react';
import { UsersManager } from '@/components/admin/users-manager';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function UsersPage() {
  return <UsersManager />;
}
