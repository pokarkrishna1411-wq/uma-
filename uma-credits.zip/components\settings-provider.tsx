'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { PricingSettings } from '@/lib/loan-math';

interface SettingsContextType {
  settings: Record<string, string>;
  pricing: PricingSettings;
  parsed: Record<string, any>;
  text: (key: string, fallback?: string) => string;
  num: (key: string, fallback?: number) => number;
  refresh: () => Promise<void>;
}

const defaultPricing: PricingSettings = {
  interestMethod: 'reducing',
  monthlyRatePct: 1.75,
  annualRatePct: 21,
  processingFeePct: 2,
  gstPct: 18,
  lateFee: 250,
  bounceCharges: 350,
  minLoan: 1000,
  maxLoan: 200000,
  stepAmount: 500,
  defaultTenure: 6,
  graceDays: 5,
  tenures: [
    { months: 3, label: '3 months · quick top-up' },
    { months: 6, label: '6 months · most popular' },
    { months: 9, label: '9 months' },
    { months: 12, label: '12 months · stock cycle' },
    { months: 18, label: '18 months' },
    { months: 24, label: '24 months · equipment' },
  ],
  quickAmounts: [1000, 5000, 10000, 25000, 50000, 100000],
  purposes: [
    { value: 'business', label: 'Business & working capital' },
    { value: 'inventory', label: 'Festival inventory' },
    { value: 'equipment', label: 'Equipment & machinery' },
    { value: 'medical', label: 'Medical emergency' },
    { value: 'education', label: 'Education' },
    { value: 'personal', label: 'Personal need' },
  ],
  acceptingApplications: true,
  maxActiveLoans: 2,
  prepaymentAllowed: true,
  prepaymentPenaltyPct: 0,
};

const SettingsContext = createContext<SettingsContextType>({
  settings: {},
  pricing: defaultPricing,
  parsed: {},
  text: () => '',
  num: () => 0,
  refresh: async () => {},
});

export function SettingsProvider({
  children,
  initial,
}: {
  children: React.ReactNode;
  initial?: { settings?: Record<string, string>; pricing?: PricingSettings };
}) {
  const [settings, setSettings] = useState<Record<string, string>>(initial?.settings || {});
  const [pricing, setPricing] = useState<PricingSettings>(initial?.pricing || defaultPricing);

  const parseJsonField = useCallback(
    (key: string, fallback: any) => {
      try {
        const val = settings[key];
        return val ? JSON.parse(val) : fallback;
      } catch {
        return fallback;
      }
    },
    [settings]
  );

  const parsed = {
    howItWorks: parseJsonField('how_it_works', []),
    valueProps: parseJsonField('value_props', []),
    loanInstructions: parseJsonField('loan_instructions', []),
    repaymentModes: parseJsonField('repayment_modes', []),
    eligibilityCriteria: parseJsonField('eligibility_criteria', []),
    documentsRequired: parseJsonField('documents_required', []),
    borrowerStories: parseJsonField('borrower_stories', []),
    faq: parseJsonField('faq', []),
  };

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`/api/settings?_t=${Date.now()}`, { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.values) setSettings(data.values);
        if (data.pricing) setPricing(data.pricing);
      }
    } catch (err) {
      console.error('Failed to refresh settings', err);
    }
  }, []);

  const text = useCallback(
    (key: string, fallback = '') => {
      return settings[key] !== undefined && settings[key] !== null ? settings[key] : fallback;
    },
    [settings]
  );

  const num = useCallback(
    (key: string, fallback = 0) => {
      const v = parseFloat(settings[key]);
      return isNaN(v) ? fallback : v;
    },
    [settings]
  );

  useEffect(() => {
    const handleBump = () => {
      refresh();
    };
    window.addEventListener('settings:bump', handleBump);
    return () => window.removeEventListener('settings:bump', handleBump);
  }, [refresh]);

  return (
    <SettingsContext.Provider value={{ settings, pricing, parsed, text, num, refresh }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  return useContext(SettingsContext);
}
