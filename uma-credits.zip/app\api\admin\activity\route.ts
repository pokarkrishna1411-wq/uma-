import { NextRequest, NextResponse } from 'next/server';
import { getAllActivity } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const operator = searchParams.get('operator');
  const limit = parseInt(searchParams.get('limit') || '200');

  let activity = getAllActivity();

  if (operator && operator !== 'all') {
    activity = activity.filter(a => a.actorName === operator);
  }

  return NextResponse.json({
    activity: activity.slice(0, limit),
    logs: activity.slice(0, limit),
  });
}
