import React from 'react';

export function KinaraSeal({ size = 62, className = '', short = 'Uma' }: { size?: number; className?: string; short?: string }) {
  const rOuter = size / 2 - 1.5;
  const rInner = size * 0.355;
  const pathR = size * 0.42;
  const pathD = `M ${size / 2}, ${size / 2} m -${pathR}, 0 a ${pathR},${pathR} 0 1,1 ${pathR * 2},0 a ${pathR},${pathR} 0 1,1 -${pathR * 2},0`;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className={className} aria-hidden="true">
      <circle cx={size / 2} cy={size / 2} r={rOuter} fill="none" stroke="currentColor" strokeWidth="1.4" opacity="0.55" />
      <circle cx={size / 2} cy={size / 2} r={rInner} fill="none" stroke="currentColor" strokeWidth="0.9" strokeDasharray="3 3" opacity="0.5" />
      <defs>
        <path id={`seal-${size}`} d={pathD} />
      </defs>
      <text fontSize={size * 0.108} fontFamily="IBM Plex Mono, monospace" letterSpacing="1.6" fill="currentColor">
        <textPath href={`#seal-${size}`} startOffset="8%">
          UMA CREDITS · SANCTIONED ·
        </textPath>
      </text>
      <text
        x={size / 2}
        y={size * 0.583}
        textAnchor="middle"
        fontSize={size * 0.227}
        fontFamily="Fraunces, serif"
        fontWeight="800"
        fill="currentColor"
      >
        ₹
      </text>
    </svg>
  );
}

export function IconArrow({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M4 12h15M13.5 6.5L20 12l-6.5 5.5" />
    </svg>
  );
}

export function IconCheck({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M4.5 12.8l4.6 4.4L19.5 6.6" />
    </svg>
  );
}

export function IconShield({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M12 3l7 2.6v5.2c0 4.3-2.9 8.2-7 10.2-4.1-2-7-5.9-7-10.2V5.6z" />
      <path d="M9.2 12.2l2 2 3.6-4" />
    </svg>
  );
}

export function IconCoins({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <ellipse cx="9" cy="7" rx="5.5" ry="2.6" />
      <path d="M3.5 7v4c0 1.4 2.5 2.6 5.5 2.6s5.5-1.2 5.5-2.6V7" />
      <path d="M9.5 16.4c0 1.4 2.5 2.6 5.5 2.6s5.5-1.2 5.5-2.6v-4c0-1.1-1.5-2-3.5-2.4" />
      <ellipse cx="15" cy="12.4" rx="5.5" ry="2.6" />
    </svg>
  );
}

export function IconPercent({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M7 4h10M7 8.5h10M16.5 4c0 3.6-2.4 4.5-5 4.5H7l8.5 11" />
    </svg>
  );
}

export function IconDoc({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M6 3.5h8l4 4v13H6z" />
      <path d="M14 3.5v4h4M9 12h6M9 15.5h6M9 8.5h2.5" />
    </svg>
  );
}

export function IconCalendar({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <rect x="3.8" y="5.2" width="16.4" height="15" rx="2" />
      <path d="M3.8 10h16.4M8.5 3.5v3.4M15.5 3.5v3.4" />
    </svg>
  );
}

export function IconClock({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M12 7.2V12l3.4 2.2" />
    </svg>
  );
}

export function IconShop({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M9 3.5h6l-.8 5.2a2.6 2.6 0 0 0 2.6 3H18a2 2 0 0 1 2 2v1.3H4V13.7a2 2 0 0 1 2-2h1.2a2.6 2.6 0 0 0 2.6-3z" />
      <path d="M4 18.5h16v2H4z" />
    </svg>
  );
}

export function IconPhone({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <rect x="6.5" y="2.5" width="11" height="19" rx="2.4" />
      <path d="M10.6 5.4h2.8M11 18.6h2" />
    </svg>
  );
}

export function IconUsers({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <circle cx="9" cy="8" r="3.2" />
      <path d="M3.5 19.5c.6-3.2 2.9-5 5.5-5s4.9 1.8 5.5 5" />
      <path d="M16 5.4a3 3 0 0 1 0 5.6M17.5 14.9c2 .6 3.3 2.3 3.7 4.6" />
    </svg>
  );
}

export function IconLock({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <rect x="4.8" y="10.4" width="14.4" height="9.4" rx="2" />
      <path d="M8.4 10.4V7.8a3.6 3.6 0 0 1 7.2 0v2.6M12 14.2v2.4" />
    </svg>
  );
}

export function IconChart({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M4 19.5h16" />
      <path d="M7 19.5V11M11.5 19.5V5.5M16 19.5v-6" />
    </svg>
  );
}

export function IconSparkles({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M12 3.5l1.9 5.1 5.1 1.9-5.1 1.9L12 17.5l-1.9-5.1L5 10.5l5.1-1.9z" />
      <path d="M18.5 16.5l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z" />
    </svg>
  );
}

export function IconGear({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <circle cx="12" cy="12" r="3.1" />
      <path d="M12 2.8l1.3 2.4 2.7-.5.5 2.7 2.4 1.3-1.4 2.3 1.4 2.3-2.4 1.3-.5 2.7-2.7-.5L12 21.2l-1.3-2.4-2.7.5-.5-2.7L5.1 15.3l1.4-2.3-1.4-2.3 2.4-1.3.5-2.7 2.7.5z" />
    </svg>
  );
}

export function IconBook({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M4.5 3.5h11a3 3 0 0 1 3 3v14h-11a3 3 0 0 1-3-3z" />
      <path d="M4.5 17.5A3 3 0 0 1 7.5 15h11" />
      <path d="M8.5 7.5h6M8.5 10.5h4" />
    </svg>
  );
}

export function IconClose({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}

export const IconCross = IconClose;

export function IconAlert({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M12 4l9 15.5H3z" />
      <path d="M12 9.5v4.2M12 16.6v.2" />
    </svg>
  );
}

export function IconBan({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <circle cx="12" cy="12" r="8.6" />
      <path d="M6 6l12 12" />
    </svg>
  );
}

export function IconDownload({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M12 3.5v11M7.5 10.5L12 15l4.5-4.5M4.5 19.5h15" />
    </svg>
  );
}

export function IconEye({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M2.6 12S6 6.2 12 6.2 21.4 12 21.4 12 18 17.8 12 17.8 2.6 12 2.6 12z" />
      <circle cx="12" cy="12" r="2.8" />
    </svg>
  );
}

export function IconFilter({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M3.8 5.5h16.4l-6.4 7.4v6l-3.6 1.8v-7.8z" />
    </svg>
  );
}

export function IconLogout({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M14 4.5H6.5v15H14M11 12h9M17 8.5l3.5 3.5L17 15.5" />
    </svg>
  );
}

export function IconMenu({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M4 7h16M4 12h16M4 17h16" />
    </svg>
  );
}

export function IconSearch({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <circle cx="10.8" cy="10.8" r="6.3" />
      <path d="M15.4 15.4L20 20" />
    </svg>
  );
}

export function IconStamp({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M9 3.5h6l-.8 5.2a2.6 2.6 0 0 0 2.6 3H18a2 2 0 0 1 2 2v1.3H4V13.7a2 2 0 0 1 2-2h1.2a2.6 2.6 0 0 0 2.6-3z" />
      <path d="M4 18.5h16v2H4z" />
    </svg>
  );
}

export function IconSpark({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M12 3.5l1.9 5.1 5.1 1.9-5.1 1.9L12 17.5l-1.9-5.1L5 10.5l5.1-1.9z" />
      <path d="M18.5 16.5l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7z" />
    </svg>
  );
}

export function IconBank({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M3 21h18M3 10h18M5 6l7-3 7 3M4 10v11M20 10v11M8 14v4M12 14v4M16 14v4" />
    </svg>
  );
}

export function IconRupee({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M6 3h12M6 8h12M6 13l7.5 8M6 8h6a4 4 0 0 0 0-8" />
    </svg>
  );
}

export function IconChevronDown({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}

export function IconTrash({ width = 16, height = 16, className = '' }: { width?: number; height?: number; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width={width} height={height} className={className}>
      <path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2M10 11v6M14 11v6" />
    </svg>
  );
}

export const IconLedger = IconBook;
export const Seal = KinaraSeal;
export const UmaSeal = KinaraSeal;

