'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { User, LoanApplication, Transaction } from '@/lib/db';
import { formatINR, formatNumberINR } from '@/lib/loan-math';
import {
  KinaraSeal,
  IconArrow,
  IconCheck,
  IconCoins,
  IconDoc,
  IconShield,
  IconCalendar,
  IconClock,
  IconClose,
} from '@/components/icons';

export function DashboardClient({
  user,
  initialLoans,
  initialTransactions,
}: {
  user: User;
  initialLoans: LoanApplication[];
  initialTransactions: Transaction[];
}) {
  const router = useRouter();
  const [loans, setLoans] = useState<LoanApplication[]>(initialLoans);
  const [transactions, setTransactions] = useState<Transaction[]>(initialTransactions);
  const [selectedLoanForPay, setSelectedLoanForPay] = useState<LoanApplication | null>(null);
  const [selectedLoanForLetter, setSelectedLoanForLetter] = useState<LoanApplication | null>(null);
  const [forecloseMode, setForecloseMode] = useState(false);
  const [payMode, setPayMode] = useState('upi');
  const [isPaying, setIsPaying] = useState(false);
  const [message, setMessage] = useState('');

  const activeLoans = loans.filter(l => l.status === 'active');
  const totalOutstanding = activeLoans.reduce((sum, l) => sum + (l.remainingRepayment || 0), 0);
  const totalPaid = loans.reduce((sum, l) => sum + (l.paidAmount || 0), 0);

  // Find earliest next due
  let nextDueLoan: LoanApplication | null = null;
  let nextDueInfo: any = null;
  for (const l of activeLoans) {
    if (l.nextDue) {
      if (!nextDueInfo || new Date(l.nextDue.dueDate) < new Date(nextDueInfo.dueDate)) {
        nextDueInfo = l.nextDue;
        nextDueLoan = l;
      }
    }
  }

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    router.refresh();
  }

  async function executePayment() {
    if (!selectedLoanForPay) return;
    setIsPaying(true);
    setMessage('');
    try {
      const res = await fetch(`/api/loans/${selectedLoanForPay.id}/pay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          foreclose: forecloseMode,
          mode: payMode,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Payment failed');

      // Refresh data
      const meRes = await fetch('/api/me');
      if (meRes.ok) {
        const meData = await meRes.json();
        setLoans(meData.loans || []);
        setTransactions(meData.transactions || []);
      }
      setSelectedLoanForPay(null);
      setMessage(forecloseMode ? 'Loan successfully foreclosed!' : 'EMI payment settled successfully!');
    } catch (err: any) {
      alert(err.message || 'Payment failed');
    } finally {
      setIsPaying(false);
    }
  }

  return (
    <div className="min-h-screen bg-paper text-ink pb-20">
      {/* Top Banner / Header */}
      <header className="sticky top-0 z-30 border-b border-ink/10 bg-paper/95 backdrop-blur-md">
        <div className="mx-auto flex h-[68px] max-w-[1240px] items-center justify-between px-5 lg:px-8">
          <Link className="flex items-center gap-3" href="/">
            <span className="grid h-9 w-9 place-items-center rounded-[10px] font-display text-[17px] font-black bg-accent text-[#fff6ec]">
              U
            </span>
            <span className="leading-none">
              <span className="block font-display text-[17px] font-bold tracking-tight text-ink">Uma Credits</span>
              <span className="mt-0.5 block font-mono text-[9.5px] uppercase tracking-[0.24em] text-ink-3">Borrower Portal</span>
            </span>
          </Link>

          <div className="flex items-center gap-4">
            <Link
              href="/apply"
              className="inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-[13px] font-bold text-[#fff6ec] shadow-[0_8px_18px_-12px_rgba(228,87,46,0.9)] hover:bg-accent-2"
            >
              + New Loan
            </Link>
            <button
              onClick={handleLogout}
              className="rounded-full border border-ink/15 px-3 py-1.5 font-mono text-[11px] font-semibold text-ink-2 hover:border-rust hover:text-rust"
            >
              Sign out
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1240px] px-5 pt-10 lg:px-8">
        {message && (
          <div className="mb-6 rounded-xl border border-moss/40 bg-moss/10 p-4 text-[14px] text-moss flex items-center justify-between">
            <span>{message}</span>
            <button onClick={() => setMessage('')} className="text-moss hover:opacity-75">✕</button>
          </div>
        )}

        {/* Borrower Profile Card */}
        <div className="rounded-[20px] border border-ink/12 bg-[#fffaf1] p-6 shadow-ledger sm:p-8">
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-brand font-display text-[22px] font-bold text-paper">
                {(user?.name || 'Borrower').split(' ').map((n: string) => n[0]).join('').slice(0, 2)}
              </span>
              <div>
                <h1 className="font-display text-[26px] font-bold leading-tight">{user?.name || 'Borrower'}</h1>
                <p className="font-mono text-[12px] text-ink-3 mt-0.5">
                  +91 {user?.mobile || ''} · {user?.city || 'Bengaluru'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-6">
              <div className="text-right">
                <span className="font-mono text-[10.5px] uppercase tracking-[0.2em] text-ink-3">Trust Score</span>
                <p className="font-display text-[24px] font-bold text-brand tabular leading-none mt-1">
                  {user?.trustScore || 650} <span className="text-[12px] font-mono text-ink-3">/ 850</span>
                </p>
                <div className="mt-1.5 h-1.5 w-28 overflow-hidden rounded-full bg-ink/10">
                  <div
                    className="h-full bg-moss"
                    style={{ width: `${Math.min(100, ((user?.trustScore || 650) / 850) * 100)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>


          {/* Metric Badges */}
          <div className="mt-8 grid grid-cols-2 gap-4 border-t border-ink/10 pt-6 sm:grid-cols-4">
            <div>
              <p className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-3">Active Loans</p>
              <p className="mt-1 font-display text-[24px] font-bold text-ink">{activeLoans.length}</p>
            </div>
            <div>
              <p className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-3">Outstanding</p>
              <p className="mt-1 font-display text-[24px] font-bold text-brand tabular">{formatINR(totalOutstanding)}</p>
            </div>
            <div>
              <p className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-3">Repaid Total</p>
              <p className="mt-1 font-display text-[24px] font-bold text-moss tabular">{formatINR(totalPaid)}</p>
            </div>
            <div>
              <p className="font-mono text-[10.5px] uppercase tracking-[0.16em] text-ink-3">Disbursal Target</p>
              <p className="mt-1 font-mono text-[13px] text-ink-2 font-medium">Bank A/C verified</p>
            </div>
          </div>
        </div>

        {/* Next Due Alert */}
        {nextDueLoan && nextDueInfo && (
          <div className="mt-8 rounded-[18px] border-2 border-haldi/40 bg-gradient-to-r from-haldi/10 to-paper p-6 shadow-ledger flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="inline-flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-[0.2em] text-[#8a5d0d]">
                <IconClock width={13} height={13} /> Next EMI Instalment #{nextDueInfo.installmentNumber}
              </span>
              <p className="mt-1 font-display text-[28px] font-bold text-ink tabular">
                {formatINR(nextDueInfo.amount)}{' '}
                <span className="text-[14px] font-sans font-normal text-ink-3">
                  due on {new Date(nextDueInfo.dueDate).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                </span>
              </p>
              <p className="font-mono text-[11px] text-ink-3 mt-0.5">Loan reference: {nextDueLoan.reference}</p>
            </div>

            <button
              type="button"
              onClick={() => {
                setSelectedLoanForPay(nextDueLoan);
                setForecloseMode(false);
              }}
              className="rounded-full bg-brand px-6 py-3 font-semibold text-paper shadow-md hover:bg-brand-2 transition-transform hover:-translate-y-0.5"
            >
              Pay This EMI Now
            </button>
          </div>
        )}

        {/* Loan Book Section */}
        <div className="mt-12">
          <div className="flex items-baseline justify-between gap-4">
            <h2 className="font-display text-[26px] font-bold leading-tight">My Loan Book</h2>
            <Link href="/apply" className="text-[13.5px] font-semibold text-accent hover:underline">
              Apply for another loan →
            </Link>
          </div>

          {loans.length === 0 ? (
            <div className="mt-6 rounded-2xl border border-dashed border-ink/20 p-12 text-center">
              <p className="text-[16px] text-ink-2 font-medium">No loans on record yet.</p>
              <p className="text-[13px] text-ink-3 mt-1">Pick an amount on our live slider and submit KYC in 2 minutes.</p>
              <Link
                href="/apply"
                className="mt-5 inline-flex items-center gap-2 rounded-full bg-accent px-6 py-2.5 text-[14px] font-bold text-paper"
              >
                Apply for loan
              </Link>
            </div>
          ) : (
            <div className="mt-6 grid gap-6 md:grid-cols-2">
              {loans.map(loan => {
                const statusStyles: Record<string, string> = {
                  pending: 'bg-haldi/15 text-[#8a5d0d] border-haldi/40',
                  approved: 'bg-brand/12 text-brand border-brand/30',
                  active: 'bg-moss/14 text-moss border-moss/35',
                  closed: 'bg-ink/10 text-ink-2 border-ink/20',
                  rejected: 'bg-rust/15 text-rust border-rust/30',
                };

                return (
                  <div
                    key={loan.id}
                    className="relative overflow-hidden rounded-[20px] border border-ink/12 bg-[#fffaf1] p-6 shadow-card"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <span className="font-mono text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-3">
                          {loan.reference}
                        </span>
                        <h3 className="mt-1 font-display text-[24px] font-bold text-ink tabular">
                          {formatINR(loan.principal)}
                        </h3>
                        <p className="font-mono text-[11px] text-ink-3 uppercase">
                          {loan.purpose} · {loan.tenureMonths} months
                        </p>
                      </div>

                      <span
                        className={`rounded-full border px-3 py-1 font-mono text-[11px] font-bold uppercase tracking-[0.14em] ${
                          statusStyles[loan.status] || 'bg-ink/10 text-ink'
                        }`}
                      >
                        {loan.status}
                      </span>
                    </div>

                    <div className="mt-6 grid grid-cols-2 gap-3 rounded-xl bg-paper/60 p-3.5 text-[12.5px]">
                      <div>
                        <span className="text-ink-3">Monthly EMI:</span>
                        <p className="font-mono font-semibold text-brand">{formatINR(loan.emi)}</p>
                      </div>
                      <div>
                        <span className="text-ink-3">Net Disbursed:</span>
                        <p className="font-mono font-semibold text-ink">{formatINR(loan.netDisbursal)}</p>
                      </div>
                      <div>
                        <span className="text-ink-3">Total Repayable:</span>
                        <p className="font-mono font-semibold text-ink">{formatINR(loan.totalRepayable)}</p>
                      </div>
                      <div>
                        <span className="text-ink-3">Outstanding:</span>
                        <p className="font-mono font-semibold text-accent">{formatINR(loan.remainingRepayment || 0)}</p>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="mt-5">
                      <div className="flex justify-between font-mono text-[10.5px] text-ink-3">
                        <span>Repayment Progress</span>
                        <span>{loan.progress || 0}% ({loan.paidCount || 0}/{loan.totalInstallments || loan.tenureMonths} EMIs)</span>
                      </div>
                      <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-ink/10">
                        <div
                          className="h-full bg-gradient-to-r from-haldi to-moss"
                          style={{ width: `${loan.progress || 0}%` }}
                        />
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="mt-6 flex flex-wrap items-center gap-3 pt-4 border-t border-ink/10">
                      <button
                        type="button"
                        onClick={() => setSelectedLoanForLetter(loan)}
                        className="inline-flex items-center gap-1.5 rounded-full border border-ink/18 px-3.5 py-1.5 font-mono text-[11.5px] font-semibold text-ink-2 hover:border-brand hover:text-brand"
                      >
                        <IconDoc width={13} height={13} /> Sanction Letter
                      </button>

                      {loan.status === 'active' && (
                        <>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedLoanForPay(loan);
                              setForecloseMode(false);
                            }}
                            className="inline-flex items-center gap-1.5 rounded-full bg-accent px-4 py-1.5 font-mono text-[11.5px] font-bold text-paper hover:bg-accent-2"
                          >
                            Pay EMI
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedLoanForPay(loan);
                              setForecloseMode(true);
                            }}
                            className="inline-flex items-center gap-1.5 rounded-full border border-accent/40 bg-accent/10 px-3.5 py-1.5 font-mono text-[11.5px] font-semibold text-accent hover:bg-accent hover:text-paper"
                          >
                            Foreclose
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Borrower Ledger / Money Trail */}
        <div className="mt-16">
          <div className="flex items-baseline justify-between">
            <h2 className="font-display text-[26px] font-bold leading-tight">My Transaction Register</h2>
            <span className="font-mono text-[11px] text-ink-3 uppercase">{transactions.length} entries</span>
          </div>

          <div className="mt-6 overflow-hidden rounded-[20px] border border-ink/12 bg-[#fffaf1] shadow-ledger">
            {transactions.length === 0 ? (
              <p className="p-8 text-center text-[14px] text-ink-3">No financial transactions recorded yet.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[13.5px]">
                  <thead>
                    <tr className="border-b border-ink/10 bg-paper-2/60 font-mono text-[10px] uppercase tracking-[0.16em] text-ink-3">
                      <th className="px-5 py-3.5">Date</th>
                      <th className="px-5 py-3.5">Type</th>
                      <th className="px-5 py-3.5">Reference</th>
                      <th className="px-5 py-3.5">Mode</th>
                      <th className="px-5 py-3.5 text-right">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-ink/10">
                    {transactions.map(t => {
                      const isNegative = t.amount < 0;
                      return (
                        <tr key={t.id} className="ledger-row hover:bg-paper-2/40">
                          <td className="px-5 py-3 font-mono text-[12px] text-ink-3">
                            {new Date(t.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                          </td>
                          <td className="px-5 py-3 capitalize font-medium">{t.type.replace('_', ' ')}</td>
                          <td className="px-5 py-3 font-mono text-[12px] text-ink-2">{t.reference}</td>
                          <td className="px-5 py-3 font-mono text-[11.5px] uppercase text-ink-3">{t.mode}</td>
                          <td className={`px-5 py-3 text-right font-mono font-bold ${isNegative ? 'text-accent' : 'text-moss'}`}>
                            {isNegative ? '-' : '+'}{formatINR(Math.abs(t.amount))}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Payment Modal */}
      {selectedLoanForPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-[22px] border border-ink/15 bg-[#fffcf4] p-6 shadow-2xl">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">
                  {forecloseMode ? 'Foreclose Loan' : 'Settle Instalment'}
                </p>
                <h3 className="font-display text-[22px] font-bold">{selectedLoanForPay.reference}</h3>
              </div>
              <button onClick={() => setSelectedLoanForPay(null)} className="rounded-full p-1 text-ink-3 hover:text-ink">
                <IconClose width={20} height={20} />
              </button>
            </div>

            <div className="mt-6 rounded-xl bg-paper-2/70 p-4 text-center">
              <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Amount to Pay</span>
              <p className="font-display text-[34px] font-black text-brand tabular mt-1">
                {formatINR(forecloseMode ? selectedLoanForPay.remainingRepayment || 0 : selectedLoanForPay.emi)}
              </p>
              <p className="font-mono text-[11px] text-moss mt-1">0% Prepayment penalty · Instant clearance</p>
            </div>

            <div className="mt-6">
              <label className="block font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3 mb-2">
                Payment Channel
              </label>
              <div className="grid grid-cols-3 gap-2">
                {['upi', 'nach', 'neft'].map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setPayMode(m)}
                    className={`rounded-xl border py-2.5 text-center font-mono text-[12px] uppercase font-bold transition-all ${
                      payMode === m ? 'border-accent bg-accent text-[#fff6ec]' : 'border-ink/15 bg-paper/60 text-ink-2'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              disabled={isPaying}
              onClick={executePayment}
              className="mt-8 flex h-13 w-full items-center justify-center gap-2 rounded-full bg-accent font-bold text-paper shadow-md hover:bg-accent-2 transition-all disabled:opacity-50"
            >
              {isPaying ? 'Processing payment...' : 'Confirm & Settle Now'}
            </button>
          </div>
        </div>
      )}

      {/* Sanction Letter Modal */}
      {selectedLoanForLetter && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-[24px] border border-ink/20 bg-[#fffcf4] p-8 shadow-2xl">
            <div className="flex items-start justify-between border-b border-ink/10 pb-4">
              <div className="flex items-center gap-3">
                <KinaraSeal size={50} className="text-brand" />
                <div>
                  <h3 className="font-display text-[22px] font-bold">Uma Credits</h3>
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-ink-3">Digital Sanction Certificate</p>
                </div>
              </div>
              <button onClick={() => setSelectedLoanForLetter(null)} className="rounded-full p-1 text-ink-3 hover:text-ink">
                <IconClose width={20} height={20} />
              </button>
            </div>

            <div className="mt-6 space-y-4 text-[13.5px] leading-relaxed text-ink-2">
              <p>Dear <strong>{selectedLoanForLetter.userName}</strong>,</p>
              <p>
                We are pleased to inform you that your loan application under reference{' '}
                <strong className="font-mono text-brand">{selectedLoanForLetter.reference}</strong> has been processed
                and sanctioned in accordance with the Uma Bahi-Khata credit rules.
              </p>

              <div className="grid grid-cols-2 gap-3 rounded-xl border border-ink/10 bg-paper-2/60 p-4 font-mono text-[12px]">
                <div>Principal: <strong>{formatINR(selectedLoanForLetter.principal)}</strong></div>
                <div>Tenure: <strong>{selectedLoanForLetter.tenureMonths} Months</strong></div>
                <div>Monthly EMI: <strong>{formatINR(selectedLoanForLetter.emi)}</strong></div>
                <div>Net Disbursed: <strong>{formatINR(selectedLoanForLetter.netDisbursal)}</strong></div>
                <div>Interest Method: <strong className="capitalize">{selectedLoanForLetter.interestMethod}</strong></div>
                <div>Status: <strong className="uppercase text-moss">{selectedLoanForLetter.status}</strong></div>
              </div>

              <p>
                Repayment will be collected automatically through your registered mandate on the due date of each month until the ledger reaches ₹0.
              </p>
            </div>

            <div className="mt-8 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedLoanForLetter(null)}
                className="rounded-full bg-brand px-6 py-2.5 font-bold text-paper"
              >
                Close Letter
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
