import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { getUserLoans, getUserTransactions, getAppSettings } from '@/lib/db';

export async function GET(req: NextRequest) {
  const user = getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const loans = getUserLoans(user.id);
  const transactions = getUserTransactions(user.id);
  const { values, pricing } = getAppSettings();

  return NextResponse.json({
    user,
    loans,
    transactions,
    settings: values,
    pricing,
  });
}
