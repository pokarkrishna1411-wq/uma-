'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  Seal,
  IconChart,
  IconDoc,
  IconUsers,
  IconRupee,
  IconGear,
  IconLedger,
  IconLogout,
  IconMenu,
  IconCross,
} from '@/components/icons';
import { useSettings } from '@/components/settings-provider';
import { initials } from '@/components/ui';

interface AdminInfo {
  name: string;
  username: string;
  role: string;
}

const navItems = [
  { href: '/admin/dashboard', label: 'Control room', icon: IconChart },
  { href: '/admin/applications', label: 'Applications & KYC', icon: IconDoc },
  { href: '/admin/users', label: 'Borrowers', icon: IconUsers },
  { href: '/admin/ledger', label: 'Money ledger', icon: IconRupee },
  { href: '/admin/settings', label: 'Site settings', icon: IconGear },
  { href: '/admin/activity', label: 'Audit trail', icon: IconLedger },
];

export function AdminShell({
  admin,
  children,
  pendingCount = 0,
}: {
  admin: AdminInfo;
  children: React.ReactNode;
  pendingCount?: number;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const { text, refresh } = useSettings();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  async function handleLogout() {
    try {
      await fetch('/api/admin/logout', { method: 'POST' });
    } finally {
      router.push('/admin');
      router.refresh();
    }
  }

  const brandName = text('brand_name', 'Uma Credits');
  const brandShort = text('brand_short', 'Uma');

  return (
    <div className="min-h-screen bg-paper lg:grid lg:grid-cols-[264px_1fr]">
      <aside
        className={`paper-dark noise fixed inset-y-0 left-0 z-50 w-[264px] overflow-y-auto p-5 text-paper transition-transform duration-500 lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between gap-3">
          <Link href="/admin/dashboard" className="flex items-center gap-3">
            <span className="text-haldi">
              <Seal short={brandShort} size={44} />
            </span>
            <span>
              <span className="block font-display text-[16px] font-bold leading-tight">{brandName}</span>
              <span className="block font-mono text-[9px] uppercase tracking-[0.22em] text-paper/45">admin panel</span>
            </span>
          </Link>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(false)}
            className="text-paper/60 lg:hidden"
            aria-label="Close menu"
          >
            <IconCross width={18} height={18} />
          </button>
        </div>

        <nav className="mt-9 grid gap-1">
          {navItems.map(item => {
            const isActive = pathname === item.href || (item.href !== '/admin/dashboard' && pathname.startsWith(`${item.href}`));
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`ledger-row group flex items-center gap-3 rounded-xl px-3.5 py-3 text-[13.5px] font-semibold transition-all duration-300 ${
                  isActive ? 'bg-paper/12 text-paper' : 'text-paper/60 hover:bg-paper/6 hover:text-paper'
                }`}
              >
                <Icon width={17} height={17} className={isActive ? 'text-haldi' : 'text-paper/45 group-hover:text-haldi'} />
                {item.label}
                {item.href === '/admin/applications' && pendingCount > 0 ? (
                  <span className="ml-auto rounded-full bg-accent px-2 py-0.5 font-mono text-[10px] text-[#fff6ec]">
                    {pendingCount}
                  </span>
                ) : null}
              </Link>
            );
          })}
        </nav>

        <div className="mt-8 rounded-2xl border border-paper/12 bg-paper/5 p-4">
          <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-haldi">Signed in</p>
          <p className="mt-2 flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-full bg-haldi font-display text-[13px] font-bold text-night">
              {initials(admin.name)}
            </span>
            <span className="min-w-0">
              <span className="block truncate text-[13.5px] font-semibold">{admin.name}</span>
              <span className="block truncate font-mono text-[10.5px] uppercase tracking-[0.14em] text-paper/45">
                {admin.role} · @{admin.username}
              </span>
            </span>
          </p>
          <div className="mt-4 grid gap-2">
            <button
              type="button"
              onClick={handleLogout}
              className="flex items-center justify-center gap-2 rounded-full border border-paper/20 px-3 py-2 text-[12.5px] font-semibold text-paper/75 transition-colors hover:border-rust hover:text-[#ffb59f]"
            >
              <IconLogout width={14} height={14} /> Sign out
            </button>
            <Link
              href="/"
              onClick={() => void refresh()}
              className="flex items-center justify-center gap-2 rounded-full bg-paper/10 px-3 py-2 text-[12.5px] font-semibold text-paper transition-colors hover:bg-paper/20"
            >
              View borrower site <IconChart width={14} height={14} />
            </Link>
          </div>
        </div>

        <p className="mt-6 font-mono text-[9.5px] leading-relaxed tracking-[0.1em] text-paper/35">
          Restricted system. Every action is written to the audit trail with your name and timestamp.
        </p>
      </aside>

      {mobileMenuOpen && (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 z-40 bg-night/60 backdrop-blur-sm lg:hidden"
        />
      )}

      <div className="min-w-0">
        <div className="sticky top-0 z-30 flex h-16 items-center justify-between gap-4 border-b border-ink/12 bg-paper/92 px-5 backdrop-blur lg:hidden">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open menu"
            className="rounded-full border border-ink/15 p-2 text-ink-2"
          >
            <IconMenu width={17} height={17} />
          </button>
          <span className="font-display text-[15px] font-bold">{brandName}</span>
          <span className="w-9" />
        </div>
        <div className="px-5 py-8 lg:px-9 lg:py-10">{children}</div>
      </div>
    </div>
  );
}
