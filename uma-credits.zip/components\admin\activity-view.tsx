'use client';

import React, { useState, useEffect, useMemo } from 'react';
import {
  IconUsers,
  IconEye,
  IconCoins,
} from '@/components/icons';
import {
  Card,
  SectionLabel,
  Select,
  Skeleton,
  EmptyState,
  ToastStack,
  useToasts,
  fmtDateTime,
} from '@/components/ui';

export function ActivityView() {
  const { toasts, push, dismiss } = useToasts();
  const [activity, setActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [operatorFilter, setOperatorFilter] = useState('all');

  useEffect(() => {
    let active = true;
    setLoading(true);

    fetch('/api/admin/activity?limit=200')
      .then(res => res.json())
      .then(data => {
        if (!active) return;
        setActivity(data.activity || data.logs || []);
      })
      .catch((err: any) => {
        push({ tone: 'bad', title: 'Could not load the audit trail', body: err.message || '' });
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [push]);

  const operators = useMemo(() => {
    return ['all', ...Array.from(new Set(activity.map(a => a.actorName).filter(Boolean)))];
  }, [activity]);

  const filteredLogs = operatorFilter === 'all' ? activity : activity.filter(a => a.actorName === operatorFilter);

  return (
    <div className="grid gap-7">
      <header className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <SectionLabel>Audit trail</SectionLabel>
          <h1 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] font-black leading-none">
            Nothing happens silently.
          </h1>
          <p className="mt-3 max-w-xl text-[14px] text-ink-3">
            Every sanction, rejection, disbursal, block and settings change is stamped with the operator’s name and the exact time.
          </p>
        </div>
        <Select value={operatorFilter} onChange={e => setOperatorFilter(e.target.value)} className="w-56">
          {operators.map(op => (
            <option key={op} value={op}>
              {op === 'all' ? 'All operators' : op}
            </option>
          ))}
        </Select>
      </header>

      <Card className="overflow-hidden p-0">
        {loading ? (
          <div className="grid gap-3 p-6">
            {[0, 1, 2, 3, 4, 5].map(i => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : (
          <ol className="divide-y divide-ink/10">
            {filteredLogs.map(log => {
              const isDanger =
                log.action.includes('reject') || log.action.includes('block') || log.action.includes('failed');
              const isSuccess =
                log.action.includes('disburse') ||
                log.action.includes('approve') ||
                log.action.includes('close') ||
                log.action.includes('repay');
              const isWarning = log.action.includes('settings');

              return (
                <li key={log.id} className="ledger-row flex flex-wrap items-start gap-4 px-6 py-4">
                  <span
                    className={`mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-xl ${
                      isDanger
                        ? 'bg-rust/12 text-rust'
                        : isSuccess
                        ? 'bg-moss/12 text-moss'
                        : isWarning
                        ? 'bg-haldi/18 text-[#8a5d0d]'
                        : 'bg-brand/10 text-brand'
                    }`}
                  >
                    {log.actorType === 'admin' ? (
                      <IconUsers width={15} height={15} />
                    ) : log.actorType === 'user' ? (
                      <IconEye width={15} height={15} />
                    ) : (
                      <IconCoins width={15} height={15} />
                    )}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[13.5px] text-ink-2">{log.summary ?? log.action}</span>
                    <span className="mt-1 block font-mono text-[10.5px] uppercase tracking-[0.14em] text-ink-3">
                      {log.actorName} · {log.actorType} · {log.action}
                      {log.entityType ? ` · ${log.entityType}` : ''} · {fmtDateTime(log.createdAt)}
                    </span>
                  </span>
                </li>
              );
            })}
            {filteredLogs.length === 0 && (
              <li className="p-6">
                <EmptyState title="No activity for this operator" />
              </li>
            )}
          </ol>
        )}
      </Card>

      <ToastStack toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
