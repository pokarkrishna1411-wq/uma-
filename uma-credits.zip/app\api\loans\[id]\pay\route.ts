import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';
import { payInstallment, getLoanById } from '@/lib/db';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const user = getCurrentUser();
    const loan = getLoanById(params.id);
    if (!loan) {
      return NextResponse.json({ error: 'Loan not found' }, { status: 404 });
    }

    const body = await req.json().catch(() => ({}));
    const updatedLoan = payInstallment(loan.id, body, user?.name || loan.userName || 'Borrower');

    return NextResponse.json({ loan: updatedLoan, success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Payment failed' }, { status: 500 });
  }
}
