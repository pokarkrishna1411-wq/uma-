import { NextRequest, NextResponse } from 'next/server';
import { deleteSession } from '@/lib/db';
import { USER_COOKIE } from '@/lib/auth';

export async function POST(req: NextRequest) {
  const token = req.cookies.get(USER_COOKIE)?.value;
  if (token) {
    deleteSession(token);
  }
  const response = NextResponse.json({ success: true });
  response.cookies.delete(USER_COOKIE);
  return response;
}
