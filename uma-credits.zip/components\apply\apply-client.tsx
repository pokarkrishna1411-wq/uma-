'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useSettings } from '@/components/settings-provider';
import { calculateLoan, formatINR } from '@/lib/loan-math';
import {
  IconArrow,
  IconCoins,
  IconPercent,
  IconDoc,
  IconShield,
  IconCalendar,
  IconClock,
  IconClose,
  IconCheck,
} from '@/components/icons';

export function ApplyClient({ user }: { user?: any }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { pricing, text } = useSettings();

  const initAmount = parseInt(searchParams.get('amount') || '10000');
  const initTenure = parseInt(searchParams.get('tenure') || String(pricing.defaultTenure || 6));
  const initPurpose = searchParams.get('purpose') || 'business';

  const [amount, setAmount] = useState(initAmount);
  const [tenure, setTenure] = useState(initTenure);
  const [purpose, setPurpose] = useState(initPurpose);
  const [showKycModal, setShowKycModal] = useState(false);

  // KYC Form state
  const [fullName, setFullName] = useState(user?.name || '');
  const [mobile, setMobile] = useState(user?.mobile || '');
  const [email, setEmail] = useState(user?.email || '');
  const [pan, setPan] = useState('');
  const [bankAccount, setBankAccount] = useState('');
  const [bankName, setBankName] = useState('HDFC Bank');
  const [ifsc, setIfsc] = useState('HDFC0001234');
  const [address, setAddress] = useState('83, Ring Road, Bengaluru');
  const [consent, setConsent] = useState(true);

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const quote = useMemo(() => {
    return calculateLoan({
      principal: amount,
      tenureMonths: tenure,
      pricing,
    });
  }, [amount, tenure, pricing]);

  const minL = pricing.minLoan || 1000;
  const maxL = pricing.maxLoan || 200000;
  const fillPct = ((amount - minL) / (maxL - minL)) * 100;

  const quickAmounts = pricing.quickAmounts || [1000, 5000, 10000, 25000, 50000, 100000];
  const tenures = pricing.tenures || [
    { months: 3, label: '3 months' },
    { months: 6, label: '6 months' },
    { months: 9, label: '9 months' },
    { months: 12, label: '12 months' },
    { months: 18, label: '18 months' },
    { months: 24, label: '24 months' },
  ];

  const purposes = pricing.purposes || [
    { value: 'business', label: 'Business & working capital' },
    { value: 'inventory', label: 'Festival inventory' },
    { value: 'equipment', label: 'Equipment & machinery' },
    { value: 'medical', label: 'Medical emergency' },
    { value: 'education', label: 'Education' },
    { value: 'personal', label: 'Personal need' },
  ];

  async function handleKycSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    const cleanPan = pan.trim().toUpperCase();
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
    if (!panRegex.test(cleanPan)) {
      setError('Please enter a valid 10-digit PAN (e.g. ABCDE1234F)');
      return;
    }

    if (!bankAccount.trim()) {
      setError('Please enter your bank account number');
      return;
    }

    if (!consent) {
      setError('Please confirm consent to proceed');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/loans', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          principal: amount,
          tenureMonths: tenure,
          purpose,
          kycData: {
            fullName: fullName.trim() || 'Borrower',
            mobile: mobile.replace(/\D/g, '').slice(-10),
            email: email.trim(),
            pan: cleanPan,
            bankAccountNumber: bankAccount.trim(),
            bankName,
            ifsc: ifsc.trim().toUpperCase(),
            address,
          },
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit loan application');
      }

      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-paper text-ink pb-24">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-ink/10 bg-paper/95 backdrop-blur-md">
        <div className="mx-auto flex h-[68px] max-w-[1240px] items-center justify-between px-5 lg:px-8">
          <Link className="flex items-center gap-3" href="/">
            <span className="grid h-9 w-9 place-items-center rounded-[10px] font-display text-[17px] font-black bg-accent text-[#fff6ec]">
              U
            </span>
            <span className="leading-none">
              <span className="block font-display text-[17px] font-bold tracking-tight text-ink">Uma Credits</span>
              <span className="mt-0.5 block font-mono text-[9.5px] uppercase tracking-[0.24em] text-ink-3">New Application</span>
            </span>
          </Link>
          <Link href="/" className="font-mono text-[12px] text-ink-3 hover:text-ink">
            Cancel & return
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-[1240px] px-5 pt-12 lg:px-8">
        <div>
          <span className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.28em] text-ink-3">
            <span className="inline-block h-px w-7 bg-accent" />
            Apply for digital loan
          </span>
          <h1 className="mt-3 font-display text-[clamp(2rem,4vw,3.2rem)] font-bold">
            Choose amount & terms
          </h1>
        </div>

        <div className="mt-10 grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-start">
          {/* Controls */}
          <div className="rounded-[20px] border border-ink/12 bg-[#fffaf1] p-6 shadow-ledger sm:p-8">
            <div className="flex items-baseline justify-between gap-4">
              <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-ink-3">Loan amount</p>
              <p className="font-display text-[40px] font-black leading-none text-brand tabular">
                {formatINR(amount)}
              </p>
            </div>

            <input
              type="range"
              className="rupee-range mt-4"
              style={{ ['--fill' as any]: `${fillPct}%` }}
              min={minL}
              max={maxL}
              step={pricing.stepAmount || 500}
              value={amount}
              onChange={e => setAmount(Number(e.target.value))}
            />

            <div className="flex justify-between font-mono text-[10.5px] uppercase tracking-[0.14em] text-ink-3 mt-1">
              <span>{formatINR(minL)}</span>
              <span>{formatINR(maxL)}</span>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              {quickAmounts.map(val => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmount(val)}
                  className={`rounded-full border px-3.5 py-1.5 font-mono text-[12px] transition-all duration-300 ${
                    amount === val
                      ? 'border-accent bg-accent text-[#fff6ec]'
                      : 'border-ink/18 text-ink-2 hover:border-accent hover:text-accent'
                  }`}
                >
                  {formatINR(val)}
                </button>
              ))}
            </div>

            <div className="mt-8 h-px w-full bg-ink/10" />

            <p className="mt-7 font-mono text-[11px] uppercase tracking-[0.2em] text-ink-3">Repay over</p>
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
              {tenures.map(t => (
                <button
                  key={t.months}
                  type="button"
                  onClick={() => setTenure(t.months)}
                  className={`rounded-xl border px-2 py-3 text-center transition-all duration-300 ${
                    tenure === t.months
                      ? 'border-brand bg-brand text-paper shadow-md'
                      : 'border-ink/15 bg-paper/60 text-ink-2 hover:border-brand/50'
                  }`}
                >
                  <span className="block font-display text-[19px] font-bold leading-none">{t.months}</span>
                  <span className="mt-1 block font-mono text-[9.5px] uppercase tracking-[0.14em] opacity-70">months</span>
                </button>
              ))}
            </div>

            <div className="mt-7">
              <label className="block">
                <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Purpose of loan</span>
                <span className="mt-1.5 block">
                  <select
                    className="w-full rounded-xl border bg-paper/70 px-3.5 py-2.5 text-[14.5px] text-ink transition-all duration-200 focus:bg-[#fffdf7] focus:outline-none cursor-pointer border-ink/18 focus:border-brand"
                    value={purpose}
                    onChange={e => setPurpose(e.target.value)}
                  >
                    {purposes.map(p => (
                      <option key={p.value} value={p.value}>
                        {p.label}
                      </option>
                    ))}
                  </select>
                </span>
              </label>
            </div>
          </div>

          {/* Breakdown & Continue */}
          <div className="lg:sticky lg:top-24">
            <div className="paper-dark noise relative overflow-hidden rounded-[20px] p-6 text-paper shadow-card sm:p-8">
              <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-haldi">Loan sanction summary</p>
              <p className="mt-2 font-display text-[15px] text-paper/70">Monthly instalment</p>
              <p className="font-display text-[clamp(2.4rem,5vw,3.4rem)] font-black leading-none text-paper tabular">
                {formatINR(quote.emi)}
              </p>

              <dl className="mt-6 grid gap-px overflow-hidden rounded-xl bg-paper/12">
                <div className="flex items-center justify-between gap-4 bg-[#101f1a] px-4 py-3">
                  <dt className="text-[13px] text-paper/70">Principal borrowed</dt>
                  <dd className="font-mono text-[13.5px] text-paper tabular">{formatINR(quote.principal)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-[#101f1a] px-4 py-3">
                  <dt className="text-[13px] text-paper/70">Interest ({quote.monthlyRatePct}%/mo)</dt>
                  <dd className="font-mono text-[13.5px] text-paper tabular">{formatINR(quote.interest)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-[#101f1a] px-4 py-3">
                  <dt className="text-[13px] text-paper/70">Processing Fee + GST</dt>
                  <dd className="font-mono text-[13.5px] text-paper tabular">{formatINR(quote.feeTotal)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-accent/90 px-4 py-3">
                  <dt className="text-[13px] font-semibold text-[#fff6ec]">Net disbursed to bank</dt>
                  <dd className="font-mono text-[14.5px] font-semibold text-[#fff6ec] tabular">{formatINR(quote.netDisbursal)}</dd>
                </div>
                <div className="flex items-center justify-between gap-4 bg-[#0b1714] px-4 py-3">
                  <dt className="text-[13px] text-paper/75">Total to repay</dt>
                  <dd className="font-mono text-[14.5px] text-paper tabular">{formatINR(quote.totalRepayable)}</dd>
                </div>
              </dl>

              <button
                type="button"
                onClick={() => setShowKycModal(true)}
                className="mt-8 flex h-14 w-full items-center justify-center gap-2 rounded-full bg-accent font-bold text-paper shadow-md hover:bg-accent-2 transition-all"
              >
                Proceed to KYC Verification <IconArrow width={16} height={16} />
              </button>

              <p className="mt-4 text-center font-mono text-[11px] text-paper/60 uppercase tracking-[0.14em]">
                NSDL encrypted · Underwriting SLA 4 hours
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* KYC Modal */}
      {showKycModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-[24px] border border-ink/15 bg-[#fffcf4] p-8 shadow-2xl">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-ink-3">Digital Counter · Form K-02</p>
                <h3 className="font-display text-[24px] font-bold">Instant KYC Submission</h3>
              </div>
              <button onClick={() => setShowKycModal(false)} className="rounded-full p-1 text-ink-3 hover:text-ink">
                <IconClose width={20} height={20} />
              </button>
            </div>

            {error && (
              <div className="mt-4 rounded-xl border border-rust/40 bg-rust/10 p-3 text-[13px] text-rust">
                {error}
              </div>
            )}

            <form onSubmit={handleKycSubmit} className="mt-6 grid gap-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Full Name</span>
                  <input
                    required
                    placeholder="e.g. Iqbal Ansari"
                    className="mt-1 w-full rounded-xl border border-ink/18 bg-paper/70 px-3.5 py-2 text-[14px] text-ink focus:border-brand focus:outline-none"
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                  />
                </label>

                <label className="block">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Mobile Number</span>
                  <input
                    required
                    maxLength={10}
                    placeholder="9845012233"
                    className="mt-1 w-full rounded-xl border border-ink/18 bg-paper/70 px-3.5 py-2 text-[14px] text-ink font-mono focus:border-brand focus:outline-none"
                    value={mobile}
                    onChange={e => setMobile(e.target.value)}
                  />
                </label>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Email Address</span>
                  <input
                    type="email"
                    placeholder="name@example.com"
                    className="mt-1 w-full rounded-xl border border-ink/18 bg-paper/70 px-3.5 py-2 text-[14px] text-ink focus:border-brand focus:outline-none"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                  />
                </label>

                <label className="block">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">PAN Card Number</span>
                  <input
                    required
                    maxLength={10}
                    placeholder="ABCDE1234F"
                    className="mt-1 w-full rounded-xl border border-ink/18 bg-paper/70 px-3.5 py-2 text-[14px] text-ink font-mono uppercase focus:border-brand focus:outline-none"
                    value={pan}
                    onChange={e => setPan(e.target.value.toUpperCase())}
                  />
                </label>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Bank Account Number</span>
                  <input
                    required
                    placeholder="912345678901"
                    className="mt-1 w-full rounded-xl border border-ink/18 bg-paper/70 px-3.5 py-2 text-[14px] text-ink font-mono focus:border-brand focus:outline-none"
                    value={bankAccount}
                    onChange={e => setBankAccount(e.target.value)}
                  />
                </label>

                <label className="block">
                  <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Bank IFSC Code</span>
                  <input
                    required
                    maxLength={11}
                    placeholder="HDFC0001234"
                    className="mt-1 w-full rounded-xl border border-ink/18 bg-paper/70 px-3.5 py-2 text-[14px] text-ink font-mono uppercase focus:border-brand focus:outline-none"
                    value={ifsc}
                    onChange={e => setIfsc(e.target.value.toUpperCase())}
                  />
                </label>
              </div>

              <label className="block">
                <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">Address</span>
                <input
                  placeholder="83, Ring Road, Bengaluru"
                  className="mt-1 w-full rounded-xl border border-ink/18 bg-paper/70 px-3.5 py-2 text-[14px] text-ink focus:border-brand focus:outline-none"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                />
              </label>

              <label className="mt-2 flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={consent}
                  onChange={e => setConsent(e.target.checked)}
                  className="mt-1 h-4 w-4 rounded accent-[#e4572e]"
                />
                <span className="text-[12px] leading-relaxed text-ink-3">
                  {text(
                    'kyc_consent_text',
                    'I confirm the details above are mine and accurate. I authorise Uma Credits to verify my PAN and bank account, and to debit EMIs through NACH/e-mandate as per the repayment schedule.'
                  )}
                </span>
              </label>

              <button
                type="submit"
                disabled={submitting}
                className="mt-4 flex h-13 w-full items-center justify-center gap-2 rounded-full bg-accent font-bold text-paper shadow-md hover:bg-accent-2 transition-all disabled:opacity-50"
              >
                {submitting ? 'Verifying & Submitting...' : 'Confirm & Submit Application'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
