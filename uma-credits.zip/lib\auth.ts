import { cookies } from 'next/headers';
import { getSession, getUserById, getAdminByUsername, User, Admin, recordAdminLogin } from './db';

export const USER_COOKIE = 'kinara_user_session';
export const ADMIN_COOKIE = 'kinara_admin_session';

export function getCurrentUser(): User | null {
  try {
    const cookieStore = cookies();
    const token = cookieStore.get(USER_COOKIE)?.value;
    if (!token) return null;
    const session = getSession(token);
    if (!session || session.subjectType !== 'user') return null;
    const user = getUserById(session.subjectId);
    if (!user || user.status === 'blocked') return null;
    return user;
  } catch {
    return null;
  }
}

export function getCurrentAdmin(): Admin | null {
  try {
    const cookieStore = cookies();
    const token = cookieStore.get(ADMIN_COOKIE)?.value;
    if (token) {
      const session = getSession(token);
      if (session && session.subjectType === 'admin') {
        const admin = getAdminByUsername('admin');
        if (admin) return admin;
      }
    }
  } catch {}
  // Direct opening mode: automatically authenticate as default admin operator without requiring password
  const fallback = getAdminByUsername('admin');
  return fallback || {
    id: 'admin-1',
    username: 'admin',
    name: 'Rukmini Iyer',
    role: 'owner',
  };
}



export function jsonResponse(data: any, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

export function errorResponse(message: string, status = 400) {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}
