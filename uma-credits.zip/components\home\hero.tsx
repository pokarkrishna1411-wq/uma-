'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useSettings } from '@/components/settings-provider';
import { IconArrow, IconLock, IconShield, IconPhone, IconShop, IconCheck } from '@/components/icons';

export function AnnouncementTicker() {
  const { text } = useSettings();
  const ticker = text(
    'announcement_ticker',
    'Festive offer • Processing fee waived above ₹25,000 • Disbursal in under 24 hours • Repay early, save interest • NACH e-mandate now live'
  );

  const items = ticker.split('•').map(s => s.trim()).filter(Boolean);

  return (
    <div className="marquee-host relative overflow-hidden border-b border-ink/20 bg-accent text-[#fff5ea]">
      <div className="marquee-track py-1.5">
        <div className="flex shrink-0 items-center">
          {items.concat(items).map((item, i) => (
            <span key={i} className="flex items-center gap-3 whitespace-nowrap px-5 font-mono text-[11px] uppercase tracking-[0.18em]">
              <span className="opacity-70">✳</span>
              {item}
            </span>
          ))}
        </div>
        <div className="flex shrink-0 items-center">
          {items.concat(items).map((item, i) => (
            <span key={`dup-${i}`} className="flex items-center gap-3 whitespace-nowrap px-5 font-mono text-[11px] uppercase tracking-[0.18em]">
              <span className="opacity-70">✳</span>
              {item}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export function SiteHeader({ user }: { user?: any }) {
  const { text } = useSettings();
  const brandName = text('brand_name', 'Uma Credits');
  const brandShort = text('brand_short', 'Uma');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 transition-all duration-500 border-b border-transparent bg-paper/95 backdrop-blur-md">
      <div className="mx-auto flex h-[68px] max-w-[1240px] items-center justify-between gap-6 px-5 lg:px-8">
        <Link className="group flex items-center gap-3" href="/">
          <span className="grid h-9 w-9 place-items-center rounded-[10px] font-display text-[17px] font-black transition-transform duration-500 group-hover:-rotate-6 bg-accent text-[#fff6ec]">
            {brandShort[0] || 'U'}
          </span>
          <span className="leading-none">
            <span className="block font-display text-[17px] font-bold tracking-tight text-ink">{brandName}</span>
            <span className="mt-0.5 block font-mono text-[9.5px] uppercase tracking-[0.24em] text-ink-3">lender · est. 2019</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-6 lg:flex">
          <Link href="/#how" className="link-draw text-[13.5px] font-semibold text-ink-2 transition-colors hover:text-ink">
            How it works
          </Link>
          <Link href="/#calculator" className="link-draw text-[13.5px] font-semibold text-ink-2 transition-colors hover:text-ink">
            EMI calculator
          </Link>
          <Link href="/#stories" className="link-draw text-[13.5px] font-semibold text-ink-2 transition-colors hover:text-ink">
            Borrowers
          </Link>
          <Link href="/#rates" className="link-draw text-[13.5px] font-semibold text-ink-2 transition-colors hover:text-ink">
            Rate board
          </Link>
          <Link href="/#faq" className="link-draw text-[13.5px] font-semibold text-ink-2 transition-colors hover:text-ink">
            FAQ
          </Link>
          <Link href="/docs" className="link-draw text-[13.5px] font-semibold text-ink-2 transition-colors hover:text-ink">
            Architecture
          </Link>
        </nav>

        <div className="flex items-center gap-2.5">
          {user ? (
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 rounded-full bg-brand px-4 py-2.5 text-[13px] font-bold text-paper transition-transform duration-300 hover:-translate-y-0.5"
            >
              My Dashboard
            </Link>
          ) : (
            <Link
              href="#login"
              className="hidden items-center gap-2 rounded-full bg-accent px-4 py-2.5 text-[13px] font-bold text-[#fff6ec] shadow-[0_12px_26px_-16px_rgba(228,87,46,1)] transition-transform duration-300 hover:-translate-y-0.5 sm:inline-flex"
            >
              <IconLock width={15} height={15} /> Log in
            </Link>
          )}
          <Link
            href="/admin"
            className="rounded-full border border-ink/15 px-3 py-1.5 font-mono text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-2 transition-colors hover:border-accent hover:text-accent"
          >
            Admin
          </Link>
          <button
            type="button"
            aria-label="Menu"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="rounded-full border border-ink/15 p-2 text-ink-2 lg:hidden"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" width="16" height="16">
              <path d="M4 7h16M4 12h16M4 17h16" />
            </svg>
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="border-b border-ink/10 bg-paper px-6 py-4 lg:hidden">
          <div className="flex flex-col gap-3 font-semibold text-[14px]">
            <Link href="/#how" onClick={() => setMobileMenuOpen(false)}>How it works</Link>
            <Link href="/#calculator" onClick={() => setMobileMenuOpen(false)}>EMI calculator</Link>
            <Link href="/#stories" onClick={() => setMobileMenuOpen(false)}>Borrowers</Link>
            <Link href="/#rates" onClick={() => setMobileMenuOpen(false)}>Rate board</Link>
            <Link href="/#faq" onClick={() => setMobileMenuOpen(false)}>FAQ</Link>
            <Link href="/docs" onClick={() => setMobileMenuOpen(false)}>Architecture</Link>
            <Link href="/admin" onClick={() => setMobileMenuOpen(false)}>Admin Panel</Link>
          </div>
        </div>
      )}
    </header>
  );
}

export function HeroSection({ user }: { user?: any }) {
  const { text, pricing } = useSettings();
  const router = useRouter();

  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const kicker = text('hero_kicker', 'Bahi-khata style digital lending · Bengaluru');
  const headline = text('hero_headline', 'A ₹1,000 loan, sanctioned before your chai gets cold.');
  const subline = text(
    'hero_subline',
    'Log in with just your name and mobile number. See the exact EMI, the exact interest and the exact date your loan closes — before you hand over a single document.'
  );

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const cleanMobile = mobile.replace(/\D/g, '').slice(-10);
    if (!name.trim()) {
      setError('Please enter your name');
      return;
    }
    if (cleanMobile.length !== 10) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, mobile: cleanMobile }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Login failed');
      }
      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="paper-dark noise relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 opacity-[0.22]">
        <img
          src="https://images.pexels.com/photos/12495827/pexels-photo-12495827.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
          alt=""
          aria-hidden="true"
          className="kenburns h-full w-full object-cover"
        />
      </div>
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(120% 100% at 80% 10%, rgba(228,87,46,.22), transparent 55%), linear-gradient(180deg, rgba(13,26,22,.55), rgba(13,26,22,.92))',
        }}
      />

      <div className="relative mx-auto grid max-w-[1240px] gap-14 px-5 pb-20 pt-14 lg:grid-cols-[1.15fr_0.85fr] lg:gap-16 lg:px-8 lg:pb-28 lg:pt-20">
        <div className="text-paper">
          <span className="line-mask inline-block">
            <span className="inline-flex items-center gap-2.5 rounded-full border border-haldi/40 bg-haldi/10 px-3.5 py-1.5 font-mono text-[10.5px] uppercase tracking-[0.24em] text-haldi">
              <span className="relative flex h-1.5 w-1.5">
                <span className="pulse-ring absolute inline-flex h-full w-full rounded-full bg-haldi" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-haldi" />
              </span>
              {kicker}
            </span>
          </span>

          <h1 className="mt-6 font-display text-[clamp(2.6rem,6.4vw,4.9rem)] font-black leading-[0.94] tracking-[-0.03em]">
            {headline}
          </h1>

          <p className="mt-7 max-w-xl text-[15.5px] leading-relaxed text-paper/75">{subline}</p>

          <div className="mt-9 flex flex-wrap items-center gap-3">
            <a
              href="#calculator"
              className="sweep relative inline-flex h-13 items-center gap-2 overflow-hidden rounded-full bg-paper px-6 py-3.5 text-[14px] font-bold text-ink transition-transform duration-300 hover:-translate-y-0.5"
            >
              Calculate my EMI <IconArrow width={16} height={16} />
            </a>
            <a
              href="#how"
              className="inline-flex items-center gap-2 rounded-full border border-paper/25 px-6 py-3.5 text-[14px] font-semibold text-paper/85 transition-colors hover:border-paper/60 hover:text-paper"
            >
              How the ledger works
            </a>
          </div>

          <dl className="mt-12 grid max-w-2xl grid-cols-2 gap-x-8 gap-y-6 border-t border-paper/15 pt-8 sm:grid-cols-4">
            <div>
              <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-haldi">Borrowers</dt>
              <dd className="mt-1.5 font-display text-[26px] font-bold leading-none text-paper tabular">18</dd>
              <dd className="mt-1 text-[11.5px] text-paper/50">on the book</dd>
            </div>
            <div>
              <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-haldi">Sanctioned</dt>
              <dd className="mt-1.5 font-display text-[26px] font-bold leading-none text-paper tabular">₹5.43L</dd>
              <dd className="mt-1 text-[11.5px] text-paper/50">lifetime</dd>
            </div>
            <div>
              <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-haldi">Disbursed</dt>
              <dd className="mt-1.5 font-display text-[26px] font-bold leading-none text-paper tabular">₹4.86L</dd>
              <dd className="mt-1 text-[11.5px] text-paper/50">to bank accounts</dd>
            </div>
            <div>
              <dt className="font-mono text-[10px] uppercase tracking-[0.2em] text-haldi">Collection</dt>
              <dd className="mt-1.5 font-display text-[26px] font-bold leading-none text-paper tabular">64.2%</dd>
              <dd className="mt-1 text-[11.5px] text-paper/50">on-time rate</dd>
            </div>
          </dl>

          <p className="mt-8 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.18em] text-paper/45">
            <span className="inline-block h-px w-8 bg-accent" />
            Rate today · {pricing.monthlyRatePct}% / month · ≈{pricing.annualRatePct}% APR · {pricing.interestMethod === 'flat' ? 'flat rate' : 'reducing balance'}
          </p>
        </div>

        <div id="login" className="relative scroll-mt-24">
          <div className="pointer-events-none absolute -right-4 -top-8 hidden h-32 w-28 rotate-[7deg] overflow-hidden rounded-xl border-4 border-paper shadow-card lg:block">
            <img
              src="https://images.pexels.com/photos/13206032/pexels-photo-13206032.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Tailor working a sewing machine in Kanpur"
              className="kenburns h-full w-full object-cover"
              loading="lazy"
            />
          </div>
          <div className="pointer-events-none absolute -bottom-10 -left-6 hidden h-28 w-24 -rotate-[9deg] overflow-hidden rounded-xl border-4 border-paper shadow-card lg:block">
            <img
              src="https://images.pexels.com/photos/38043952/pexels-photo-38043952.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Street fruit vendor in Delhi"
              className="kenburns h-full w-full object-cover"
              loading="lazy"
            />
          </div>

          <div
            className="paper relative rounded-[16px] border border-ink/15 bg-[#fffcf4] p-6 shadow-[0_50px_90px_-40px_rgba(0,0,0,.85)] sm:p-7"
            style={{ transform: 'rotate(-0.7deg)' }}
          >
            <div
              className="pointer-events-none absolute inset-x-0 top-[86px] h-px"
              style={{
                backgroundImage: 'repeating-linear-gradient(to right, rgba(23,19,15,.28) 0 6px, transparent 6px 12px)',
              }}
            />

            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.26em] text-ink-3">Counter slip · form K-01</p>
                <h2 className="mt-1.5 font-display text-[26px] font-bold leading-none text-ink">
                  {user ? `Welcome back, ${user.name}` : 'Log in to borrow'}
                </h2>
              </div>
              <span className="font-mono text-[10px] text-ink-3">SN-00000</span>
            </div>

            {user ? (
              <div className="mt-8 space-y-4">
                <p className="text-[14px] text-ink-2">You are currently signed in with mobile <strong>+91 {user.mobile}</strong>.</p>
                <Link
                  href="/dashboard"
                  className="relative inline-flex items-center justify-center rounded-full font-semibold tracking-tight transition-all duration-300 active:translate-y-px bg-accent text-[#fff6ec] hover:bg-accent-2 shadow-[0_10px_24px_-14px_rgba(228,87,46,.95)] h-14 px-7 text-[15px] gap-2.5 w-full"
                >
                  Go to Borrower Dashboard <IconArrow width={16} height={16} />
                </Link>
              </div>
            ) : (
              <form className="mt-8 grid gap-4" onSubmit={handleLogin} noValidate>
                {error && (
                  <div className="rounded-xl border border-rust/35 bg-rust/10 p-3 text-[13px] text-rust">
                    {error}
                  </div>
                )}

                <label className="block">
                  <span className="flex items-baseline justify-between gap-3">
                    <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">
                      Your name<span className="ml-1 text-accent">*</span>
                    </span>
                  </span>
                  <span className="mt-1.5 block">
                    <input
                      autoComplete="name"
                      placeholder="e.g. Iqbal Ansari"
                      className="w-full rounded-xl border bg-paper/70 px-3.5 py-2.5 text-[14.5px] text-ink placeholder:text-ink-3/60 transition-all duration-200 focus:bg-[#fffdf7] focus:outline-none border-ink/18 focus:border-brand"
                      value={name}
                      onChange={e => setName(e.target.value)}
                    />
                  </span>
                </label>

                <label className="block">
                  <span className="flex items-baseline justify-between gap-3">
                    <span className="font-mono text-[11px] uppercase tracking-[0.16em] text-ink-3">
                      Mobile number<span className="ml-1 text-accent">*</span>
                    </span>
                    <span className="text-[11px] text-ink-3/80">10 digits, no OTP</span>
                  </span>
                  <span className="mt-1.5 block">
                    <div className="flex items-stretch gap-2">
                      <span className="grid w-14 shrink-0 place-items-center rounded-xl border border-ink/18 bg-paper-2/70 font-mono text-[13px] text-ink-2">
                        +91
                      </span>
                      <input
                        inputMode="numeric"
                        autoComplete="tel"
                        maxLength={10}
                        placeholder="98450 12233"
                        className="w-full rounded-xl border bg-paper/70 px-3.5 py-2.5 text-[14.5px] text-ink placeholder:text-ink-3/60 transition-all duration-200 focus:bg-[#fffdf7] focus:outline-none border-ink/18 focus:border-brand font-mono tracking-[0.06em]"
                        value={mobile}
                        onChange={e => setMobile(e.target.value)}
                      />
                    </div>
                  </span>
                </label>

                <button
                  type="submit"
                  disabled={loading}
                  className="relative inline-flex items-center justify-center rounded-full font-semibold tracking-tight transition-all duration-300 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-50 bg-accent text-[#fff6ec] hover:bg-accent-2 shadow-[0_10px_24px_-14px_rgba(228,87,46,.95)] h-14 px-7 text-[15px] gap-2.5 mt-1 w-full"
                >
                  {loading ? 'Opening ledger...' : 'Continue to my dashboard'}
                  <IconArrow width={16} height={16} />
                </button>

                <p className="flex items-start gap-2 text-[12px] leading-relaxed text-ink-3">
                  <IconLock width={14} height={14} className="mt-0.5 shrink-0 text-brand" />
                  {text(
                    'login_note',
                    'No password, no OTP fatigue. We identify you by your mobile number and keep a session on this device only.'
                  )}
                </p>
              </form>
            )}
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 font-mono text-[10.5px] uppercase tracking-[0.18em] text-paper/60">
            <span className="flex items-center gap-1.5">
              <IconShield width={13} height={13} className="text-haldi" /> KYC encrypted at rest
            </span>
            <span className="flex items-center gap-1.5">
              <IconPhone width={13} height={13} className="text-haldi" /> {text('support_phone', '+91 80 4718 2200')}
            </span>
            <span className="flex items-center gap-1.5">
              <IconShop width={13} height={13} className="text-haldi" /> 18 borrowers on the book
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
