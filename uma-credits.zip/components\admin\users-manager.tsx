'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import Link from 'next/link';
import {
  IconSearch,
  IconDownload,
  IconDoc,
  IconUsers,
  IconEye,
  IconBan,
  IconCheck,
  IconAlert,
  IconTrash,
  IconCross,
} from '@/components/icons';
import {
  Button,
  Card,
  Badge,
  SectionLabel,
  EmptyState,
  Input,
  Textarea,
  Tabs,
  Modal,
  Field,
  Skeleton,
  ToastStack,
  useToasts,
  inr,
  fmtDate,
  relativeTime,
  dueLabel,
  initials,
} from '@/components/ui';

function useDebounce<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debounced;
}

const statusBadgeTones: Record<string, string> = {
  pending: 'amber',
  approved: 'teal',
  active: 'green',
  closed: 'slate',
  rejected: 'rust',
};

export function UsersManager() {
  const { toasts, push, dismiss } = useToasts();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [users, setUsers] = useState<any[]>([]);
  const [totalCount, setTotalCount] = useState(0);
  const [tabCounts, setTabCounts] = useState({ all: 0, active: 0, blocked: 0 });
  const [loading, setLoading] = useState(true);
  const [viewingUser, setViewingUser] = useState<any | null>(null);
  const [blockingUser, setBlockingUser] = useState<any | null>(null);
  const [deletingUser, setDeletingUser] = useState<any | null>(null);
  const [deleteAllOpen, setDeleteAllOpen] = useState(false);
  const [blockReason, setBlockReason] = useState('');
  const [actionLoading, setActionLoading] = useState(false);

  const debouncedSearch = useDebounce(searchTerm);

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/admin/users?q=${encodeURIComponent(debouncedSearch)}&status=${statusFilter}&limit=100`
      );
      const data = await res.json();
      setUsers(data.users || []);
      setTotalCount(data.total || (data.users || []).length);
      if (data.counts) {
        setTabCounts(data.counts);
      } else {
        const uList = data.users || [];
        setTabCounts({
          all: data.total || uList.length,
          active: uList.filter((u: any) => u.status === 'active').length,
          blocked: uList.filter((u: any) => u.status === 'blocked').length,
        });
      }
    } catch (err: any) {
      push({ tone: 'bad', title: 'Could not load borrowers', body: err.message || '' });
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, statusFilter, push]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  async function handleUserAction(user: any, action: 'block' | 'unblock') {
    setActionLoading(true);
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, reason: blockReason }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Action failed');
      }

      push({
        tone: action === 'block' ? 'info' : 'good',
        title: action === 'block' ? `${user.name} blocked` : `${user.name} unblocked`,
        body: action === 'block' ? 'Their session was invalidated immediately.' : 'They can log in again with the same number.',
      });

      setBlockingUser(null);
      setBlockReason('');
      setViewingUser(null);
      await fetchUsers();
    } catch (err: any) {
      push({ tone: 'bad', title: 'Action failed', body: err.message || '' });
    } finally {
      setActionLoading(false);
    }
  }

  async function handleDeleteUser(user: any) {
    setActionLoading(true);
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'DELETE',
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to delete user');
      }

      setUsers(prev => prev.filter(u => u.id !== user.id));
      setTotalCount(prev => Math.max(0, prev - 1));
      setTabCounts(prev => ({
        ...prev,
        all: Math.max(0, prev.all - 1),
        [user.status === 'blocked' ? 'blocked' : 'active']: Math.max(
          0,
          (prev as any)[user.status === 'blocked' ? 'blocked' : 'active'] - 1
        ),
      }));

      push({
        tone: 'good',
        title: 'Borrower deleted',
        body: `${user.name} and all their applications and KYC records have been removed.`,
      });

      setDeletingUser(null);
      setViewingUser(null);
    } catch (err: any) {
      push({ tone: 'bad', title: 'Delete failed', body: err.message || '' });
    } finally {
      setActionLoading(false);
    }
  }

  async function handleDeleteAllUsers() {
    setActionLoading(true);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'DELETE',
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to purge users');
      }

      setUsers([]);
      setTotalCount(0);
      setTabCounts({ all: 0, active: 0, blocked: 0 });

      push({
        tone: 'good',
        title: 'All borrowers purged',
        body: 'All borrower records, loan applications, KYC files and ledger history were deleted.',
      });

      setDeleteAllOpen(false);
    } catch (err: any) {
      push({ tone: 'bad', title: 'Purge failed', body: err.message || '' });
    } finally {
      setActionLoading(false);
    }
  }

  return (
    <div className="grid gap-7">
      <header className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <SectionLabel>Borrower registry</SectionLabel>
          <h1 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] font-black leading-none">
            Everyone who has walked up to the counter.
          </h1>
          <p className="mt-3 max-w-xl text-[14px] text-ink-3">
            Search by name or mobile number, open a full file, block a number, or delete borrowers.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            variant="danger"
            size="md"
            onClick={() => setDeleteAllOpen(true)}
            className="border border-rust/40 bg-rust/90 text-paper hover:bg-rust shadow-sm"
          >
            <IconTrash width={15} height={15} /> Delete all users
          </Button>
          <a href="/api/admin/export?what=users">
            <Button variant="outline">
              <IconDownload width={15} height={15} /> Export users
            </Button>
          </a>
          <a href="/api/admin/export?what=kyc">
            <Button variant="outline">
              <IconDoc width={15} height={15} /> Export KYC
            </Button>
          </a>
        </div>
      </header>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[240px] flex-1">
          <IconSearch width={16} height={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-3" />
          <Input
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search name, mobile or email…"
            className="pl-10"
          />
        </div>
        <Tabs
          tabs={[
            { value: 'all', label: 'All', count: tabCounts.all },
            { value: 'active', label: 'Active', count: tabCounts.active },
            { value: 'blocked', label: 'Blocked', count: tabCounts.blocked },
          ]}
          active={statusFilter}
          onChange={setStatusFilter}
        />
      </div>

      <Card className="overflow-hidden p-0">
        {loading ? (
          <div className="grid gap-3 p-6">
            {[0, 1, 2, 3, 4].map(i => (
              <Skeleton key={i} className="h-14 w-full" />
            ))}
          </div>
        ) : users.length === 0 ? (
          <div className="p-6">
            <EmptyState
              icon={<IconUsers width={28} height={28} />}
              title="No borrowers match that search"
              body="Try a different name, mobile number or clear the filters."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead className="bg-paper-2/50 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">
                <tr>
                  <th className="px-5 py-3">Borrower</th>
                  <th className="px-5 py-3">Location</th>
                  <th className="px-5 py-3 text-right">Loans</th>
                  <th className="px-5 py-3 text-right">Borrowed</th>
                  <th className="px-5 py-3 text-right">Outstanding</th>
                  <th className="px-5 py-3 text-center">Trust</th>
                  <th className="px-5 py-3">Last seen</th>
                  <th className="px-5 py-3 text-right">Status</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="text-[13px]">
                {users.map(u => (
                  <tr key={u.id} className="ledger-row border-t border-ink/10">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <span
                          className={`grid h-9 w-9 shrink-0 place-items-center rounded-full font-display text-[12.5px] font-bold ${
                            u.status === 'blocked' ? 'bg-rust/15 text-rust' : 'bg-brand/12 text-brand'
                          }`}
                        >
                          {initials(u.name)}
                        </span>
                        <span>
                          <span className="block font-semibold text-ink">{u.name}</span>
                          <span className="block font-mono text-[11px] text-ink-3">{u.maskedMobile}</span>
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-ink-2">
                      {u.city ?? '—'}
                      <span className="block font-mono text-[10.5px] text-ink-3">{u.occupation ?? ''}</span>
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono tabular">{u.loans?.length || 0}</td>
                    <td className="px-5 py-3.5 text-right font-mono tabular">{inr(u.totalBorrowed)}</td>
                    <td className="px-5 py-3.5 text-right font-mono tabular">
                      {inr(u.outstanding)}
                      {u.overdue > 0 && <span className="ml-1.5 text-[11px] font-semibold text-rust">{u.overdue} late</span>}
                    </td>
                    <td className="px-5 py-3.5 text-center">
                      <span
                        className={`font-mono text-[12.5px] tabular ${
                          u.trustScore >= 720 ? 'text-moss' : u.trustScore >= 650 ? 'text-[#8a5d0d]' : 'text-rust'
                        }`}
                      >
                        {u.trustScore}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 font-mono text-[11.5px] text-ink-3">
                      {u.lastLoginAt ? relativeTime(u.lastLoginAt) : 'never'}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <Badge tone={u.status === 'blocked' ? 'rust' : 'green'}>{u.status}</Badge>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex justify-end gap-1.5">
                        <Button size="sm" variant="ghost" onClick={() => setViewingUser(u)}>
                          <IconEye width={14} height={14} /> File
                        </Button>
                        {u.status === 'active' ? (
                          <Button size="sm" variant="outline" onClick={() => setBlockingUser(u)}>
                            <IconBan width={14} height={14} /> Block
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="primary"
                            loading={actionLoading}
                            onClick={() => handleUserAction(u, 'unblock')}
                          >
                            <IconCheck width={14} height={14} /> Unblock
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-rust hover:bg-rust/10 hover:text-rust"
                          onClick={() => setDeletingUser(u)}
                          title="Delete borrower"
                        >
                          <IconTrash width={14} height={14} />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* User File Modal */}
      <Modal
        open={!!viewingUser}
        onClose={() => setViewingUser(null)}
        title={viewingUser?.name ?? ''}
        subtitle={
          viewingUser
            ? `${viewingUser.maskedMobile} · joined ${fmtDate(viewingUser.createdAt)} · ${viewingUser.loginCount} logins`
            : ''
        }
        width="max-w-4xl"
      >
        {viewingUser && (
          <div className="grid gap-6">
            <div className="grid gap-3 sm:grid-cols-4">
              {[
                { k: 'Borrowed', v: inr(viewingUser.totalBorrowed) },
                { k: 'Outstanding', v: inr(viewingUser.outstanding) },
                { k: 'Trust score', v: String(viewingUser.trustScore) },
                { k: 'Ledger entries', v: String(viewingUser.ledgerCount) },
              ].map(item => (
                <div key={item.k} className="rounded-xl border border-ink/12 bg-paper-2/40 px-4 py-3">
                  <p className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">{item.k}</p>
                  <p className="mt-1 font-display text-[20px] font-bold tabular">{item.v}</p>
                </div>
              ))}
            </div>

            {viewingUser.blockReason && (
              <p className="flex items-start gap-2 rounded-xl border border-rust/25 bg-rust/8 px-4 py-3 text-[13px] text-rust">
                <IconAlert width={15} height={15} className="mt-0.5 shrink-0" /> Blocked: {viewingUser.blockReason}
              </p>
            )}

            <div>
              <p className="font-mono text-[10.5px] uppercase tracking-[0.18em] text-ink-3">Loan history & KYC</p>
              <div className="mt-3 grid gap-3">
                {(!viewingUser.loans || viewingUser.loans.length === 0) && (
                  <p className="text-[13.5px] text-ink-3">This borrower has never applied.</p>
                )}
                {viewingUser.loans?.map((l: any) => (
                  <div key={l.id} className="rounded-2xl border border-ink/12 bg-[#fffaf1] p-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div>
                        <Link
                          href={`/admin/applications/${l.id}`}
                          className="font-mono text-[12px] text-accent hover:underline"
                        >
                          {l.reference}
                        </Link>
                        <p className="mt-1 font-display text-[20px] font-bold leading-none tabular">{inr(l.principal)}</p>
                        <p className="mt-1 text-[12px] text-ink-3">
                          {l.tenureMonths} mo · EMI {inr(l.emi)} · {l.paidCount}/{l.totalInstallments} paid ·{' '}
                          {dueLabel(l.nextDue?.dueDate ?? l.maturityDate)}
                        </p>
                      </div>
                      <Badge tone={statusBadgeTones[l.status] ?? 'slate'}>{l.status}</Badge>
                    </div>

                    {l.kyc && (
                      <dl className="mt-3 grid gap-1.5 border-t border-ink/10 pt-3 sm:grid-cols-2">
                        {[
                          { k: 'PAN', v: l.kyc.pan },
                          { k: 'Account', v: `${l.kyc.bankName ?? 'Bank'} · ${l.kyc.bankAccountNumber}` },
                          { k: 'Email', v: l.kyc.email },
                          { k: 'KYC status', v: l.kyc.status },
                        ].map(item => (
                          <div key={item.k} className="flex items-baseline justify-between gap-3">
                            <dt className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-3">{item.k}</dt>
                            <dd className="truncate font-mono text-[12px] text-ink-2">{item.v}</dd>
                          </div>
                        ))}
                      </dl>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap justify-between gap-3 border-t border-ink/10 pt-5">
              <Button
                variant="danger"
                onClick={() => {
                  const target = viewingUser;
                  setViewingUser(null);
                  setDeletingUser(target);
                }}
              >
                <IconTrash width={15} height={15} /> Delete this user
              </Button>

              <div className="flex gap-2">
                {viewingUser.status === 'active' ? (
                  <Button variant="outline" onClick={() => setBlockingUser(viewingUser)}>
                    <IconBan width={15} height={15} /> Block this number
                  </Button>
                ) : (
                  <Button
                    variant="primary"
                    loading={actionLoading}
                    onClick={() => handleUserAction(viewingUser, 'unblock')}
                  >
                    <IconCheck width={15} height={15} /> Unblock this number
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* Block Confirmation Modal */}
      <Modal open={!!blockingUser} onClose={() => setBlockingUser(null)} title={`Block ${blockingUser?.name ?? ''}`} width="max-w-md">
        <div className="grid gap-4">
          <p className="text-[13.5px] leading-relaxed text-ink-3">
            Blocking ends their live session, stops new applications and shows a support message when they try to log in with{' '}
            {blockingUser?.maskedMobile}.
          </p>
          <Field label="Reason (shown to the borrower on request)">
            <Textarea
              value={blockReason}
              onChange={e => setBlockReason(e.target.value)}
              placeholder="Two consecutive NACH bounces"
            />
          </Field>
          <div className="flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setBlockingUser(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              loading={actionLoading}
              onClick={() => blockingUser && handleUserAction(blockingUser, 'block')}
            >
              <IconBan width={15} height={15} /> Block borrower
            </Button>
          </div>
        </div>
      </Modal>

      {/* Single User Delete Confirmation Modal */}
      <Modal
        open={!!deletingUser}
        onClose={() => setDeletingUser(null)}
        title={`Delete borrower: ${deletingUser?.name ?? ''}`}
        width="max-w-md"
      >
        <div className="grid gap-4">
          <p className="text-[13.5px] leading-relaxed text-ink-3">
            Are you sure you want to permanently delete <strong className="text-ink font-semibold">{deletingUser?.name}</strong> (+91 {deletingUser?.mobile})?
          </p>
          <div className="rounded-xl border border-rust/20 bg-rust/8 p-3 text-[12.5px] leading-relaxed text-rust">
            This will permanently erase their profile, all submitted loan applications, KYC documents, repayment schedules, and ledger entries.
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={() => setDeletingUser(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              loading={actionLoading}
              onClick={() => deletingUser && handleDeleteUser(deletingUser)}
            >
              <IconTrash width={15} height={15} /> Delete borrower
            </Button>
          </div>
        </div>
      </Modal>

      {/* Delete All Users Modal */}
      <Modal
        open={deleteAllOpen}
        onClose={() => setDeleteAllOpen(false)}
        title="Delete all borrowers from registry?"
        width="max-w-md"
      >
        <div className="grid gap-4">
          <p className="text-[13.5px] leading-relaxed text-ink-3">
            This action will permanently delete <strong className="text-ink font-semibold">all {totalCount} borrowers</strong>, reset active borrower sessions, clear all loan applications, uploaded KYC data, and ledger entries.
          </p>
          <div className="rounded-xl border border-rust/30 bg-rust/10 p-3 text-[12.5px] font-medium leading-relaxed text-rust">
            ⚠️ Warning: Admin accounts and platform configuration settings will remain intact, but all user records will be irreversibly erased.
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={() => setDeleteAllOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              loading={actionLoading}
              onClick={handleDeleteAllUsers}
            >
              <IconTrash width={15} height={15} /> Yes, delete all users
            </Button>
          </div>
        </div>
      </Modal>

      <ToastStack toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
