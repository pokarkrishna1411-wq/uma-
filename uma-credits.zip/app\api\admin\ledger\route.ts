import { NextRequest, NextResponse } from 'next/server';
import { getAllTransactions, roundPaisa } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const type = searchParams.get('type');
  const limit = parseInt(searchParams.get('limit') || '200');

  let ledger = getAllTransactions();

  const totalInflow = ledger.filter(t => t.amount > 0).reduce((acc, t) => acc + t.amount, 0);
  const totalOutflow = ledger.filter(t => t.amount < 0).reduce((acc, t) => acc + Math.abs(t.amount), 0);
  const netBalance = roundPaisa(totalInflow - totalOutflow);

  if (type && type !== 'all') {
    ledger = ledger.filter(t => t.type === type);
  }

  return NextResponse.json({
    ledger: ledger.slice(0, limit),
    transactions: ledger.slice(0, limit),
    summary: {
      totalInflow: roundPaisa(totalInflow),
      totalOutflow: roundPaisa(totalOutflow),
      netBalance,
      totalCount: ledger.length,
    },
  });
}
