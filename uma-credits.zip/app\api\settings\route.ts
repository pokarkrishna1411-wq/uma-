import { NextResponse } from 'next/server';
import { getAppSettings } from '@/lib/db';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  const { values, pricing } = getAppSettings();
  return NextResponse.json(
    {
      settings: values,
      values,
      pricing,
    },
    {
      headers: {
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
      },
    }
  );
}
