import React from 'react';
import { ApplicationsManager } from '@/components/admin/applications-manager';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export default function ApplicationsPage() {
  return <ApplicationsManager />;
}
