'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import {
  IconSearch,
  IconDownload,
  IconFilter,
  IconCheck,
  IconCross,
  IconBank,
  IconRupee,
  IconArrow,
} from '@/components/icons';
import {
  Button,
  Card,
  Badge,
  SectionLabel,
  EmptyState,
  Input,
  Textarea,
  Tabs,
  Modal,
  Field,
  Skeleton,
  ToastStack,
  useToasts,
  inr,
  inrExact,
  relativeTime,
  maskPan,
  maskAccount,
} from '@/components/ui';

const statusBadgeTones: Record<string, string> = {
  pending: 'amber',
  approved: 'teal',
  active: 'green',
  closed: 'slate',
  rejected: 'rust',
  submitted: 'amber',
  verified: 'green',
};

function useDebounce<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debounced;
}

export function ApplicationsManager() {
  const { toasts, push, dismiss } = useToasts();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [applications, setApplications] = useState<any[]>([]);
  const [counts, setCounts] = useState<{ [key: string]: number }>({
    all: 0,
    pending: 0,
    approved: 0,
    active: 0,
    closed: 0,
    rejected: 0,
  });
  const [totalCount, setTotalCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [rejectingApp, setRejectingApp] = useState<any | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');

  const debouncedSearch = useDebounce(searchTerm);

  const fetchApplications = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/api/admin/applications?q=${encodeURIComponent(debouncedSearch)}&status=${statusFilter}&limit=100`
      );
      const data = await res.json();
      setApplications(data.applications || []);
      setTotalCount(data.total || (data.applications || []).length);
      if (data.counts) {
        setCounts(data.counts);
      }
    } catch (err: any) {
      push({ tone: 'bad', title: 'Could not load applications', body: err.message || '' });
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, statusFilter, push]);

  useEffect(() => {
    fetchApplications();
  }, [fetchApplications]);

  async function handleAction(app: any, action: string, extra: any = {}) {
    setActionLoadingId(app.id);
    try {
      const res = await fetch(`/api/admin/applications/${app.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...extra }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Action failed');
      }

      const resData = await res.json();
      const updated = resData.loan || resData.application;

      // Optimistically update applications state immediately so buttons vanish / update
      setApplications(prev => {
        if (statusFilter === 'pending' && (action === 'approve' || action === 'reject')) {
          return prev.filter(a => a.id !== app.id);
        }
        if (statusFilter === 'approved' && action === 'disburse') {
          return prev.filter(a => a.id !== app.id);
        }
        return prev.map(a => {
          if (a.id !== app.id) return a;
          return updated || {
            ...a,
            status: action === 'approve' ? 'approved' : action === 'disburse' ? 'active' : action === 'reject' ? 'rejected' : a.status,
          };
        });
      });

      // Update tab counts immediately
      setCounts(prev => {
        const next = { ...prev };
        if (action === 'approve') {
          next.pending = Math.max(0, (next.pending || 1) - 1);
          next.approved = (next.approved || 0) + 1;
        } else if (action === 'disburse') {
          next.approved = Math.max(0, (next.approved || 1) - 1);
          next.active = (next.active || 0) + 1;
        } else if (action === 'reject') {
          next.pending = Math.max(0, (next.pending || 1) - 1);
          next.rejected = (next.rejected || 0) + 1;
        }
        return next;
      });

      push({
        tone: action === 'reject' ? 'info' : 'good',
        title: `${action.replace('-', ' ')} · ${app.reference}`,
        body: app.userName ?? '',
      });

      setRejectingApp(null);
    } catch (err: any) {
      push({ tone: 'bad', title: 'Action failed', body: err.message || '' });
    } finally {
      setActionLoadingId(null);
    }
  }

  return (
    <div className="grid gap-7">
      <header className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <SectionLabel>Underwriting desk</SectionLabel>
          <h1 className="mt-3 font-display text-[clamp(2rem,4.4vw,3rem)] font-black leading-none">
            Applications & KYC review.
          </h1>
          <p className="mt-3 max-w-2xl text-[14px] text-ink-3">
            Verify the PAN and bank details, sanction or reject with a reason, then disburse — disbursal generates the instalment schedule and writes the ledger entries.
          </p>
        </div>
        <a href="/api/admin/export?what=applications">
          <Button variant="outline">
            <IconDownload width={15} height={15} /> Export applications
          </Button>
        </a>
      </header>

      <div className="flex flex-wrap items-center gap-3">
        <div className="relative min-w-[240px] flex-1">
          <IconSearch width={16} height={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-3" />
          <Input
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search reference, name, mobile, PAN or email…"
            className="pl-10"
          />
        </div>
        <Tabs
          tabs={[
            { value: 'all', label: 'All', count: counts.all },
            { value: 'pending', label: 'Pending', count: counts.pending },
            { value: 'approved', label: 'Approved', count: counts.approved },
            { value: 'active', label: 'Active', count: counts.active },
            { value: 'closed', label: 'Closed', count: counts.closed },
            { value: 'rejected', label: 'Rejected', count: counts.rejected },
          ]}
          active={statusFilter}
          onChange={setStatusFilter}
        />
      </div>

      <Card className="overflow-hidden p-0">
        {loading ? (
          <div className="grid gap-3 p-6">
            {[0, 1, 2, 3, 4, 5].map(i => (
              <Skeleton key={i} className="h-14 w-full" />
            ))}
          </div>
        ) : applications.length === 0 ? (
          <div className="p-6">
            <EmptyState
              icon={<IconFilter width={26} height={26} />}
              title="Nothing in this slice of the book"
              body="Change the status filter or clear the search."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead className="bg-paper-2/50 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ink-3">
                <tr>
                  <th className="px-5 py-3">Reference</th>
                  <th className="px-5 py-3">Borrower</th>
                  <th className="px-5 py-3">KYC</th>
                  <th className="px-5 py-3 text-right">Amount</th>
                  <th className="px-5 py-3 text-right">Tenure</th>
                  <th className="px-5 py-3 text-right">EMI</th>
                  <th className="px-5 py-3 text-right">Interest</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="text-[13px]">
                {applications.map(app => (
                  <tr key={app.id} className="ledger-row border-t border-ink/10">
                    <td className="px-5 py-3.5">
                      <Link href={`/admin/applications/${app.id}`} className="font-mono text-[12px] text-accent hover:underline">
                        {app.reference}
                      </Link>
                      <p className="mt-0.5 font-mono text-[10.5px] text-ink-3">{relativeTime(app.createdAt)}</p>
                    </td>
                    <td className="px-5 py-3.5">
                      <p className="font-semibold text-ink">{app.userName ?? '—'}</p>
                      <p className="font-mono text-[11px] text-ink-3">+91 {app.userMobile}</p>
                    </td>
                    <td className="px-5 py-3.5 font-mono text-[11px] text-ink-3">
                      {app.kyc ? (
                        <span className="grid gap-0.5">
                          <span>{maskPan(app.kyc.panMasked || app.kyc.pan)}</span>
                          <span>{maskAccount(app.kyc.bankAccountNumber)}</span>
                        </span>
                      ) : (
                        <Badge tone="rust">missing</Badge>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-right font-mono font-semibold tabular">{inr(app.principal)}</td>
                    <td className="px-5 py-3.5 text-right font-mono tabular text-ink-3">{app.tenureMonths} mo</td>
                    <td className="px-5 py-3.5 text-right font-mono tabular">{inrExact(app.emi)}</td>
                    <td className="px-5 py-3.5 text-right font-mono tabular text-ink-3">{inr(app.interest)}</td>
                    <td className="px-5 py-3.5">
                      <Badge tone={statusBadgeTones[app.status] ?? 'slate'}>{app.status}</Badge>
                      {app.kyc && app.kyc.status !== 'submitted' && (
                        <span className="mt-1 block font-mono text-[10px] uppercase tracking-[0.12em] text-ink-3">
                          kyc {app.kyc.status}
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex flex-wrap justify-end gap-2">
                        {app.status === 'pending' && (
                          <>
                            <Button
                              size="sm"
                              variant="primary"
                              loading={actionLoadingId === app.id}
                              onClick={() => handleAction(app, 'approve')}
                            >
                              <IconCheck width={13} height={13} /> Sanction
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => setRejectingApp(app)}>
                              <IconCross width={13} height={13} /> Reject
                            </Button>
                          </>
                        )}
                        {app.status === 'approved' && (
                          <Button
                            size="sm"
                            variant="accent"
                            loading={actionLoadingId === app.id}
                            onClick={() => handleAction(app, 'disburse')}
                          >
                            <IconBank width={13} height={13} /> Disburse {inr(app.netDisbursal)}
                          </Button>
                        )}
                        {app.status === 'active' && (
                          <Button
                            size="sm"
                            variant="outline"
                            loading={actionLoadingId === app.id}
                            onClick={() => handleAction(app, 'mark-paid')}
                          >
                            <IconRupee width={13} height={13} /> Record EMI
                          </Button>
                        )}
                        <Link href={`/admin/applications/${app.id}`}>
                          <Button size="sm" variant="ghost">
                            <IconArrow width={13} height={13} /> File
                          </Button>
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Reject Modal */}
      <Modal open={!!rejectingApp} onClose={() => setRejectingApp(null)} title={`Reject ${rejectingApp?.reference ?? ''}`} width="max-w-md">
        <div className="grid gap-4">
          <p className="text-[13.5px] text-ink-3">
            The borrower sees this reason on their dashboard and on the loan letter.
          </p>
          <Field label="Reason">
            <Textarea
              autoFocus
              value={rejectionReason}
              onChange={e => setRejectionReason(e.target.value)}
              placeholder="Bank statements show insufficient cash flow"
            />
          </Field>
          <div className="flex justify-end gap-3">
            <Button variant="ghost" onClick={() => setRejectingApp(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              loading={actionLoadingId === rejectingApp?.id}
              onClick={() => rejectingApp && handleAction(rejectingApp, 'reject', { reason: rejectionReason.trim() || undefined })}
            >
              Reject application
            </Button>
          </div>
        </div>
      </Modal>

      <ToastStack toasts={toasts} onDismiss={dismiss} />
    </div>
  );
}
