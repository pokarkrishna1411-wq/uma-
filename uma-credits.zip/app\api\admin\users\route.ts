import { NextRequest, NextResponse } from 'next/server';
import { getAllUsers, getAllLoans, deleteAllUsers } from '@/lib/db';
import { getCurrentAdmin } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get('q')?.toLowerCase().trim();
  const status = searchParams.get('status');
  const limit = parseInt(searchParams.get('limit') || '100');

  const users = getAllUsers();
  const loans = getAllLoans();

  let enrichedUsers = users.map(u => {
    const userLoans = loans.filter(l => l.userId === u.id);
    const totalBorrowed = userLoans.reduce((acc, l) => acc + (l.status !== 'rejected' ? l.principal : 0), 0);
    const outstanding = userLoans.filter(l => l.status === 'active').reduce((acc, l) => acc + (l.remainingRepayment || 0), 0);
    const overdue = userLoans.reduce((acc, l) => acc + (l.overdueCount || 0), 0);

    return {
      ...u,
      loans: userLoans,
      ledgerCount: userLoans.length,
      totalBorrowed,
      outstanding,
      overdue,
    };
  });

  const counts = {
    all: enrichedUsers.length,
    active: enrichedUsers.filter(u => u.status === 'active').length,
    blocked: enrichedUsers.filter(u => u.status === 'blocked').length,
  };

  if (q) {
    enrichedUsers = enrichedUsers.filter(u =>
      u.name.toLowerCase().includes(q) ||
      u.mobile.includes(q) ||
      (u.maskedMobile && u.maskedMobile.includes(q)) ||
      (u.email && u.email.toLowerCase().includes(q)) ||
      (u.city && u.city.toLowerCase().includes(q))
    );
  }

  if (status && status !== 'all') {
    enrichedUsers = enrichedUsers.filter(u => u.status === status);
  }

  return NextResponse.json({
    users: enrichedUsers.slice(0, limit),
    total: enrichedUsers.length,
    counts,
  });
}

export async function DELETE(req: NextRequest) {
  try {
    const admin = getCurrentAdmin();
    const operatorName = admin?.name || 'Rukmini Iyer';

    const result = deleteAllUsers(operatorName);

    return NextResponse.json({
      success: true,
      count: result.count,
      message: `Successfully deleted all ${result.count} borrowers and cleared loan registry`,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to delete all users' }, { status: 500 });
  }
}
