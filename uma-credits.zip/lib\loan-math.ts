export interface PricingSettings {
  interestMethod?: 'reducing' | 'flat';
  monthlyRatePct: number;
  annualRatePct?: number;
  processingFeePct: number;
  gstPct: number;
  lateFee?: number;
  bounceCharges?: number;
  minLoan?: number;
  maxLoan?: number;
  stepAmount?: number;
  defaultTenure?: number;
  graceDays?: number;
  tenures?: Array<{ months: number; label: string }>;
  quickAmounts?: number[];
  purposes?: Array<{ value: string; label: string }>;
  acceptingApplications?: boolean;
  maxActiveLoans?: number;
  prepaymentAllowed?: boolean;
  prepaymentPenaltyPct?: number;
}

export interface InstallmentScheduleItem {
  n: number;
  dueDate: string;
  emi: number;
  principalPart: number;
  interestPart: number;
  openingBalance: number;
  closingBalance: number;
  status?: 'upcoming' | 'due' | 'paid' | 'overdue';
  paidAt?: string | null;
  paidAmount?: number;
  lateFee?: number;
}

export interface LoanCalculationResult {
  principal: number;
  tenureMonths: number;
  method: 'reducing' | 'flat';
  monthlyRatePct: number;
  annualRatePct: number;
  emi: number;
  interest: number;
  processingFee: number;
  gst: number;
  feeTotal: number;
  netDisbursal: number;
  totalRepayable: number;
  costOfCredit: number;
  costOfCreditPct: number;
  perDayCost: number;
  firstDueDate: string;
  maturityDate: string;
  schedule: InstallmentScheduleItem[];
}

export const roundPaisa = (val: number | string): number => {
  return Math.round((Number(val) + Number.EPSILON) * 100) / 100;
};

export function addMonths(date: Date, months: number): Date {
  const result = new Date(date.getTime());
  const day = result.getDate();
  result.setDate(1);
  result.setMonth(result.getMonth() + months);
  const maxDays = new Date(result.getFullYear(), result.getMonth() + 1, 0).getDate();
  result.setDate(Math.min(day, maxDays));
  return result;
}

export function calculateLoan({
  principal,
  tenureMonths,
  pricing,
  startDate = new Date(),
}: {
  principal: number | string;
  tenureMonths: number | string;
  pricing: PricingSettings;
  startDate?: Date;
}): LoanCalculationResult {
  const p = Math.max(0, roundPaisa(Number(principal) || 0));
  const tenure = Math.max(1, Math.round(Number(tenureMonths) || 1));
  const monthlyRate = (Number(pricing.monthlyRatePct) || 0) / 100;
  const method: 'reducing' | 'flat' = pricing.interestMethod === 'flat' ? 'flat' : 'reducing';
  const annualRate = pricing.annualRatePct ?? roundPaisa(monthlyRate * 100 * 12);

  let totalInterest = 0;
  let emiAmount = 0;
  const schedule: InstallmentScheduleItem[] = [];

  if (method === 'flat') {
    totalInterest = roundPaisa(p * monthlyRate * tenure);
    emiAmount = roundPaisa((p + totalInterest) / tenure);
    let curBal = p;
    const baseP = roundPaisa(p / tenure);
    const baseI = roundPaisa(totalInterest / tenure);

    for (let i = 1; i <= tenure; i++) {
      const openBal = roundPaisa(curBal);
      const pPart = i === tenure ? openBal : baseP;
      const iPart = i === tenure ? roundPaisa(totalInterest - baseI * (tenure - 1)) : baseI;
      const closeBal = roundPaisa(Math.max(0, openBal - pPart));
      schedule.push({
        n: i,
        dueDate: addMonths(startDate, i).toISOString(),
        emi: roundPaisa(pPart + iPart),
        principalPart: pPart,
        interestPart: iPart,
        openingBalance: openBal,
        closingBalance: closeBal,
        status: 'upcoming',
      });
      curBal = closeBal;
    }
  } else {
    // Reducing balance
    if (monthlyRate === 0) {
      emiAmount = roundPaisa(p / tenure);
    } else {
      const factor = Math.pow(1 + monthlyRate, tenure);
      emiAmount = roundPaisa((p * monthlyRate * factor) / (factor - 1));
    }

    let curBal = roundPaisa(p);
    for (let i = 1; i <= tenure; i++) {
      const openBal = roundPaisa(curBal);
      const interestPart = roundPaisa(openBal * monthlyRate);
      let principalPart = roundPaisa(emiAmount - interestPart);
      let emi = emiAmount;

      if (i === tenure) {
        principalPart = openBal;
        emi = roundPaisa(openBal + interestPart);
      }

      const closeBal = roundPaisa(Math.max(0, openBal - principalPart));
      schedule.push({
        n: i,
        dueDate: addMonths(startDate, i).toISOString(),
        emi: emi,
        principalPart: principalPart,
        interestPart: interestPart,
        openingBalance: openBal,
        closingBalance: closeBal,
        status: 'upcoming',
      });
      curBal = closeBal;
    }
    totalInterest = roundPaisa(schedule.reduce((acc, item) => acc + item.interestPart, 0));
  }

  const processingFee = roundPaisa((p * (Number(pricing.processingFeePct) || 0)) / 100);
  const gst = roundPaisa((processingFee * (Number(pricing.gstPct) || 0)) / 100);
  const feeTotal = roundPaisa(processingFee + gst);
  const totalRepayable = roundPaisa(schedule.reduce((acc, item) => acc + item.emi, 0));
  const costOfCredit = roundPaisa(totalInterest + feeTotal);
  const approxDays = Math.max(1, Math.round((365 * tenure) / 12));

  return {
    principal: p,
    tenureMonths: tenure,
    method,
    monthlyRatePct: Number(pricing.monthlyRatePct) || 0,
    annualRatePct: annualRate,
    emi: schedule.length ? roundPaisa(schedule[0].emi) : 0,
    interest: totalInterest,
    processingFee,
    gst,
    feeTotal,
    netDisbursal: roundPaisa(Math.max(0, p - feeTotal)),
    totalRepayable,
    costOfCredit,
    costOfCreditPct: p > 0 ? roundPaisa((costOfCredit / p) * 100) : 0,
    perDayCost: roundPaisa(costOfCredit / approxDays),
    firstDueDate: schedule[0]?.dueDate ?? addMonths(startDate, 1).toISOString(),
    maturityDate: schedule[schedule.length - 1]?.dueDate ?? addMonths(startDate, tenure).toISOString(),
    schedule,
  };
}

export function formatINR(val: number | string): string {
  const num = Number(val) || 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(num);
}

export function formatNumberINR(val: number | string): string {
  const num = Number(val) || 0;
  return new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(num);
}
